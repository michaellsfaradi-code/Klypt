import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import * as webpush from 'web-push';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

// Ensure data directory exists for lightweight persistent storage
const DATA_DIR = path.resolve(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const VAPID_FILE = path.join(DATA_DIR, 'vapid.json');
const SUBS_FILE = path.join(DATA_DIR, 'subscriptions.json');

// 1. Initialize or load persistent VAPID keys
interface VapidKeys {
  publicKey: string;
  privateKey: string;
}

let vapidKeys: VapidKeys;
if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
  vapidKeys = {
    publicKey: process.env.VAPID_PUBLIC_KEY,
    privateKey: process.env.VAPID_PRIVATE_KEY
  };
} else if (fs.existsSync(VAPID_FILE)) {
  try {
    vapidKeys = JSON.parse(fs.readFileSync(VAPID_FILE, 'utf-8'));
  } catch {
    vapidKeys = webpush.generateVAPIDKeys();
    fs.writeFileSync(VAPID_FILE, JSON.stringify(vapidKeys, null, 2));
  }
} else {
  vapidKeys = webpush.generateVAPIDKeys();
  fs.writeFileSync(VAPID_FILE, JSON.stringify(vapidKeys, null, 2));
}

webpush.setVapidDetails(
  'mailto:station@klypt.local',
  vapidKeys.publicKey,
  vapidKeys.privateKey
);

// 2. Load persistent Push Subscriptions map: stationId -> PushSubscription
let subscriptionsMap: Record<string, webpush.PushSubscription> = {};
if (fs.existsSync(SUBS_FILE)) {
  try {
    subscriptionsMap = JSON.parse(fs.readFileSync(SUBS_FILE, 'utf-8'));
  } catch (e) {
    console.warn('Failed reading subscriptions file, resetting:', e);
    subscriptionsMap = {};
  }
}

function saveSubscriptions() {
  try {
    fs.writeFileSync(SUBS_FILE, JSON.stringify(subscriptionsMap, null, 2));
  } catch (err) {
    console.error('Failed saving subscriptions file:', err);
  }
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // ===================== WEB PUSH API ROUTES =====================

  // Endpoint 0: Public VAPID key for browser subscription
  app.get('/api/vapid-public-key', (_req: Request, res: Response) => {
    res.json({ publicKey: vapidKeys.publicKey });
  });

  // Endpoint 1: Register or update browser PushSubscription by stationId
  app.post('/api/subscribe', (req: Request, res: Response) => {
    const { stationId, subscription } = req.body;
    if (!stationId || !subscription || !subscription.endpoint) {
      res.status(400).json({ error: 'Missing stationId or subscription object' });
      return;
    }

    subscriptionsMap[stationId] = subscription;
    saveSubscriptions();
    console.log(`[WebPush] Subscribed station: ${stationId} (Total: ${Object.keys(subscriptionsMap).length})`);

    res.json({
      success: true,
      stationId,
      totalSubscribers: Object.keys(subscriptionsMap).length
    });
  });

  // Endpoint 2: Wake up an offline / sleeping peer by stationId
  app.post('/api/ring', async (req: Request, res: Response) => {
    const { targetStationId, callerId, callerName, callerIp } = req.body;

    if (!targetStationId || !callerId) {
      res.status(400).json({ error: 'Missing targetStationId or callerId' });
      return;
    }

    console.log(`[WebPush] Incoming ring request for station: ${targetStationId} from ${callerName || callerId}`);

    const subscription = subscriptionsMap[targetStationId];
    if (!subscription) {
      res.status(404).json({
        success: false,
        reason: 'not_subscribed',
        message: 'החבר טרם אישר התראות Push או שהמזהה שגוי'
      });
      return;
    }

    const payload = JSON.stringify({
      type: 'INCOMING_CALL',
      title: `שיחה נכנסת מ-${callerName || 'חבר'}!`,
      body: `מחייג אליך כעת ל-Klypt • לחץ למענה`,
      callerId,
      callerName: callerName || 'חבר',
      callerIp: callerIp || '',
      url: `/?incomingCallFrom=${encodeURIComponent(callerId)}&callerName=${encodeURIComponent(callerName || 'חבר')}&autoAnswer=1`,
      timestamp: Date.now()
    });

    try {
      await webpush.sendNotification(subscription, payload, {
        urgency: 'high',
        TTL: 60
      });

      console.log(`[WebPush] Successfully sent ring notification to station: ${targetStationId}`);
      res.json({
        success: true,
        delivered: true,
        targetStationId
      });
    } catch (err: any) {
      console.warn(`[WebPush] Failed sending push to ${targetStationId}:`, err?.statusCode || err?.message);

      // If subscription expired or was invalidated by browser/FCM/APNS (404/410), clean it up
      if (err?.statusCode === 404 || err?.statusCode === 410) {
        delete subscriptionsMap[targetStationId];
        saveSubscriptions();
      }

      res.status(502).json({
        success: false,
        reason: 'push_failed',
        statusCode: err?.statusCode,
        message: 'שליחת הודעת ה-Push נכשלה או שהמינוי פג תוקף'
      });
    }
  });

  // Endpoint 3: Stop nagging alert if caller hung up before answer
  app.post('/api/stop-ring', async (req: Request, res: Response) => {
    const { targetStationId } = req.body;
    if (!targetStationId) {
      res.status(400).json({ error: 'Missing targetStationId' });
      return;
    }

    const subscription = subscriptionsMap[targetStationId];
    if (subscription) {
      const payload = JSON.stringify({
        type: 'CANCEL_CALL',
        title: 'שיחה בוטלה',
        body: 'המתקשר ביטל את השיחה'
      });
      try {
        await webpush.sendNotification(subscription, payload, {
          urgency: 'normal',
          TTL: 10
        });
      } catch {
        // Ignore cancellation errors
      }
    }
    res.json({ success: true });
  });

  // ===================== WI-FI NEARBY DISCOVERY =====================
  interface NearbyDevice {
    stationId: string;
    userName: string;
    clientIp: string;
    lastSeen: number;
  }
  const nearbyDevices = new Map<string, NearbyDevice>();

  // Heartbeat & discover peers on the same local network / router (same external IP)
  app.post('/api/nearby', (req: Request, res: Response) => {
    const { stationId, userName } = req.body;
    if (!stationId) {
      res.status(400).json({ error: 'Missing stationId' });
      return;
    }

    // Extract client IP address accurately (handling reverse proxy x-forwarded-for)
    const rawIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || req.ip || '127.0.0.1';
    const clientIp = typeof rawIp === 'string'
      ? rawIp.split(',')[0].trim()
      : (Array.isArray(rawIp) ? rawIp[0].trim() : '127.0.0.1');

    const now = Date.now();

    // Clean up stale devices inactive for more than 35 seconds
    for (const [id, dev] of nearbyDevices.entries()) {
      if (now - dev.lastSeen > 35000) {
        nearbyDevices.delete(id);
      }
    }

    // Register / update current device heartbeat
    nearbyDevices.set(stationId, {
      stationId,
      userName: userName || stationId,
      clientIp,
      lastSeen: now
    });

    // Return other active devices on the same IP / local network
    const peersOnSameNetwork: Array<{ stationId: string; userName: string; clientIp: string; lastSeen: number }> = [];
    for (const dev of nearbyDevices.values()) {
      if (dev.stationId !== stationId && dev.clientIp === clientIp) {
        peersOnSameNetwork.push(dev);
      }
    }

    res.json({
      success: true,
      clientIp,
      devices: peersOnSameNetwork
    });
  });

  // ===================== FRONTEND SERVING =====================
  if (!isProd) {
    // Mount Vite middlewares in development
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Klypt Full-Stack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting server:', err);
  process.exit(1);
});
