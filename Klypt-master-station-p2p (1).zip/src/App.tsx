/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import Peer, { type DataConnection, type MediaConnection } from 'peerjs';
import {
  Phone,
  PhoneOff,
  Copy,
  Check,
  Globe,
  Users,
  Video,
  Film,
  MessageSquare,
  Volume2,
  VolumeX,
  Bell,
  ArrowRight,
  ArrowLeft,
  UserCheck,
  Loader2,
  BellRing,
  ShieldCheck,
  Sparkles,
  Radio,
  Share2,
  Zap,
  Lock,
  ArrowUpRight,
  Network,
  Key,
  ChevronRight,
  ChevronLeft,
  Edit3,
  Dices,
  RefreshCw,
  Hash,
  PenTool,
  Wifi
} from 'lucide-react';

import {
  PeerContact,
  NetworkInfo,
  PeerNetworkInfo,
  ChatMessage,
  FileTransferProgress,
  GroupParticipant,
  WhiteboardStroke,
  NearbyDevice
} from './types';
import { copyToClipboard } from './utils/clipboard';
import {
  fetchPublicNetworkInfo,
  gatherWebRtcIceInfo,
  isIpAddress,
  extractCleanIp,
  ipToPeerId,
  peerIdToIp
} from './utils/network';
import { sound } from './utils/sound';
import { VideoPlayerSection } from './components/VideoPlayerSection';
import { CallOverlay } from './components/CallOverlay';
import { ChatSection } from './components/ChatSection';
import { ContactsSection } from './components/ContactsSection';
import { WhiteboardSection } from './components/WhiteboardSection';
import { CustomIdModal } from './components/CustomIdModal';
import { IncomingCallModal } from './components/IncomingCallModal';
import { NicknamePromptModal } from './components/NicknamePromptModal';
import { TermsAndSettingsModal } from './components/TermsAndSettingsModal';
import { BridgeModal } from './components/BridgeModal';
import {
  initServiceWorker,
  showHomeScreenNotification,
  startNaggingCallAlert,
  stopNaggingCallAlert,
  subscribeToWebPush,
  sendPushRing,
  stopPushRing
} from './utils/notifications';

const STORAGE = {
  stationId: 'ms_persistent_station_id',
  userName: 'ms_my_name',
  contacts: 'ms_saved_friends_v7',
  sound: 'ms_sound_v7'
};

export default function App() {
  // Identity state
  const [myId, setMyId] = useState<string>('');
  const [myIp, setMyIp] = useState<string>('');
  const [userName, setUserName] = useState<string>('אני');
  const [linkCopied, setLinkCopied] = useState<boolean>(false);
  const [idCopied, setIdCopied] = useState<boolean>(false);
  const [shareMode, setShareMode] = useState<'id' | 'link'>('id');
  const [status, setStatus] = useState<string>('מתחבר לרשת...');
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [hasNotifPermission, setHasNotifPermission] = useState<boolean>(false);
  const [hasAcceptedTerms, setHasAcceptedTerms] = useState<boolean>(() => {
    return localStorage.getItem('ms_terms_accepted_v1') === 'true';
  });
  const [showTermsModal, setShowTermsModal] = useState<boolean>(false);

  // Web Push Wake-Up & Retry Refs
  const activeDialTargetIdRef = useRef<string | null>(null);
  const wakeUpRetryTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const wakeUpTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const wakeUpActiveContactRef = useRef<PeerContact | undefined>(undefined);

  // Bridge Mode & Group Chat State
  const [showBridgeModal, setShowBridgeModal] = useState<boolean>(false);
  const [groupParticipants, setGroupParticipants] = useState<GroupParticipant[]>([]);
  const groupParticipantsRef = useRef<GroupParticipant[]>([]);
  groupParticipantsRef.current = groupParticipants;

  // Multi-peer active connections map (peerId -> DataConnection)
  const groupConnsRef = useRef<Map<string, DataConnection>>(new Map());
  // Set of seen message IDs to prevent relay duplication and loops
  const seenMsgIdsRef = useRef<Set<string>>(new Set());

  // Calling & In-Session state
  const [activePage, setActivePage] = useState<'lounge' | 'chat' | 'watch' | 'call' | 'board' | 'contacts'>('lounge');
  const [activeTab, setActiveTab] = useState<'video' | 'call' | 'chat' | 'board'>('video');

  // Wi-Fi Nearby discovery state
  const [nearbyDevices, setNearbyDevices] = useState<NearbyDevice[]>([]);

  // MSE Video streaming chunk state
  const [incomingVideoChunk, setIncomingVideoChunk] = useState<{ buffer: ArrayBuffer; isLast?: boolean; mime?: string; name?: string } | null>(null);

  // Collaborative Whiteboard state
  const [incomingWhiteboardStroke, setIncomingWhiteboardStroke] = useState<WhiteboardStroke | null>(null);
  const [incomingWhiteboardClear, setIncomingWhiteboardClear] = useState<boolean>(false);

  // Custom Station ID editor state (supports pure numbers or custom text)
  const [isEditingId, setIsEditingId] = useState<boolean>(false);
  const [customIdInput, setCustomIdInput] = useState<string>('');
  const [idEditError, setIdEditError] = useState<string | null>(null);
  const [idSuccessMsg, setIdSuccessMsg] = useState<string | null>(null);
  const touchStartXRef = useRef<number | null>(null);
  const touchStartYRef = useRef<number | null>(null);
  const [connectedFriend, setConnectedFriend] = useState<PeerContact | null>(null);
  const [outgoingCallTarget, setOutgoingCallTarget] = useState<string | null>(null);
  const [incomingCall, setIncomingCall] = useState<{
    callerId: string;
    callerName?: string;
    callerIp: string;
    callerCity?: string;
    callerCountry?: string;
  } | null>(null);

  const [offlinePeerAlert, setOfflinePeerAlert] = useState<string | null>(null);

  // Prompt to nickname newly connected friend
  const [newPeerToNickname, setNewPeerToNickname] = useState<{
    peerId: string;
    peerIp: string;
    peerNetwork?: PeerNetworkInfo | null;
    initialName?: string;
  } | null>(null);

  // Manual connect input on main lounge
  const [directConnectInput, setDirectConnectInput] = useState<string>('');

  // Contacts & Chat
  const [contacts, setContacts] = useState<PeerContact[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [fileProgress, setFileProgress] = useState<FileTransferProgress | null>(null);

  // Network Telemetry
  const [myNetwork, setMyNetwork] = useState<NetworkInfo>({
    publicIp: '',
    localCandidates: [],
    online: navigator.onLine,
    isLoading: true
  });
  const [peerNetwork, setPeerNetwork] = useState<PeerNetworkInfo | null>(null);

  // Media Call state
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [incomingVideoStream, setIncomingVideoStream] = useState<MediaStream | null>(null);
  const [isInCall, setIsInCall] = useState<boolean>(false);
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(false);
  const [isVideoMuted, setIsVideoMuted] = useState<boolean>(false);

  // WebRTC references
  const peerRef = useRef<Peer | null>(null);
  const connRef = useRef<DataConnection | null>(null);
  const mediaCallRef = useRef<MediaConnection | null>(null);
  const activeIncomingFileRef = useRef<{
    id: string;
    name: string;
    size: number;
    mime: string;
    chunks: BlobPart[];
    received: number;
    startTime: number;
    lastCalcTime: number;
    lastCalcBytes: number;
  } | null>(null);

  // Mutable refs to prevent any infinite re-render loops in event handlers
  const userNameRef = useRef(userName);
  userNameRef.current = userName;

  const myIpRef = useRef(myIp);
  myIpRef.current = myIp;

  const myNetworkRef = useRef(myNetwork);
  myNetworkRef.current = myNetwork;

  const contactsRef = useRef(contacts);
  contactsRef.current = contacts;

  const outgoingCallTargetRef = useRef(outgoingCallTarget);
  outgoingCallTargetRef.current = outgoingCallTarget;

  // Shareable link that you send to your friend once
  const shareableUrl = myId
    ? `${window.location.origin}${window.location.pathname}?peer=${encodeURIComponent(myId)}`
    : '';

  // System logging helper
  const addLogMessage = useCallback((text: string, sender: 'me' | 'peer' | 'sys' | 'system' = 'system') => {
    const normalized: 'me' | 'peer' | 'system' = sender === 'sys' ? 'system' : sender;
    setMessages((prev) => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2) + Date.now(),
        sender: normalized,
        text,
        timestamp: Date.now()
      }
    ]);
  }, []);

  // Broadcast data payload to all connected peers in the group (excluding optional sender)
  const broadcastToGroup = useCallback((data: any, excludePeerId?: string) => {
    groupConnsRef.current.forEach((c, peerId) => {
      if (peerId !== excludePeerId && c && c.open) {
        try {
          c.send(data);
        } catch (e) {
          console.warn('Failed broadcasting to peer:', peerId, e);
        }
      }
    });
  }, []);

  // Load saved settings & contacts
  useEffect(() => {
    const savedName = localStorage.getItem(STORAGE.userName);
    if (savedName) setUserName(savedName);

    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE.contacts) || '[]');
      if (Array.isArray(saved)) setContacts(saved);
    } catch {
      // Ignore
    }

    const savedSound = localStorage.getItem(STORAGE.sound);
    if (savedSound !== null) {
      const en = savedSound === 'true';
      setSoundEnabled(en);
      sound.enabled = en;
    }

    if ('Notification' in window) {
      setHasNotifPermission(Notification.permission === 'granted');
    }
  }, []);

  // Wi-Fi Nearby discovery heartbeat every 15s to discover peers on the same local network
  useEffect(() => {
    if (!myId) return;

    const pingNearby = async () => {
      try {
        const res = await fetch('/api/nearby', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            stationId: myId,
            userName: userName || myId
          })
        });
        if (res.ok) {
          const data = await res.json();
          if (data && Array.isArray(data.devices)) {
            setNearbyDevices(data.devices);
          }
        }
      } catch {
        // Silently ignore network heartbeat errors
      }
    };

    pingNearby();
    const interval = setInterval(pingNearby, 15000);
    return () => clearInterval(interval);
  }, [myId, userName]);

  // Unlock audio on first user touch/click anywhere on page
  useEffect(() => {
    const unlockAudio = () => {
      sound.unlock();
    };
    window.addEventListener('pointerdown', unlockAudio, { once: true });
    window.addEventListener('keydown', unlockAudio, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlockAudio);
      window.removeEventListener('keydown', unlockAudio);
    };
  }, []);

  // Adaptive screen fit: collect screen metrics and apply CSS variables + safe-area for any device/browser
  useEffect(() => {
    const applyScreenMetrics = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const dpr = window.devicePixelRatio || 1;
      const root = document.documentElement;
      root.style.setProperty('--screen-w', `${w}px`);
      root.style.setProperty('--screen-h', `${h}px`);
      root.style.setProperty('--dpr', String(dpr));
      root.style.setProperty('--safe-top', 'env(safe-area-inset-top, 0px)');
      root.style.setProperty('--safe-bottom', 'env(safe-area-inset-bottom, 0px)');
      root.style.setProperty('--safe-left', 'env(safe-area-inset-left, 0px)');
      root.style.setProperty('--safe-right', 'env(safe-area-inset-right, 0px)');
      // Prevent horizontal overflow glitches on narrow screens
      root.style.setProperty('--app-max-w', w < 640 ? '100%' : '80rem');
      // Orientation helper
      root.dataset.orientation = w > h ? 'landscape' : 'portrait';
      root.dataset.narrow = w < 420 ? 'true' : 'false';
    };
    applyScreenMetrics();
    window.addEventListener('resize', applyScreenMetrics, { passive: true });
    window.addEventListener('orientationchange', applyScreenMetrics, { passive: true });
    // visualViewport for mobile browser chrome changes
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', applyScreenMetrics, { passive: true });
    }
    return () => {
      window.removeEventListener('resize', applyScreenMetrics);
      window.removeEventListener('orientationchange', applyScreenMetrics);
      if (window.visualViewport) {
        window.visualViewport.removeEventListener('resize', applyScreenMetrics);
      }
    };
  }, []);

  // Dynamic Browser Tab Title & Mobile Vibration while receiving an incoming call (Nagging loop)
  useEffect(() => {
    if (!incomingCall) {
      document.title = 'Klypt - תקשורת חברתית ישירה';
      stopNaggingCallAlert();
      return;
    }

    const callerName = incomingCall.callerName || 'חבר';

    // Repeating persistent vibration pulses every 2 seconds
    const vibrateCycle = () => {
      if ('vibrate' in navigator) {
        try {
          navigator.vibrate([500, 200, 500, 200, 600]);
        } catch {}
      }
    };
    vibrateCycle();
    const vibInterval = setInterval(vibrateCycle, 2000);

    // Rapid urgent flashing of document title (every 450ms)
    let isToggled = false;
    const titleInterval = setInterval(() => {
      isToggled = !isToggled;
      document.title = isToggled
        ? `🔴 שיחה נכנסת מ-${callerName}! 📞`
        : `⚡ לחץ להצטרפות לשיחה! | Klypt`;
    }, 450);

    return () => {
      clearInterval(vibInterval);
      clearInterval(titleInterval);
      document.title = 'Klypt - תקשורת חברתית ישירה';
      stopNaggingCallAlert();
    };
  }, [incomingCall]);

  const saveContacts = (updated: PeerContact[]) => {
    setContacts(updated);
    try {
      localStorage.setItem(STORAGE.contacts, JSON.stringify(updated));
    } catch {
      // Ignore
    }
  };

  // Wire DataConnection with background telemetry exchange & Bridge Group Mesh Relay
  const wireDataConnection = useCallback(
    (conn: DataConnection, targetFriend?: PeerContact) => {
      // Register connection in multi-peer group map
      groupConnsRef.current.set(conn.peer, conn);

      // Also set primary connection ref if not yet set
      if (!connRef.current || !connRef.current.open) {
        connRef.current = conn;
      }

      conn.on('open', () => {
        // Connected! Clear any active Web Push wake-up retry timers
        if (wakeUpRetryTimerRef.current) {
          clearInterval(wakeUpRetryTimerRef.current);
          wakeUpRetryTimerRef.current = null;
        }
        if (wakeUpTimeoutRef.current) {
          clearTimeout(wakeUpTimeoutRef.current);
          wakeUpTimeoutRef.current = null;
        }
        activeDialTargetIdRef.current = null;
        sound.stopRingtone();
        sound.playConnect();
        setOutgoingCallTarget(null);
        setOfflinePeerAlert(null);
        setIsConnected(true);
        setStatus('מחובר');

        // Collect our telemetry to send to the friend in the background
        conn.send({
          type: 'handshake_telemetry',
          name: userNameRef.current,
          publicIp: myIpRef.current || myNetworkRef.current.publicIp,
          country: myNetworkRef.current.country,
          city: myNetworkRef.current.city,
          org: myNetworkRef.current.org,
          platform: navigator.platform,
          screen: `${window.screen.width}x${window.screen.height}`,
          language: navigator.language,
          isCalling: !!outgoingCallTargetRef.current,
          knownPeers: Array.from(groupConnsRef.current.keys())
        });
      });

      conn.on('data', (raw: unknown) => {
        const msg = raw as Record<string, any>;
        if (!msg || typeof msg !== 'object') return;

        // Realtime Mood Status update from friend
        if (msg.type === 'status_mood' && typeof msg.mood === 'string') {
          const updatedMood = msg.mood;
          setPeerNetwork((prev) => (prev ? { ...prev, mood: updatedMood } : { publicIp: '', mood: updatedMood }));
          setConnectedFriend((prev) => (prev ? { ...prev, mood: updatedMood } : null));
          const updatedContacts = contactsRef.current.map((c) =>
            c.id === conn.peer ? { ...c, mood: updatedMood } : c
          );
          saveContacts(updatedContacts);
          sound.playPop();
          return;
        }

        // 1. Background Telemetry received!
        if (msg.type === 'handshake_telemetry') {
          const remoteIp = msg.publicIp || peerIdToIp(conn.peer) || '';
          const remoteNetwork: PeerNetworkInfo = {
            publicIp: remoteIp,
            country: msg.country,
            city: msg.city,
            org: msg.org,
            platform: msg.platform,
            screen: msg.screen,
            language: msg.language,
            mood: msg.mood
          };
          setPeerNetwork(remoteNetwork);

          // Find if we already have this friend saved in contacts (by permanent station ID or IP)
          const existing = contactsRef.current.find(
            (c) => c.id === conn.peer || (remoteIp && c.ip === remoteIp)
          );

          const friendName = existing?.nickname || existing?.name || msg.name || 'חבר';

          if (existing) {
            // Update last seen and network details silently (keep existing.id permanent!)
            const updated = contactsRef.current.map((c) =>
              c.id === existing.id
                ? {
                    ...c,
                    ip: remoteIp || c.ip,
                    lastSeen: Date.now(),
                    city: msg.city || c.city,
                    country: msg.country || c.country,
                    mood: msg.mood || c.mood
                  }
                : c
            );
            saveContacts(updated);
            setConnectedFriend({
              ...existing,
              ip: remoteIp || existing.ip,
              city: msg.city || existing.city,
              mood: msg.mood || existing.mood
            });
          } else {
            // Prompt user: "איך תרצה לכנות את החבר?"
            setNewPeerToNickname({
              peerId: conn.peer,
              peerIp: remoteIp,
              peerNetwork: remoteNetwork,
              initialName: msg.name || ''
            });
          }

          // Update group participants list
          const newParticipant: GroupParticipant = {
            id: conn.peer,
            name: friendName,
            ip: remoteIp,
            city: msg.city,
            joinedAt: Date.now()
          };

          setGroupParticipants((prev) => {
            const hasMe = prev.some((p) => p.isMe);
            const myEntry: GroupParticipant = {
              id: peerRef.current?.id || myId,
              name: userNameRef.current,
              ip: myIpRef.current,
              isMe: true,
              isHost: true,
              joinedAt: Date.now()
            };
            const base = hasMe ? prev : [myEntry, ...prev];
            const withoutConn = base.filter((p) => p.id !== conn.peer);
            const fullList = [...withoutConn, newParticipant];

            // If we are bridging multiple peers, synchronize full list to all peers!
            if (groupConnsRef.current.size > 1) {
              broadcastToGroup({ type: 'bridge_group_sync', participants: fullList });
            }

            return fullList;
          });

          // If this is a 3rd peer joining via Bridge, broadcast announcement to all existing members
          if (groupConnsRef.current.size > 1) {
            broadcastToGroup(
              {
                type: 'bridge_participant_joined',
                participant: newParticipant
              },
              conn.peer
            );
            addLogMessage(`🌐 ${friendName} הצטרף לשיחה הקבוצתית דרך הגשר!`, 'system');
          }

          // If friend clicked our call button (incoming call invitation)
          if (msg.isCalling) {
            sound.unlock();
            sound.startIncomingRingtone();
            setIncomingCall({
              callerId: conn.peer,
              callerName: friendName,
              callerIp: remoteIp,
              callerCity: msg.city,
              callerCountry: msg.country
            });

            // Pop native persistent nagging alert to Desktop & Mobile Home Screen through Service Worker
            startNaggingCallAlert(friendName, remoteIp);
            return;
          }

          // Direct connection from link opened
          setIsConnected(true);
          sound.playConnect();
          setStatus(groupConnsRef.current.size > 1 ? `בקבוצה (${groupConnsRef.current.size + 1} משתתפים)` : 'מחובר');
          addLogMessage(`מחובר עם ${friendName}!`, 'system');
          return;
        }

        // 2. Bridge Group Sync: full participants list update
        if (msg.type === 'bridge_group_sync' && Array.isArray(msg.participants)) {
          const syncList = msg.participants as GroupParticipant[];
          // Map 'isMe' flag according to current peer ID
          const mapped = syncList.map((p) => ({
            ...p,
            isMe: p.id === (peerRef.current?.id || myId)
          }));
          setGroupParticipants(mapped);
          setIsConnected(true);
          setStatus(`בקבוצה (${mapped.length} משתתפים)`);
          return;
        }

        // 3. Bridge Participant Joined: new 3rd person entered the bridge!
        if (msg.type === 'bridge_participant_joined' && msg.participant) {
          const p = msg.participant as GroupParticipant;
          setGroupParticipants((prev) => {
            if (prev.some((x) => x.id === p.id)) return prev;
            return [...prev, p];
          });
          sound.playConnect();
          addLogMessage(`🎉 ${p.name || 'משתתף נוסף'} הצטרף לשיחה הקבוצתית דרך הגשר!`, 'system');

          // Try to establish direct mesh connection with the new peer if not already connected
          const myCurrentId = peerRef.current?.id || myId;
          if (
            peerRef.current &&
            peerRef.current.open &&
            p.id !== myCurrentId &&
            !groupConnsRef.current.has(p.id)
          ) {
            try {
              const meshConn = peerRef.current.connect(p.id, {
                reliable: true,
                serialization: 'binary'
              });
              wireDataConnection(meshConn);
            } catch (err) {
              console.warn('Mesh direct connect error:', err);
            }
          }
          return;
        }

        // 4. Bridge Participant Left
        if (msg.type === 'bridge_participant_left' && msg.peerId) {
          setGroupParticipants((prev) => prev.filter((x) => x.id !== msg.peerId));
          addLogMessage('משתתף עזב את השיחה הקבוצתית.', 'system');
          return;
        }

        // 5. Call Answered
        if (msg.type === 'call_accepted') {
          sound.stopRingtone();
          sound.playConnect();
          setOutgoingCallTarget(null);
          setIsConnected(true);
          setStatus('בשיחה');
          addLogMessage('החבר קיבל את השיחה!', 'peer');
          return;
        }

        // 6. Call Declined
        if (msg.type === 'call_declined') {
          sound.stopRingtone();
          sound.playBusyTone();
          setOutgoingCallTarget(null);
          setStatus('השיחה נדחתה');
          addLogMessage('החבר דחה את השיחה כרגע', 'system');
          setTimeout(() => {
            disconnect();
          }, 1500);
          return;
        }

        // 7. Chat Message with Bridge Mesh Relay
        if (msg.type === 'chat_text') {
          const msgId = msg.id || `${conn.peer}_${Date.now()}`;
          // Idempotency check: prevent duplicate display or relay feedback loop
          if (seenMsgIdsRef.current.has(msgId)) return;
          seenMsgIdsRef.current.add(msgId);

          sound.playMessage();
          const senderDisplayName = msg.senderName || 'חבר';

          setMessages((prev) => [
            ...prev,
            {
              id: msgId,
              sender: 'peer',
              senderName: senderDisplayName,
              senderId: msg.senderId || conn.peer,
              text: msg.text,
              timestamp: msg.timestamp || Date.now(),
              isBridgeRelayed: msg.isBridgeRelayed
            }
          ]);

          // Bridge Relay: forward to other connected peers in the group who didn't receive it directly!
          broadcastToGroup(
            {
              ...msg,
              isBridgeRelayed: true
            },
            conn.peer
          );
          return;
        }

        // 8. File transfer header
        if (msg.type === 'file_header') {
          activeIncomingFileRef.current = {
            id: msg.id,
            name: msg.name,
            size: msg.size,
            mime: msg.mime || 'application/octet-stream',
            chunks: [],
            received: 0,
            startTime: Date.now(),
            lastCalcTime: Date.now(),
            lastCalcBytes: 0
          };
          setFileProgress({
            id: msg.id,
            name: msg.name,
            size: msg.size,
            transferred: 0,
            speedBps: 0,
            progress: 0,
            direction: 'receiving',
            status: 'transferring',
            mime: msg.mime
          });
          return;
        }

        // 9. File chunk
        if (msg.type === 'file_chunk' && activeIncomingFileRef.current) {
          const fileMeta = activeIncomingFileRef.current;
          const chunkData = msg.buffer as BlobPart;
          const byteLength = (msg.buffer as { byteLength?: number })?.byteLength || 0;

          fileMeta.chunks.push(chunkData);
          fileMeta.received += byteLength;

          // Forward to VideoPlayerSection for real-time MSE streaming if video
          if (fileMeta.mime.startsWith('video/') && msg.buffer) {
            setIncomingVideoChunk({
              buffer: msg.buffer as ArrayBuffer,
              isLast: !!msg.isLast,
              mime: fileMeta.mime,
              name: fileMeta.name
            });
          }

          const pct = Math.min(100, Math.round((fileMeta.received / fileMeta.size) * 100));
          setFileProgress((prev) =>
            prev ? { ...prev, transferred: fileMeta.received, progress: pct } : null
          );

          if (msg.isLast) {
            const blob = new Blob(fileMeta.chunks, { type: fileMeta.mime });
            const blobUrl = URL.createObjectURL(blob);
            const isVideo = fileMeta.mime.startsWith('video/');

            setFileProgress({
              id: fileMeta.id,
              name: fileMeta.name,
              size: fileMeta.size,
              transferred: fileMeta.size,
              progress: 100,
              speedBps: 0,
              direction: 'receiving',
              status: 'completed',
              url: blobUrl,
              mime: fileMeta.mime
            });

            sound.playFileReady();

            setMessages((prev) => [
              ...prev,
              {
                id: Math.random().toString(36).substring(2) + Date.now(),
                sender: 'peer',
                senderName: msg.senderName || 'חבר',
                text: `קובץ: ${fileMeta.name}`,
                timestamp: Date.now(),
                file: {
                  name: fileMeta.name,
                  size: fileMeta.size,
                  url: blobUrl,
                  mime: fileMeta.mime,
                  isVideo
                }
              }
            ]);

            activeIncomingFileRef.current = null;
          }
          return;
        }

        // 10. Whiteboard Draw
        if (msg.type === 'whiteboard_draw' && msg.stroke) {
          setIncomingWhiteboardStroke(msg.stroke);
          broadcastToGroup(msg, conn.peer);
          return;
        }

        // 11. Whiteboard Clear
        if (msg.type === 'whiteboard_clear') {
          setIncomingWhiteboardClear(true);
          setTimeout(() => setIncomingWhiteboardClear(false), 300);
          broadcastToGroup(msg, conn.peer);
          return;
        }

        // 12. Bye / Disconnect
        if (msg.type === 'bye') {
          addLogMessage('החבר התנתק מהשיחה.', 'system');
          disconnect();
        }
      });

      conn.on('close', () => {
        // Remove from active group map
        groupConnsRef.current.delete(conn.peer);

        // Update participants list
        const leavingPeer = groupParticipantsRef.current.find((p) => p.id === conn.peer);
        const leavingName = leavingPeer?.name || 'משתתף';
        setGroupParticipants((prev) => prev.filter((p) => p.id !== conn.peer));

        // If other peers still connected in group, stay online!
        if (groupConnsRef.current.size > 0) {
          addLogMessage(`${leavingName} התנתק מהשיחה הקבוצתית.`, 'system');
          broadcastToGroup({ type: 'bridge_participant_left', peerId: conn.peer });
          // Ensure connRef points to one of the remaining active connections
          const nextConn = groupConnsRef.current.values().next().value;
          if (nextConn) connRef.current = nextConn;
        } else {
          sound.stopRingtone();
          setOutgoingCallTarget(null);
          setIsConnected(false);
          setIncomingCall(null);
          setStatus('מנותק');
          sound.playDisconnect();
          addLogMessage('כל החיבורים נסגרו.', 'system');
        }
      });

      conn.on('error', (err) => {
        sound.stopRingtone();
        setOutgoingCallTarget(null);
        console.error('DataConnection error:', err);
      });
    },
    [addLogMessage, broadcastToGroup, myId]
  );

  // Peer connection lifecycle & heartbeat guards
  const isPeerOpenRef = useRef<boolean>(false);
  const isReconnectingRef = useRef<boolean>(false);
  const heartbeatTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const pendingTargetRef = useRef<{ cleanId: string; friendContact?: PeerContact } | null>(null);

  const stopHeartbeat = useCallback(() => {
    if (heartbeatTimerRef.current) {
      clearInterval(heartbeatTimerRef.current);
      heartbeatTimerRef.current = null;
    }
  }, []);

  const startHeartbeat = useCallback((peer: Peer) => {
    stopHeartbeat();
    heartbeatTimerRef.current = setInterval(() => {
      if (!peer || peer.destroyed || !peer.open || peer.disconnected) return;
      try {
        const sock = (peer as any).socket?._socket;
        if (sock && sock.readyState === WebSocket.OPEN) {
          // Send lightweight keep-alive ping to prevent 0.peerjs.com from closing idle socket
          sock.send(JSON.stringify({ type: 'HEARTBEAT' }));
        }
      } catch {}
    }, 15000);
  }, [stopHeartbeat]);

  const wireDataConnectionRef = useRef(wireDataConnection);
  wireDataConnectionRef.current = wireDataConnection;

  // Safe reconnect function that never calls peer.reconnect() when !peer.open or while busy
  const safeReconnect = useCallback((stationId?: string) => {
    const currentPeer = peerRef.current;
    if (!currentPeer || currentPeer.destroyed) return;
    if (isReconnectingRef.current) return;

    isReconnectingRef.current = true;
    const targetStationId = stationId || localStorage.getItem(STORAGE.stationId) || currentPeer.id;

    setTimeout(() => {
      isReconnectingRef.current = false;
      const p = peerRef.current;
      if (!p || p.destroyed) return;

      // If peer is disconnected and not destroyed, invoke peer.reconnect()
      if (p.disconnected && !p.destroyed) {
        try {
          p.reconnect();
          return;
        } catch {
          // Fall back to clean re-init
        }
      }

      // If peer was never opened or reconnect failed, re-initialize cleanly with the same persistent station ID
      if (targetStationId && (!p.open || p.disconnected)) {
        initStationRef.current(targetStationId);
      }
    }, 1500);
  }, []);

  // Initialize Station Peer instance (One persistent station ID per browser)
  const initStation = useCallback((stationId: string) => {
    stopHeartbeat();
    isPeerOpenRef.current = false;

    if (peerRef.current) {
      try {
        peerRef.current.destroy();
      } catch {}
      peerRef.current = null;
    }

    setMyId(stationId);

    const peer = new Peer(stationId, {
      debug: 0,
      host: '0.peerjs.com',
      port: 443,
      path: '/',
      secure: true,
      config: {
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
          { urls: 'stun:global.stun.twilio.com:3478' }
        ]
      }
    });

    peerRef.current = peer;

    peer.on('open', (id) => {
      isPeerOpenRef.current = true;
      isReconnectingRef.current = false;
      startHeartbeat(peer);

      setMyId(id);
      setStatus('מוכן לשיחה');

      // Initialize self in participants list
      setGroupParticipants([
        {
          id,
          name: userNameRef.current,
          ip: myIpRef.current,
          isMe: true,
          isHost: true,
          joinedAt: Date.now()
        }
      ]);

      // Process any pending queued connection if user clicked call before peer opened
      if (pendingTargetRef.current) {
        const queued = pendingTargetRef.current;
        pendingTargetRef.current = null;
        connectToFriendIdRef.current(queued.cleanId, queued.friendContact);
        return;
      }

      // Auto-connect if URL has ?incomingCallFrom=..., ?bridge=1 or ?peer=...
      const params = new URLSearchParams(window.location.search);
      const incomingCallFrom = params.get('incomingCallFrom');
      const callerNameParam = params.get('callerName') || 'חבר';
      const isBridgeMode = params.get('bridge') === '1';
      const bridgeHost = params.get('host');
      const bridgeTokenParam = params.get('token');
      const urlPeer = params.get('peer') || params.get('id');

      // Auto-subscribe to Web Push with this station ID so device can be reached
      subscribeToWebPush(id).catch(() => {});

      if (incomingCallFrom && incomingCallFrom !== id) {
        try {
          window.history.replaceState({}, document.title, window.location.pathname);
        } catch {}
        addLogMessage(`מענה אוטומטי לשיחה נכנסת מ-${callerNameParam}...`, 'system');
        connectToFriendIdRef.current(incomingCallFrom);
      } else if (isBridgeMode && bridgeHost && bridgeHost !== id) {
        try {
          window.history.replaceState({}, document.title, window.location.pathname);
        } catch {}
        addLogMessage('מתחבר לשיחה קבוצתית דרך גשר (Bridge)...', 'system');
        connectToFriendIdRef.current(bridgeHost);
      } else if (urlPeer && urlPeer !== id) {
        try {
          window.history.replaceState({}, document.title, window.location.pathname);
        } catch {}
        connectToFriendIdRef.current(urlPeer);
      }
    });

    peer.on('connection', (c) => {
      wireDataConnectionRef.current(c);
    });

    peer.on('call', (call) => {
      const isLiveStream = call.metadata && call.metadata.type === 'video-stream';

      if (isLiveStream) {
        call.answer();
        call.on('stream', (stream) => {
          setIncomingVideoStream(stream);
          setActiveTab('video');
        });
        return;
      }

      navigator.mediaDevices
        .getUserMedia({ video: true, audio: true })
        .then((stream) => {
          setLocalStream(stream);
          call.answer(stream);
          mediaCallRef.current = call;
          setIsInCall(true);

          call.on('stream', (remote) => {
            setRemoteStream(remote);
          });

          call.on('close', () => {
            endCall();
          });
        })
        .catch(() => {
          navigator.mediaDevices
            .getUserMedia({ video: false, audio: true })
            .then((audioStream) => {
              setLocalStream(audioStream);
              call.answer(audioStream);
              mediaCallRef.current = call;
              setIsInCall(true);

              call.on('stream', (remote) => {
                setRemoteStream(remote);
              });
            })
            .catch((e) => {
              console.warn('Device access failed:', e);
            });
        });
    });

    peer.on('error', (err: any) => {
      const type = err?.type || '';
      const message = String(err?.message || err || '');

      // 1. In a hurry error - PeerJS emits this when reconnect is triggered while initial connection is in flight.
      if (message.includes('In a hurry') || message.includes('initial connection')) {
        return;
      }

      // 2. Lost connection to server - Cloud WebSocket idle/dropped
      if (
        message.includes('Lost connection to server') ||
        type === 'network' ||
        type === 'server-error' ||
        type === 'socket-error' ||
        type === 'socket-closed'
      ) {
        setStatus('מחדש חיבור לרשת...');
        safeReconnect(stationId);
        return;
      }

      // 3. Peer is offline or asleep -> Trigger Web Push wake-up & retry loop (Wake up and wait)
      if (type === 'peer-unavailable' || message.includes('Could not connect to peer')) {
        const targetStationId = activeDialTargetIdRef.current;
        if (targetStationId) {
          console.log('[WebPush] Target peer is offline/asleep. Sending Web Push wake-up:', targetStationId);
          setStatus('החבר לא מקוון כעת. שולח התראת Web Push להעיר את המכשיר שלו...');

          // Fire Web Push ring to server
          sendPushRing(
            targetStationId,
            stationId,
            userNameRef.current,
            myIpRef.current
          ).then((res) => {
            if (res.success) {
              setStatus('נשלחה התראת Push למכשיר של החבר! ממתין שייכנס (צלצול פעיל)...');
            } else {
              setStatus('החבר לא מחובר (טרם אישר התראות Push בדפדפן שלו)');
            }
          });

          // Keep outgoing dial tone playing
          sound.startOutgoingTone();

          // Start retry loop every 3 seconds to catch the friend as soon as their browser opens
          if (!wakeUpRetryTimerRef.current) {
            wakeUpRetryTimerRef.current = setInterval(() => {
              if (!activeDialTargetIdRef.current || !peerRef.current || !peerRef.current.open) return;
              console.log('[WakeUp Retry] Attempting reconnection to:', activeDialTargetIdRef.current);
              try {
                const c = peerRef.current.connect(activeDialTargetIdRef.current, {
                  reliable: true,
                  serialization: 'binary'
                });
                wireDataConnection(c, wakeUpActiveContactRef.current);
              } catch (e) {
                console.warn('Retry connect error:', e);
              }
            }, 3000);
          }

          // Timeout after 40 seconds
          if (!wakeUpTimeoutRef.current) {
            wakeUpTimeoutRef.current = setTimeout(() => {
              if (wakeUpRetryTimerRef.current) {
                clearInterval(wakeUpRetryTimerRef.current);
                wakeUpRetryTimerRef.current = null;
              }
              wakeUpTimeoutRef.current = null;
              sound.stopRingtone();
              sound.playBusyTone();
              setOutgoingCallTarget(null);
              setStatus('החבר לא נענה להתראת ה-Push');
              setOfflinePeerAlert('החבר לא נענה להתראת ה-Push בתוך 40 שניות. נסה שוב מאוחר יותר.');
              if (activeDialTargetIdRef.current) {
                stopPushRing(activeDialTargetIdRef.current);
                activeDialTargetIdRef.current = null;
              }
            }, 40000);
          }
          return;
        }

        sound.stopRingtone();
        sound.playBusyTone();
        setOutgoingCallTarget(null);
        setStatus('החבר אינו מחובר כרגע');
        setOfflinePeerAlert('החבר אינו מחובר כרגע. ודא שהמזהה שלו נכון.');
        return;
      }

      sound.stopRingtone();
      setOutgoingCallTarget(null);

      // 4. Station ID collision (e.g. rapid page refresh before server cleans socket)
      if (type === 'unavailable-id') {
        const freshId = 'user_' + Math.random().toString(36).substring(2, 8) + Date.now().toString(36).slice(-3);
        localStorage.setItem(STORAGE.stationId, freshId);
        initStationRef.current(freshId);
        return;
      }

      setStatus('שגיאת תקשורת');
    });

    peer.on('disconnected', () => {
      isPeerOpenRef.current = false;
      stopHeartbeat();
      setStatus('החיבור נותק, מתחבר מחדש...');
      safeReconnect(stationId);
    });

    peer.on('close', () => {
      isPeerOpenRef.current = false;
      stopHeartbeat();
      setStatus('מנותק');
    });
  }, [addLogMessage, myId, safeReconnect, startHeartbeat, stopHeartbeat]);

  const initStationRef = useRef(initStation);
  initStationRef.current = initStation;

  // Connect / Call Friend (Supports Station ID, IP, URL, or BRIDGE Token!)
  const connectToFriendId = useCallback((targetId: string, friendContact?: PeerContact) => {
    let cleanId = (targetId || '').trim();
    if (!cleanId) return;

    // Detect Bridge Token directly e.g. BRIDGE-eyJob3N0...
    if (cleanId.startsWith('BRIDGE-')) {
      try {
        const b64 = cleanId.replace('BRIDGE-', '').trim();
        const json = atob(b64);
        const payload = JSON.parse(json);
        if (payload.host) {
          cleanId = payload.host;
          addLogMessage('מפענח טוקן גשר ומתחבר לקבוצה...', 'system');
        }
      } catch (err) {
        console.warn('Failed parsing bridge token:', err);
      }
    }

    try {
      if (cleanId.startsWith('http://') || cleanId.startsWith('https://') || cleanId.includes('?')) {
        const u = new URL(cleanId, window.location.href);
        const host = u.searchParams.get('host');
        const token = u.searchParams.get('token');

        if (token && token.startsWith('BRIDGE-')) {
          try {
            const b64 = token.replace('BRIDGE-', '').trim();
            const payload = JSON.parse(atob(b64));
            if (payload.host) cleanId = payload.host;
          } catch {}
        } else if (host) {
          cleanId = host.trim();
        } else {
          const p = u.searchParams.get('peer') || u.searchParams.get('id');
          if (p) cleanId = p.trim();
        }
      }
    } catch {}

    if (cleanId === myId) {
      setOfflinePeerAlert('זהו הקישור האישי שלך! שלח אותו לחבר כדי שיתחבר אליך.');
      return;
    }

    setOfflinePeerAlert(null);

    // Track active target for Web Push wake-up retry
    activeDialTargetIdRef.current = cleanId;
    wakeUpActiveContactRef.current = friendContact;

    // If Peer is still negotiating initial connection or disconnected, queue it instead of looping rapidly
    if (!peerRef.current || !peerRef.current.open || peerRef.current.disconnected) {
      pendingTargetRef.current = { cleanId, friendContact };
      setStatus('מתחבר לרשת...');
      if (!isReconnectingRef.current && (!peerRef.current || peerRef.current.disconnected)) {
        safeReconnect();
      }
      return;
    }

    const targetDisplayName = friendContact?.nickname || friendContact?.name || cleanId;
    setOutgoingCallTarget(targetDisplayName);
    sound.startOutgoingTone();
    setStatus(`מחייג אל ${targetDisplayName}...`);

    try {
      const newConn = peerRef.current.connect(cleanId, {
        reliable: true,
        serialization: 'binary'
      });
      wireDataConnection(newConn, friendContact);
    } catch (e) {
      console.warn('Connect error:', e);
      setStatus('שגיאה ביצירת חיבור');
    }
  }, [addLogMessage, myId, safeReconnect, wireDataConnection]);

  const connectToFriendIdRef = useRef(connectToFriendId);
  connectToFriendIdRef.current = connectToFriendId;

  // On mount: Generate/retrieve persistent station ID and gather public network
  useEffect(() => {
    initServiceWorker();

    let id = localStorage.getItem(STORAGE.stationId);
    if (!id) {
      id = 'user_' + Math.random().toString(36).substring(2, 8) + Date.now().toString(36).slice(-3);
      localStorage.setItem(STORAGE.stationId, id);
    }

    initStationRef.current(id);

    // Listen for Service Worker auto-answer click on background notification
    const handleSwMsg = (e: MessageEvent) => {
      if (e.data?.type === 'AUTO_ANSWER_CALL' && e.data?.callerId) {
        addLogMessage(`מענה אוטומטי לשיחה מ-${e.data.callerName || 'חבר'}...`, 'system');
        connectToFriendIdRef.current(e.data.callerId);
      }
    };
    navigator.serviceWorker?.addEventListener('message', handleSwMsg);

    // Fetch IP and network silently in background
    Promise.all([fetchPublicNetworkInfo(), gatherWebRtcIceInfo()]).then(([pub, ice]) => {
      const ip = pub.publicIp || ice.stunIp || '';
      setMyIp(ip);
      setMyNetwork({
        publicIp: ip,
        country: pub.country,
        countryCode: pub.countryCode,
        city: pub.city,
        org: pub.org,
        localCandidates: ice.candidates,
        stunReflexiveIp: ice.stunIp,
        online: navigator.onLine,
        isLoading: false
      });
    });

    return () => {
      stopHeartbeat();
      navigator.serviceWorker?.removeEventListener('message', handleSwMsg);
      if (peerRef.current) {
        try {
          peerRef.current.destroy();
        } catch {}
      }
    };
  }, [addLogMessage, stopHeartbeat]);

  // Answer Incoming Call from Friend
  const handleAnswerCall = () => {
    sound.stopRingtone();
    stopNaggingCallAlert();
    sound.playConnect();

    broadcastToGroup({ type: 'call_accepted' });

    setIsConnected(true);
    setStatus(`בשיחה עם ${incomingCall?.callerName || 'חבר'}`);
    setIncomingCall(null);
  };

  // Decline Incoming Call
  const handleDeclineCall = () => {
    sound.stopRingtone();
    stopNaggingCallAlert();

    broadcastToGroup({ type: 'call_declined' });
    disconnect();

    setIncomingCall(null);
    setStatus('השיחה נדחתה');
  };

  // Cancel Outgoing Call
  const handleCancelOutgoing = () => {
    sound.stopRingtone();
    setOutgoingCallTarget(null);

    if (wakeUpRetryTimerRef.current) {
      clearInterval(wakeUpRetryTimerRef.current);
      wakeUpRetryTimerRef.current = null;
    }
    if (wakeUpTimeoutRef.current) {
      clearTimeout(wakeUpTimeoutRef.current);
      wakeUpTimeoutRef.current = null;
    }
    if (activeDialTargetIdRef.current) {
      stopPushRing(activeDialTargetIdRef.current);
      activeDialTargetIdRef.current = null;
    }

    groupConnsRef.current.forEach((c) => {
      try {
        c.close();
      } catch {}
    });
    groupConnsRef.current.clear();

    setStatus('מוכן לשיחה');
  };

  // Disconnect from Call / Group
  const disconnect = () => {
    sound.stopRingtone();
    stopNaggingCallAlert();

    broadcastToGroup({ type: 'bye' });

    groupConnsRef.current.forEach((c) => {
      try {
        c.close();
      } catch {}
    });
    groupConnsRef.current.clear();

    endCall();
    setIsConnected(false);
    setOutgoingCallTarget(null);
    setIncomingCall(null);
    setConnectedFriend(null);
    setGroupParticipants([
      {
        id: myId,
        name: userName,
        ip: myIp,
        isMe: true,
        isHost: true,
        joinedAt: Date.now()
      }
    ]);
    setStatus('מוכן לשיחה');
  };

  // Save nickname after first connection
  const handleSaveNickname = (nickname: string) => {
    if (!newPeerToNickname) return;
    const { peerId, peerIp, peerNetwork: net, initialName } = newPeerToNickname;

    const newContact: PeerContact = {
      id: peerId,
      name: initialName || nickname,
      nickname,
      ip: peerIp,
      city: net?.city,
      country: net?.country,
      platform: net?.platform,
      lastSeen: Date.now()
    };

    const updated = [newContact, ...contacts.filter((c) => c.id !== peerId)];
    saveContacts(updated);
    setConnectedFriend(newContact);
    setNewPeerToNickname(null);
    sound.playConnect();
  };

  // Voice/Video Call actions
  const startCall = (withVideo: boolean) => {
    const dest = connRef.current?.peer;
    if (!dest || !peerRef.current) return;

    navigator.mediaDevices
      .getUserMedia({ video: withVideo, audio: true })
      .then((stream) => {
        setLocalStream(stream);
        const call = peerRef.current!.call(dest, stream);
        mediaCallRef.current = call;
        setIsInCall(true);

        call.on('stream', (remote) => setRemoteStream(remote));
        call.on('close', () => endCall());
      })
      .catch((err) => alert('שגיאת התקן שיחה: ' + err.message));
  };

  const endCall = () => {
    if (localStream) {
      localStream.getTracks().forEach((t) => t.stop());
      setLocalStream(null);
    }
    setRemoteStream(null);
    if (mediaCallRef.current) {
      try {
        mediaCallRef.current.close();
      } catch {}
      mediaCallRef.current = null;
    }
    setIsInCall(false);
  };

  const handleStartLiveStream = (stream: MediaStream) => {
    const dest = connRef.current?.peer;
    if (!dest || !peerRef.current) return;
    peerRef.current.call(dest, stream, { metadata: { type: 'video-stream' } });
  };

  // Send file with backpressure to all group connections
  const sendFileWithFlowControl = async (file: File) => {
    if (groupConnsRef.current.size === 0) return;

    const fileId = Math.random().toString(36).substring(2) + Date.now();
    const chunkSize = 32 * 1024;
    const totalSize = file.size;
    let offset = 0;

    broadcastToGroup({
      type: 'file_header',
      id: fileId,
      name: file.name,
      size: totalSize,
      mime: file.type || 'application/octet-stream',
      senderName: userNameRef.current
    });

    setFileProgress({
      id: fileId,
      name: file.name,
      size: totalSize,
      transferred: 0,
      speedBps: 0,
      progress: 0,
      direction: 'sending',
      status: 'transferring',
      mime: file.type
    });

    while (offset < totalSize) {
      const slice = file.slice(offset, offset + chunkSize);
      const buffer = await slice.arrayBuffer();
      const isLast = offset + chunkSize >= totalSize;

      broadcastToGroup({
        type: 'file_chunk',
        id: fileId,
        buffer: new Uint8Array(buffer),
        isLast,
        senderName: userNameRef.current
      });

      offset += chunkSize;
      const pct = Math.min(100, Math.round((offset / totalSize) * 100));
      setFileProgress((prev) => (prev ? { ...prev, transferred: offset, progress: pct } : null));
    }

    setFileProgress((prev) => (prev ? { ...prev, status: 'completed', progress: 100 } : null));

    const localUrl = URL.createObjectURL(file);
    setMessages((prev) => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2) + Date.now(),
        sender: 'me',
        senderName: userNameRef.current,
        text: `קובץ: ${file.name}`,
        timestamp: Date.now(),
        file: {
          name: file.name,
          size: file.size,
          url: localUrl,
          mime: file.type,
          isVideo: file.type.startsWith('video/')
        }
      }
    ]);
  };

  // Send Chat message across all active peer connections
  const sendChatMessage = (text: string) => {
    if (groupConnsRef.current.size === 0) return;

    const msgId = Math.random().toString(36).substring(2) + Date.now();
    seenMsgIdsRef.current.add(msgId);

    broadcastToGroup({
      type: 'chat_text',
      id: msgId,
      text,
      senderId: myId,
      senderName: userNameRef.current,
      timestamp: Date.now()
    });

    setMessages((prev) => [
      ...prev,
      {
        id: msgId,
        sender: 'me',
        senderName: userNameRef.current,
        text,
        timestamp: Date.now()
      }
    ]);
  };

  const handleCopyId = async () => {
    if (!myId) return;
    const ok = await copyToClipboard(myId);
    if (ok) {
      setIdCopied(true);
      setTimeout(() => setIdCopied(false), 2000);
    }
  };

  const handleCopyLink = async () => {
    if (!shareableUrl) return;
    const ok = await copyToClipboard(shareableUrl);
    if (ok) {
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    }
  };

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    sound.enabled = next;
    localStorage.setItem(STORAGE.sound, String(next));
  };

  const handleDirectConnectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (directConnectInput.trim()) {
      connectToFriendId(directConnectInput.trim());
      setDirectConnectInput('');
    }
  };

  // Pages list for swipe / arrow navigation
  const APP_PAGES: { id: 'lounge' | 'chat' | 'watch' | 'call' | 'board' | 'contacts'; label: string; icon: any }[] = [
    { id: 'lounge', label: 'טרקלין וחיוג', icon: Sparkles },
    { id: 'chat', label: "צ'אט והודעות", icon: MessageSquare },
    { id: 'watch', label: 'קולנוע משותף', icon: Film },
    { id: 'call', label: 'שיחות וידאו', icon: Video },
    { id: 'board', label: 'לוח ציור', icon: PenTool },
    { id: 'contacts', label: 'אנשי קשר', icon: Users }
  ];

  const handlePrevPage = () => {
    const idx = APP_PAGES.findIndex((p) => p.id === activePage);
    const prevIdx = (idx - 1 + APP_PAGES.length) % APP_PAGES.length;
    setActivePage(APP_PAGES[prevIdx].id);
  };

  const handleNextPage = () => {
    const idx = APP_PAGES.findIndex((p) => p.id === activePage);
    const nextIdx = (idx + 1) % APP_PAGES.length;
    setActivePage(APP_PAGES[nextIdx].id);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
    touchStartYRef.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartXRef.current === null || touchStartYRef.current === null) return;
    const diffX = e.changedTouches[0].clientX - touchStartXRef.current;
    const diffY = e.changedTouches[0].clientY - touchStartYRef.current;
    touchStartXRef.current = null;
    touchStartYRef.current = null;
    // Only treat as horizontal page swipe when horizontal movement dominates (prevents scroll conflicts / graphic glitches)
    if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 55) {
      if (diffX > 0) {
        handlePrevPage();
      } else {
        handleNextPage();
      }
    }
  };

  // Custom Station ID editor handlers
  const handleStartEditId = () => {
    setCustomIdInput(myId);
    setIdEditError(null);
    setIsEditingId(true);
  };

  const handleSaveCustomId = (newId?: string) => {
    const raw = typeof newId === 'string' ? newId : customIdInput;
    const clean = raw.trim().replace(/\s+/g, '_');
    if (!clean) {
      setIdEditError('אנא הזן מזהה (מספרים בלבד או אותיות)');
      return;
    }
    if (clean.length < 1 || clean.length > 64) {
      setIdEditError('אורך המזהה חייב להיות בין 1 ל-64 תווים');
      return;
    }
    const validRegex = /^[a-zA-Z0-9_-]+$/;
    if (!validRegex.test(clean)) {
      setIdEditError('המזהה יכול להכיל רק מספרים (0-9), אותיות באנגלית, מקף (-) וקו תחתון (_)');
      return;
    }

    try {
      localStorage.setItem(STORAGE.stationId, clean);
      setMyId(clean);
      setIsEditingId(false);
      setIdEditError(null);
      setIdSuccessMsg(`המזהה שלך עודכן בהצלחה ל: ${clean}. חברים יכולים לחייג אליך כעת ישירות!`);
      setTimeout(() => setIdSuccessMsg(null), 5000);

      initStationRef.current(clean);
      subscribeToWebPush(clean).catch(() => {});
    } catch (e: any) {
      setIdEditError('שגיאה בעדכון המזהה: ' + e.message);
    }
  };

  const handleRandomizeNumericId = () => {
    const randomNum = Math.floor(100000 + Math.random() * 900000).toString();
    setCustomIdInput(randomNum);
    setIdEditError(null);
  };

  const activeFriendName = connectedFriend?.nickname || connectedFriend?.name || 'חבר';
  const isGroupActive = groupParticipants.length > 2;

  return (
    <div className="min-h-screen bg-[#0f141c] text-slate-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-indigo-300" dir="rtl">
      {/* Sleek Social Platform Header Bar */}
      <header className="border-b border-slate-800/80 bg-slate-900/80 backdrop-blur-md px-4 sm:px-6 lg:px-8 py-3.5 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Logo & App Brand */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src="/station-logo.jpg"
                alt="Klypt Logo"
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl object-cover border border-indigo-500/30 shadow-md shadow-indigo-950/20"
              />
              <span
                className={`absolute -bottom-0.5 -left-0.5 w-3 h-3 rounded-full border-2 border-[#0f141c] ${
                  isConnected ? 'bg-sky-400' : 'bg-slate-500'
                }`}
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold tracking-tight text-white leading-none">
                  Klypt
                </h1>
                <span className="hidden md:inline px-2 py-0.5 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-[10px] text-indigo-300 font-medium">
                  {isGroupActive ? 'קבוצה במצב גשר' : 'רשת חברתית ישירה'}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5 flex items-center gap-1.5">
                <span className={`w-1.5 h-1.5 rounded-full ${isConnected ? 'bg-sky-400 animate-pulse' : 'bg-slate-500'}`} />
                <span>{status}</span>
              </p>
            </div>
          </div>

          {/* Quick Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {isConnected && (
              <button
                type="button"
                onClick={() => setShowBridgeModal(true)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600/15 hover:bg-indigo-600/25 text-xs text-indigo-300 font-semibold transition-all border border-indigo-500/30 cursor-pointer shadow-xs"
                title="שתף טוקן גשר לצירוף משתתף 3"
              >
                <Network className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">מצב גשר (טוקן)</span>
              </button>
            )}

            {/* Header Direct Station ID Pill */}
            <button
              type="button"
              onClick={handleStartEditId}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600/15 hover:bg-indigo-600/25 border border-indigo-500/30 text-indigo-300 text-xs font-mono font-bold transition-all cursor-pointer shadow-xs"
              title="לחץ כאן כדי להחליט ולשנות את המזהה שלך (מספרים או אותיות)"
            >
              <Hash className="w-3.5 h-3.5 text-indigo-400" />
              <span className="max-w-[100px] sm:max-w-[140px] truncate">{myId || 'קבע מזהה'}</span>
              <Edit3 className="w-3 h-3 text-indigo-400/80" />
            </button>

            <button
              type="button"
              onClick={() => setShowTermsModal(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-xs text-slate-300 font-medium transition-colors border border-slate-700/60 cursor-pointer shadow-xs"
              title="תנאי שימוש והגדרות מערכת"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">תנאים והגדרות</span>
            </button>

            <button
              type="button"
              onClick={toggleSound}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 transition-colors cursor-pointer border border-slate-700/60 shadow-xs"
              title={soundEnabled ? 'צלילים פעילים' : 'צלילים מושתקים'}
            >
              {soundEnabled ? (
                <Volume2 className="w-4 h-4 text-indigo-400" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-500" />
              )}
            </button>

            {isConnected && (
              <button
                type="button"
                onClick={disconnect}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-red-600/15 hover:bg-red-600/25 border border-red-500/30 text-xs font-semibold text-red-300 transition-all cursor-pointer shadow-xs"
              >
                <PhoneOff className="w-3.5 h-3.5" />
                <span>{isGroupActive ? 'עזוב קבוצה' : 'נתק שיחה'}</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Navigation Bar for Dedicated Spacious Rooms */}
      <nav className="bg-slate-900/60 border-b border-slate-800/80 px-4 sm:px-6 lg:px-8 py-2 sticky top-[65px] z-20 backdrop-blur-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">
          {/* Arrow (Previous Room) */}
          <button
            type="button"
            onClick={handlePrevPage}
            className="p-2 rounded-xl bg-slate-800/70 hover:bg-slate-700 text-slate-300 transition-colors shrink-0 cursor-pointer shadow-xs"
            title="עבור לעמוד הקודם (החלקה ימינה)"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          {/* Room Tabs */}
          <div className="flex items-center gap-1.5 sm:gap-2 flex-1 justify-center overflow-x-auto no-scrollbar">
            {APP_PAGES.map((page) => {
              const Icon = page.icon;
              const isActive = activePage === page.id;
              const isChat = page.id === 'chat';
              const isCall = page.id === 'call';
              const isContacts = page.id === 'contacts';

              return (
                <button
                  key={page.id}
                  type="button"
                  onClick={() => setActivePage(page.id)}
                  className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-2xl text-xs font-bold transition-all cursor-pointer relative shrink-0 shadow-xs ${
                    isActive
                      ? 'bg-gradient-to-r from-indigo-600 to-indigo-500 text-white shadow-indigo-950/40 ring-1 ring-indigo-400/40'
                      : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800/90'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{page.label}</span>

                  {/* Badges */}
                  {isChat && messages.length > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-black/30 text-indigo-200">
                      {messages.length}
                    </span>
                  )}
                  {isCall && isInCall && (
                    <span className="w-2 h-2 rounded-full bg-red-400 animate-ping" />
                  )}
                  {isContacts && contacts.length > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-800 text-slate-400">
                      {contacts.length}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Arrow (Next Room) */}
          <button
            type="button"
            onClick={handleNextPage}
            className="p-2 rounded-xl bg-slate-800/70 hover:bg-slate-700 text-slate-300 transition-colors shrink-0 cursor-pointer shadow-xs"
            title="עבור לעמוד הבא (החלקה שמאלה)"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </nav>

      {/* Main Spacious Viewport Layout with Swipe Gestures */}
      <main
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        className="max-w-7xl mx-auto w-full p-4 sm:p-6 lg:p-8 flex-1 flex flex-col gap-6 touch-pan-y"
        style={{ maxWidth: 'var(--app-max-w, 80rem)' }}
      >
        {/* Offline Peer Alert */}
        {offlinePeerAlert && (
          <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/30 flex items-center justify-between text-xs animate-in fade-in duration-200 shadow-md">
            <div className="flex items-center gap-3 text-amber-300">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse shrink-0" />
              <span className="leading-relaxed">{offlinePeerAlert}</span>
            </div>
            <button
              type="button"
              onClick={() => setOfflinePeerAlert(null)}
              className="text-slate-400 hover:text-slate-200 px-2.5 py-1 rounded-lg hover:bg-slate-800 text-xs cursor-pointer shrink-0"
            >
              ✕
            </button>
          </div>
        )}

        {/* Outgoing Calling Alert Bar */}
        {outgoingCallTarget && (
          <div className="p-4 rounded-2xl bg-slate-900 border border-indigo-500/40 flex items-center justify-between gap-4 animate-in fade-in duration-200 shadow-lg">
            <div className="flex items-center gap-3 min-w-0">
              <Loader2 className="w-5 h-5 text-indigo-400 animate-spin shrink-0" />
              <div className="min-w-0">
                <p className="text-xs font-bold text-slate-100 truncate">
                  מחייג כעת אל {outgoingCallTarget}...
                </p>
                <p className="text-[11px] text-slate-400 truncate">
                  נשלחה התראת דפדפן וצלצול. ממתין לאישור והצטרפות החבר.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleCancelOutgoing}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 font-medium transition-colors shrink-0 cursor-pointer"
            >
              ביטול חיוג
            </button>
          </div>
        )}

        {/* Floating Active Connection / Ongoing Call Indicator across all rooms */}
        {isConnected && (
          <div className="p-3.5 sm:p-4 rounded-3xl bg-slate-900/95 border border-indigo-500/30 flex flex-wrap items-center justify-between gap-3 shadow-xl backdrop-blur-md">
            <div className="flex items-center gap-3 min-w-0">
              <div className="relative">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 to-sky-500 flex items-center justify-center text-white text-sm font-bold shadow-sm border border-indigo-400/40">
                  {isGroupActive ? <Users className="w-5 h-5" /> : activeFriendName.charAt(0) || 'ח'}
                </div>
                <span className="absolute -bottom-0.5 -left-0.5 w-3 h-3 rounded-full bg-sky-400 border-2 border-slate-900" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-bold text-white truncate">
                    {isGroupActive ? `קבוצה פעילה (${groupParticipants.length} חברים)` : activeFriendName}
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-indigo-500/15 text-[10px] text-indigo-300 font-semibold border border-indigo-500/30">
                    {isInCall ? 'שיחת וידאו פעילה ●' : 'מחובר P2P'}
                  </span>
                  {(connectedFriend?.mood || peerNetwork?.mood) && (
                    <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-[11px] text-amber-300 border border-slate-700/80 font-normal">
                      {connectedFriend?.mood || peerNetwork?.mood}
                    </span>
                  )}
                </div>
                <span className="text-xs text-slate-400 font-mono truncate block mt-0.5">
                  {isGroupActive
                    ? `משתתפים: ${groupParticipants.map((p) => p.name).join(', ')}`
                    : `מזהה: ${connectedFriend?.id || ''} ${peerNetwork?.city ? `• ${peerNetwork.city}` : ''}`}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActivePage('chat')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activePage === 'chat'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                }`}
              >
                צ'אט ({messages.length})
              </button>
              <button
                type="button"
                onClick={() => setActivePage('call')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activePage === 'call'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                }`}
              >
                וידאו & שמע
              </button>
              <button
                type="button"
                onClick={() => setActivePage('watch')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activePage === 'watch'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                }`}
              >
                סרטים
              </button>
              <button
                type="button"
                onClick={disconnect}
                className="px-3.5 py-1.5 rounded-xl bg-red-600/15 hover:bg-red-600/25 border border-red-500/30 text-xs text-red-300 font-semibold transition-colors cursor-pointer"
              >
                נתק
              </button>
            </div>
          </div>
        )}

        {/* =========================================================================
            ROOM 1: LOUNGE & DIAL (טרקלין וחיוג)
            ========================================================================= */}
        {activePage === 'lounge' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            {/* Hero Welcome Card */}
            <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-slate-800/80 rounded-3xl p-6 sm:p-8 shadow-sm">
              <div className="relative z-10 max-w-3xl space-y-3">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/25 text-xs font-semibold text-indigo-300">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>פלטפורמת תקשורת חברתית P2P ישירה ונעימה</span>
                </div>

                <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-snug">
                  ברוכים הבאים ל-Klypt
                </h2>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  מרחב חברתי מרווח ונעים הכולל צ'אט מהיר, שיחות וידאו באיכות HD, צפייה מסונכרנת בסרטים (Watch Party), וצ'אט קבוצתי במצב גשר (Bridge Mode) ישירות בין מכשירים.
                </p>
              </div>

              {/* Decorative glowing gradient sphere */}
              <div className="absolute -top-12 -left-12 w-56 h-56 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
            </div>

            {/* Success toast after updating custom Station ID */}
            {idSuccessMsg && (
              <div className="p-4 rounded-2xl bg-indigo-950/80 border border-indigo-500/40 text-indigo-200 text-xs flex items-center justify-between gap-3 animate-in fade-in duration-200">
                <div className="flex items-center gap-2 font-semibold">
                  <Check className="w-4 h-4 text-indigo-400" />
                  <span>{idSuccessMsg}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIdSuccessMsg(null)}
                  className="text-indigo-400 hover:text-indigo-200 text-xs cursor-pointer"
                >
                  ✕
                </button>
              </div>
            )}

            {/* 2-Column Responsive Section: Personal Station Profile & Direct Dial */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Card 1: My Profile & Customizable Station ID (7 Cols) */}
              <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800/80 rounded-3xl p-6 shadow-sm space-y-5">
                {/* Profile Header */}
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="relative shrink-0">
                      <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 to-sky-500 flex items-center justify-center text-white font-bold text-lg shadow-sm border border-indigo-400/30">
                        {userName.charAt(0) || 'א'}
                      </div>
                      <span className="absolute -bottom-0.5 -left-0.5 w-3.5 h-3.5 rounded-full bg-sky-400 border-2 border-slate-900" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-bold text-white truncate">
                          {userName}
                        </h3>
                        <button
                          type="button"
                          onClick={() => {
                            const newName = prompt('ערוך את שמך בתחנה:', userName);
                            if (newName && newName.trim()) {
                              setUserName(newName.trim());
                              localStorage.setItem(STORAGE.userName, newName.trim());
                            }
                          }}
                          className="text-slate-400 hover:text-slate-200 text-xs cursor-pointer p-1 rounded-lg hover:bg-slate-800"
                          title="ערוך שם"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <p className="text-xs text-slate-400 font-mono mt-0.5 flex items-center gap-1.5">
                        <span className="text-sky-400 font-semibold">● תחנה מוכנה</span>
                        {myIp && <span className="text-slate-500">• IP: {myIp}</span>}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleStartEditId}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600/15 hover:bg-indigo-600/25 border border-indigo-500/30 text-indigo-300 text-xs font-semibold transition-all cursor-pointer shadow-xs"
                    title="שנה את מזהה התחנה שלך (מספרים או אותיות)"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-indigo-400" />
                    <span>ערוך מזהה אישי</span>
                  </button>
                </div>



                {/* Station ID / Link Display Card */}
                <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
                  {/* Mode Selector Tabs: ID (Default) vs Link */}
                  <div className="flex items-center gap-2 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs font-semibold">
                    <button
                      type="button"
                      onClick={() => setShareMode('id')}
                      className={`flex-1 py-1.5 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        shareMode === 'id'
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Key className="w-3.5 h-3.5" />
                      <span>מזהה תחנה (ברירת מחדל אמינה)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setShareMode('link')}
                      className={`flex-1 py-1.5 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        shareMode === 'link'
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>קישור ישיר</span>
                    </button>
                  </div>

                  {shareMode === 'id' ? (
                    /* ID Mode */
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
                        <span className="flex items-center gap-1.5 text-indigo-300">
                          <Key className="w-3.5 h-3.5 text-indigo-400" />
                          המזהה האישי שלך לחיוג והתחברות:
                        </span>
                        {idCopied && (
                          <span className="text-[11px] text-indigo-300 font-bold animate-in fade-in">
                            המזהה הועתק! ✓
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap sm:flex-nowrap gap-2">
                        <div
                          onClick={handleCopyId}
                          dir="ltr"
                          className="flex-1 bg-slate-900 border border-slate-800 hover:border-indigo-500/50 rounded-xl px-4 py-2.5 font-mono text-sm text-indigo-300 font-bold truncate cursor-pointer transition-colors select-all min-w-[140px]"
                          title="לחץ להעתקת המזהה"
                        >
                          {myId || 'מייצר מזהה...'}
                        </div>

                        <button
                          type="button"
                          onClick={handleCopyId}
                          className={`flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer shadow-xs ${
                            idCopied
                              ? 'bg-indigo-500 text-slate-950 font-bold'
                              : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                          }`}
                        >
                          {idCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                          <span>{idCopied ? 'הועתק' : 'העתק מזהה'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={handleStartEditId}
                          className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-indigo-500/50 text-indigo-300 text-xs font-bold transition-all shrink-0 cursor-pointer shadow-xs"
                          title="החלט מה המזהה שלך (מספרים או אותיות)"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-indigo-400" />
                          <span>החלף מזהה</span>
                        </button>
                      </div>

                      <p className="text-[11px] text-slate-400 leading-relaxed pt-1">
                        <strong>ברירת מחדל אמינה:</strong> שלח מזהה זה לחבר (או בחר מספרים בלבד בכפתור "החלף מזהה"). אם קישור נחסם או לא עובד אצלו, הוא פשוט מזין את המזהה בתיבת החיוג ומתחבר מיד.
                      </p>
                    </div>
                  ) : (
                    /* Link Mode */
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
                        <span className="flex items-center gap-1.5 text-slate-300">
                          <Share2 className="w-3.5 h-3.5 text-indigo-400" />
                          הקישור הקבוע שלך:
                        </span>
                        {linkCopied && (
                          <span className="text-[11px] text-indigo-300 font-bold animate-in fade-in">
                            הקישור הועתק! ✓
                          </span>
                        )}
                      </div>

                      <div className="flex gap-2">
                        <div
                          onClick={handleCopyLink}
                          dir="ltr"
                          className="flex-1 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl px-4 py-2.5 font-mono text-xs text-indigo-300 truncate cursor-pointer transition-colors select-all"
                          title="לחץ להעתקת הקישור"
                        >
                          {shareableUrl || 'מייצר קישור...'}
                        </div>

                        <button
                          type="button"
                          onClick={handleCopyLink}
                          className={`flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all shrink-0 cursor-pointer shadow-xs ${
                            linkCopied
                              ? 'bg-indigo-500 text-slate-950 font-bold'
                              : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                          }`}
                        >
                          {linkCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                          <span>{linkCopied ? 'הועתק' : 'העתק קישור'}</span>
                        </button>
                      </div>

                      <p className="text-[11px] text-slate-400 leading-relaxed pt-1">
                        החבר פותח את הקישור פעם אחת בלבד בדפדפן ומתחבר אליך אוטומטית.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Card 2: Direct Dial & Connect Box (5 Cols) */}
              <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800/80 rounded-3xl p-6 shadow-sm space-y-4">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Key className="w-4 h-4 text-indigo-400" />
                    <span>חיוג והתחברות ישירה</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    הדבק כאן מזהה של חבר (יכול להיות מספרים כמו 123456 או אותיות) או קישור:
                  </p>
                </div>

                <form onSubmit={handleDirectConnectSubmit} className="space-y-3">
                  <input
                    type="text"
                    value={directConnectInput}
                    onChange={(e) => setDirectConnectInput(e.target.value)}
                    placeholder="הדבק כאן מזהה של חבר או מספר תחנה..."
                    dir="ltr"
                    className="w-full bg-slate-950 border border-slate-800 hover:border-slate-700 focus:border-indigo-500 rounded-xl px-4 py-3 text-xs text-slate-100 font-mono placeholder-slate-500 focus:outline-none transition-colors"
                  />
                  <button
                    type="submit"
                    disabled={!directConnectInput.trim()}
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-bold transition-all cursor-pointer shadow-xs"
                  >
                    <span>התחבר וחייג עכשיו</span>
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                </form>

                <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-start gap-2.5 text-[11px] text-slate-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-sky-400 mt-1.5 shrink-0" />
                  <p className="leading-relaxed">
                    <strong>מנגנון השכמה אוטומטי:</strong> גם אם החבר סגר את הדפדפן, המערכת תשלח לו התראת צלצול Web Push ותתחבר אליו מיידית ברגע שייכנס.
                  </p>
                </div>
              </div>
            </div>

            {/* Wi-Fi Nearby Devices Discovery (באותו Wi-Fi / נתב) */}
            <div className="bg-slate-900/90 border border-slate-800/80 rounded-3xl p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
                    <Wifi className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      מכשירים ברשת המקומית (לידי)
                      {nearbyDevices.length > 0 && (
                        <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
                      )}
                    </h3>
                    <p className="text-xs text-slate-400">
                      גילוי אוטומטי של מחשבים ומכשירים המחוברים לאותו נתב Wi-Fi (ללא צורך בהחלפת קישורים)
                    </p>
                  </div>
                </div>

                <span className="text-xs font-mono text-sky-400 font-semibold px-2.5 py-1 rounded-full bg-sky-500/10 border border-sky-500/30">
                  {nearbyDevices.length > 0 ? `${nearbyDevices.length} זוהו ברשת` : 'סריקה פעילה...'}
                </span>
              </div>

              {nearbyDevices.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5 pt-1">
                  {nearbyDevices.map((dev) => (
                    <div
                      key={dev.stationId}
                      className="bg-slate-950/80 border border-sky-500/30 hover:border-sky-400/60 rounded-2xl p-4 flex items-center justify-between gap-3 transition-all hover:bg-slate-950 shadow-xs"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-400" />
                          <h4 className="text-sm font-bold text-slate-100 truncate">
                            {dev.userName}
                          </h4>
                        </div>
                        <p className="text-xs text-slate-400 font-mono truncate mt-0.5">
                          מזהה: {dev.stationId}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() =>
                          connectToFriendId(dev.stationId, {
                            id: dev.stationId,
                            name: dev.userName,
                            nickname: dev.userName,
                            ip: dev.clientIp,
                            lastSeen: Date.now()
                          })
                        }
                        className="flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95 shrink-0"
                      >
                        <Phone className="w-3.5 h-3.5 fill-current" />
                        <span>התחבר</span>
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-slate-950/50 border border-slate-800 flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-sky-400/60 animate-pulse" />
                    <span>המערכת סורקת את הרשת המקומית — כשמכשיר נוסף יפתח את האפליקציה באותו הבית או המשרד, הוא יופיע כאן מיידית להתחברות בלחיצה אחת.</span>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Dial Friends Grid (if contacts exist) */}
            {contacts.length > 0 && (
              <div className="bg-slate-900/90 border border-slate-800/80 rounded-3xl p-6 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Phone className="w-4 h-4 text-indigo-400" />
                    <span>חיוג מהיר לחברים שמורים</span>
                  </h3>
                  <button
                    type="button"
                    onClick={() => setActivePage('contacts')}
                    className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
                  >
                    ניהול כל אנשי הקשר ({contacts.length}) ←
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
                  {contacts.map((c) => {
                    const displayName = c.nickname || c.name || `חבר (${c.id.slice(0, 8)})`;
                    return (
                      <div
                        key={c.id}
                        className="bg-slate-950/70 border border-slate-800 hover:border-indigo-500/40 rounded-2xl p-4 flex items-center justify-between gap-3 transition-all hover:bg-slate-950 shadow-xs"
                      >
                        <div className="min-w-0 flex-1">
                          <h4 className="text-sm font-bold text-slate-100 truncate">
                            {displayName}
                          </h4>
                          <p className="text-xs text-slate-400 font-mono truncate mt-0.5">
                            מזהה: {c.id} {c.city ? `• ${c.city}` : ''}
                          </p>
                        </div>

                        <button
                          type="button"
                          onClick={() => connectToFriendId(c.id, c)}
                          className="flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95 shrink-0"
                        >
                          <Phone className="w-3.5 h-3.5 fill-current" />
                          <span>חייג</span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Platform Highlights */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="w-9 h-9 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center">
                  <Film className="w-4 h-4" />
                </div>
                <h4 className="text-xs font-bold text-slate-100">קולנוע וצפייה משותפת</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  סנכרון מלא של עצירה, הפעלה ודילוג בסרטים וסרטונים בזמן אמת בינך לבין החברים.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="w-9 h-9 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center">
                  <Network className="w-4 h-4" />
                </div>
                <h4 className="text-xs font-bold text-slate-100">מצב גשר (Bridge Mode)</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  שיתוף טוקן עם אדם שלישי ליצירת צ'אט קבוצתי P2P ישיר ללא שרתים מתווכים.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="w-9 h-9 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                <h4 className="text-xs font-bold text-slate-100">העברת קבצים ישירה</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  שיתוף סרטים וקבצים ללא הגבלת גודל, ישירות בין הדפדפנים ברוחב הפס המקסימלי.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            ROOM 2: SOCIAL CHAT (צ'אט והודעות)
            ========================================================================= */}
        {activePage === 'chat' && (
          <div className="animate-in fade-in duration-150">
            <ChatSection
              messages={messages}
              onSendMessage={sendChatMessage}
              onSendFile={sendFileWithFlowControl}
              onClearChat={() => setMessages([])}
              isPeerConnected={isConnected}
              fileProgress={fileProgress}
              groupParticipants={groupParticipants}
              onOpenBridgeModal={() => setShowBridgeModal(true)}
              contacts={contacts}
              onConnectToFriend={(id) => connectToFriendId(id)}
            />
          </div>
        )}

        {/* =========================================================================
            ROOM 3: WATCH PARTY CINEMA (קולנוע משותף)
            ========================================================================= */}
        {activePage === 'watch' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            {!isConnected && (
              <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 flex items-center justify-between text-xs text-indigo-200">
                <div className="flex items-center gap-2.5">
                  <Film className="w-4 h-4 text-indigo-400 shrink-0" />
                  <span>
                    ניתן לצפות בסרטונים מקומית כעת. כשחבר יתחבר, הצפייה והסנכרון יפעלו יחד אוטומטית!
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setActivePage('lounge')}
                  className="px-3 py-1 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 text-xs font-semibold cursor-pointer"
                >
                  חייג לחבר
                </button>
              </div>
            )}

            <VideoPlayerSection
              conn={connRef.current}
              remotePeerId={connRef.current?.peer}
              userName={userName}
              friendName={connectedFriend?.nickname || connectedFriend?.name || 'חבר'}
              onStartLiveStream={handleStartLiveStream}
              incomingStream={incomingVideoStream}
              transferProgress={fileProgress}
              incomingVideoChunk={incomingVideoChunk}
              onLogMessage={addLogMessage}
            />
          </div>
        )}

        {/* =========================================================================
            ROOM 4: CALL STUDIO (שיחות וידאו וקול)
            ========================================================================= */}
        {activePage === 'call' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <CallOverlay
              localStream={localStream}
              remoteStream={remoteStream}
              isInCall={isInCall}
              isAudioMuted={isAudioMuted}
              isVideoMuted={isVideoMuted}
              onToggleAudio={() => {
                if (localStream) {
                  const t = localStream.getAudioTracks()[0];
                  if (t) {
                    t.enabled = isAudioMuted;
                    setIsAudioMuted(!isAudioMuted);
                  }
                }
              }}
              onToggleVideo={() => {
                if (localStream) {
                  const t = localStream.getVideoTracks()[0];
                  if (t) {
                    t.enabled = isVideoMuted;
                    setIsVideoMuted(!isVideoMuted);
                  }
                }
              }}
              onEndCall={endCall}
              onStartCall={startCall}
              isPeerConnected={isConnected}
            />

            {/* If idle, offer quick-dial contacts right in the calling studio */}
            {!isConnected && !isInCall && contacts.length > 0 && (
              <div className="bg-slate-900/90 border border-slate-800/80 rounded-3xl p-6 space-y-3">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Phone className="w-4 h-4 text-indigo-400" />
                  <span>בחר חבר לחיוג וידאו מיידי:</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {contacts.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => connectToFriendId(c.id, c)}
                      className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/40 text-right flex items-center justify-between gap-3 transition-all cursor-pointer group"
                    >
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-100 group-hover:text-indigo-300 truncate">
                          {c.nickname || c.name}
                        </p>
                        <p className="text-[10px] text-slate-400 font-mono truncate">
                          {c.id}
                        </p>
                      </div>
                      <div className="w-8 h-8 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center shrink-0">
                        <Video className="w-4 h-4" />
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* =========================================================================
            ROOM 5: COLLABORATIVE WHITEBOARD (לוח ציור משותף)
            ========================================================================= */}
        {activePage === 'board' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <WhiteboardSection
              conn={connRef.current}
              remotePeerId={connRef.current?.peer}
              userName={userName}
              isPeerConnected={isConnected}
              onBroadcastMessage={broadcastToGroup}
              incomingWhiteboardStroke={incomingWhiteboardStroke}
              incomingWhiteboardClear={incomingWhiteboardClear}
            />
          </div>
        )}

        {/* =========================================================================
            ROOM 6: CONTACTS & FRIENDS (אנשי קשר וחברים)
            ========================================================================= */}
        {activePage === 'contacts' && (
          <div className="bg-slate-900/90 border border-slate-800/80 rounded-3xl p-6 shadow-sm space-y-4 animate-in fade-in duration-150">
            <ContactsSection
              contacts={contacts}
              nearbyDevices={nearbyDevices}
              onCallNearby={(dev) =>
                connectToFriendId(dev.stationId, {
                  id: dev.stationId,
                  name: dev.userName,
                  nickname: dev.userName,
                  ip: dev.clientIp,
                  lastSeen: Date.now()
                })
              }
              onCallFriend={(friend) => connectToFriendId(friend.id, friend)}
              onUpdateNickname={(id, nickname) => {
                const updated = contacts.map((c) => (c.id === id ? { ...c, nickname } : c));
                saveContacts(updated);
              }}
              onDeleteContact={(id) => {
                const updated = contacts.filter((c) => c.id !== id);
                saveContacts(updated);
              }}
              onAddContactManual={(c) => {
                const updated = [c, ...contacts.filter((x) => x.id !== c.id)];
                saveContacts(updated);
              }}
            />
          </div>
        )}
      </main>

      {/* MODAL 1: FRIEND IS CALLING YOU (Incoming Call Dropdown Alert) */}
      {incomingCall && (
        <IncomingCallModal
          callerIp={incomingCall.callerIp}
          callerName={incomingCall.callerName}
          callerCity={incomingCall.callerCity}
          callerCountry={incomingCall.callerCountry}
          onAnswer={handleAnswerCall}
          onDecline={handleDeclineCall}
        />
      )}

      {/* MODAL 2: NAME THE NEWLY CONNECTED FRIEND */}
      {newPeerToNickname && (
        <NicknamePromptModal
          peerIp={newPeerToNickname.peerIp}
          peerNetwork={newPeerToNickname.peerNetwork}
          initialName={newPeerToNickname.initialName}
          onSave={handleSaveNickname}
          onDismiss={() => setNewPeerToNickname(null)}
        />
      )}

      {/* MODAL: CUSTOM STATION ID PICKER */}
      <CustomIdModal
        isOpen={isEditingId}
        onClose={() => setIsEditingId(false)}
        currentId={myId}
        onSaveId={handleSaveCustomId}
      />

      {/* MODAL 3: BRIDGE MODE - SHARE CONNECTION TOKEN WITH 3RD PERSON */}
      <BridgeModal
        isOpen={showBridgeModal}
        onClose={() => setShowBridgeModal(false)}
        myId={myId}
        connectedPeerIds={Array.from(groupConnsRef.current.keys())}
        participants={groupParticipants}
      />

      {/* MANDATORY ONBOARDING: TERMS & SETTINGS ACCEPTANCE */}
      {(!hasAcceptedTerms || showTermsModal) && (
        <TermsAndSettingsModal
          onAccept={() => {
            setHasAcceptedTerms(true);
            setShowTermsModal(false);
          }}
        />
      )}
    </div>
  );
}
