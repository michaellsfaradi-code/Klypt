import React, { useState, useEffect } from 'react';
import {
  Hash,
  X,
  Check,
  Dices,
  Sparkles,
  PhoneCall,
  Key,
  ShieldCheck
} from 'lucide-react';

interface CustomIdModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentId: string;
  onSaveId: (newId: string) => void;
}

export const CustomIdModal: React.FC<CustomIdModalProps> = ({
  isOpen,
  onClose,
  currentId,
  onSaveId
}) => {
  const [inputValue, setInputValue] = useState(currentId);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setInputValue(currentId);
      setError(null);
    }
  }, [isOpen, currentId]);

  if (!isOpen) return null;

  const handleRandomize6Digits = () => {
    const randomNum = Math.floor(100000 + Math.random() * 900000).toString();
    setInputValue(randomNum);
    setError(null);
  };

  const handleRandomize4Digits = () => {
    const randomNum = Math.floor(1000 + Math.random() * 9000).toString();
    setInputValue(randomNum);
    setError(null);
  };

  const handlePresetPhoneExample = () => {
    setInputValue('050' + Math.floor(1000000 + Math.random() * 9000000).toString());
    setError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = inputValue.trim().replace(/\s+/g, '_');

    if (!clean) {
      setError('אנא הזן מזהה (מספרים או אותיות באנגלית)');
      return;
    }

    if (clean.length < 1 || clean.length > 64) {
      setError('אורך המזהה חייב להיות בין תו 1 ל-64 תווים');
      return;
    }

    const validRegex = /^[a-zA-Z0-9_-]+$/;
    if (!validRegex.test(clean)) {
      setError('המזהה יכול להכיל רק מספרים (0-9), אותיות באנגלית, מקף (-) וקו תחתון (_)');
      return;
    }

    onSaveId(clean);
  };

  const isNumericOnly = /^[0-9]+$/.test(inputValue.trim());

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200" dir="rtl">
      <div className="relative w-full max-w-lg bg-[#0f141c] border border-indigo-500/30 rounded-3xl p-6 sm:p-7 shadow-[0_20px_60px_rgba(0,0,0,0.8),0_0_30px_rgba(99,102,241,0.15)] text-right flex flex-col max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 left-5 text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 pb-4 border-b border-slate-800/80">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-sky-500 flex items-center justify-center text-white shadow-md border border-indigo-400/30 shrink-0">
            <Hash className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
              החלט מה יהיה המזהה שלך (Station ID)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              תוכל להגדיר כל מזהה שבא לך — מספרים בלבד או כל כינוי אישי
            </p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="py-4 space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-200 flex items-center justify-between">
              <span>הזן את המזהה האישי שלך:</span>
              {inputValue && isNumericOnly && (
                <span className="text-[11px] text-sky-400 font-mono font-bold">
                  ✓ מספרים בלבד ({inputValue.length} ספרות)
                </span>
              )}
            </label>

            <div className="relative">
              <input
                type="text"
                autoFocus
                value={inputValue}
                onChange={(e) => {
                  setInputValue(e.target.value);
                  setError(null);
                }}
                placeholder="למשל: 123456, 0521234567, alex..."
                dir="ltr"
                className="w-full bg-slate-900 border-2 border-indigo-500/40 focus:border-indigo-400 rounded-2xl px-4 py-3 text-base font-mono font-bold text-indigo-300 placeholder-slate-500 focus:outline-none transition-colors shadow-inner"
              />
              {inputValue && (
                <button
                  type="button"
                  onClick={() => setInputValue('')}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs px-2 py-1 rounded-md"
                >
                  נקה
                </button>
              )}
            </div>

            {error && (
              <p className="text-xs text-red-400 font-medium animate-in fade-in">
                {error}
              </p>
            )}
          </div>

          {/* Quick Choice Buttons */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-medium text-slate-400 block">
              בחירה מהירה בלחיצה (לנוחיותך):
            </span>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleRandomize6Digits}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200 transition-colors cursor-pointer"
              >
                <Dices className="w-3.5 h-3.5 text-amber-400" />
                <span>הגרל 6 ספרות</span>
              </button>

              <button
                type="button"
                onClick={handleRandomize4Digits}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200 transition-colors cursor-pointer"
              >
                <Key className="w-3.5 h-3.5 text-sky-400" />
                <span>הגרל 4 ספרות (קצר)</span>
              </button>

              <button
                type="button"
                onClick={handlePresetPhoneExample}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200 transition-colors cursor-pointer"
              >
                <PhoneCall className="w-3.5 h-3.5 text-indigo-400" />
                <span>דוגמת מספר נייד</span>
              </button>
            </div>
          </div>

          {/* Helpful Explanation Cards */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2 text-xs text-slate-400">
            <div className="flex items-start gap-2">
              <Sparkles className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <p className="leading-relaxed">
                <strong>איך חברים יחייגו אליך?</strong> החברים שלך פשוט מקלידים את המזהה שקבעת (למשל <span className="font-mono text-indigo-300 font-bold">{inputValue || '123456'}</span>) בתיבת החיוג ולוחצים "חייג". השיחה תצלצל אצלך מיידית!
              </p>
            </div>
            <div className="flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <p className="leading-relaxed">
                המזהה נשמר מקומית בדפדפן שלך ולא משתנה גם אם תתחבר לרשת Wi-Fi אחרת.
              </p>
            </div>
          </div>

          {/* Footer Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors cursor-pointer"
            >
              ביטול
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-950/40 cursor-pointer flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>שמור מזהה והפעל תחנה</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
