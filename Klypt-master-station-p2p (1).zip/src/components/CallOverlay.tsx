import React, { useRef, useEffect } from 'react';
import {
  Video,
  VideoOff,
  Mic,
  MicOff,
  PhoneOff,
  PhoneCall,
  Volume2
} from 'lucide-react';

interface CallOverlayProps {
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  isInCall: boolean;
  isAudioMuted: boolean;
  isVideoMuted: boolean;
  onToggleAudio: () => void;
  onToggleVideo: () => void;
  onEndCall: () => void;
  onStartCall: (withVideo: boolean) => void;
  isPeerConnected: boolean;
}

export const CallOverlay: React.FC<CallOverlayProps> = ({
  localStream,
  remoteStream,
  isInCall,
  isAudioMuted,
  isVideoMuted,
  onToggleAudio,
  onToggleVideo,
  onEndCall,
  onStartCall,
  isPeerConnected
}) => {
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  return (
    <div className="bg-slate-900/90 border border-slate-800/80 rounded-3xl p-5 md:p-6 shadow-xl">
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <Video className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              שיחת וידאו & שמע P2P
              {isInCall && (
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              )}
            </h3>
            <p className="text-xs text-slate-400">
              תקשורת שמע ווידאו מוצפנת מקצה-לקצה באיכות HD
            </p>
          </div>
        </div>

        {isInCall && (
          <span className="text-xs font-mono font-semibold px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            בשיחה פעילה
          </span>
        )}
      </div>

      {isInCall ? (
        <div>
          {/* Video grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
            {/* Remote Peer Stream */}
            <div className="relative bg-black rounded-xl overflow-hidden aspect-video border border-slate-800 flex items-center justify-center">
              <video
                ref={remoteVideoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded text-[11px] font-medium text-slate-300">
                החבר
              </div>
            </div>

            {/* Local Stream */}
            <div className="relative bg-black rounded-xl overflow-hidden aspect-video border border-slate-800 flex items-center justify-center">
              <video
                ref={localVideoRef}
                autoPlay
                muted
                playsInline
                className="w-full h-full object-cover scale-x-[-1]"
              />
              <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded text-[11px] font-medium text-slate-300">
                אני (מצלמה מקומית)
              </div>
              {isVideoMuted && (
                <div className="absolute inset-0 bg-slate-950/80 flex items-center justify-center text-xs text-slate-400">
                  המצלמה שלך כבויה
                </div>
              )}
            </div>
          </div>

          {/* Call control bar */}
          <div className="flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={onToggleAudio}
              className={`p-3 rounded-full border transition-all ${
                isAudioMuted
                  ? 'bg-red-500/20 border-red-500/40 text-red-400'
                  : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
              }`}
              title={isAudioMuted ? 'בטל השתקת מיקרופון' : 'השתק מיקרופון'}
            >
              {isAudioMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            <button
              type="button"
              onClick={onToggleVideo}
              className={`p-3 rounded-full border transition-all ${
                isVideoMuted
                  ? 'bg-red-500/20 border-red-500/40 text-red-400'
                  : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
              }`}
              title={isVideoMuted ? 'הפעל מצלמה' : 'כבה מצלמה'}
            >
              {isVideoMuted ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
            </button>

            <button
              type="button"
              onClick={onEndCall}
              className="px-5 py-3 rounded-full bg-red-600 hover:bg-red-500 text-white font-medium text-xs flex items-center gap-2 shadow-lg hover:shadow-red-500/20 transition-all"
            >
              <PhoneOff className="w-4 h-4" />
              סיים שיחה
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-xl bg-slate-900/50 border border-slate-800">
          <div className="text-right">
            <p className="text-xs font-semibold text-slate-200 mb-0.5">
              מוכן לשיחה ישירה
            </p>
            <p className="text-xs text-slate-400">
              ניתן להפעיל שיחת וידאו או שיחת קול בלבד תוך כדי גלישה, צפייה בסרט או שיתוף קבצים.
            </p>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => onStartCall(true)}
              disabled={!isPeerConnected}
              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-semibold shadow-md shadow-indigo-950/40 transition-all"
            >
              <Video className="w-4 h-4" />
              שיחת וידאו
            </button>
            <button
              type="button"
              onClick={() => onStartCall(false)}
              disabled={!isPeerConnected}
              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 border border-slate-700 text-slate-200 text-xs font-medium transition-all"
            >
              <PhoneCall className="w-4 h-4 text-sky-400" />
              שיחת קול בלבד
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
