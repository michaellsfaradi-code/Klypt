import React, { useState, useMemo } from 'react';
import {
  Phone,
  Trash2,
  Edit2,
  Check,
  Globe,
  MapPin,
  Plus,
  Clock,
  Search,
  X,
  User,
  Sparkles,
  Wifi,
  Radio
} from 'lucide-react';
import { PeerContact, NearbyDevice } from '../types';
import { isIpAddress, extractCleanIp, ipToPeerId } from '../utils/network';

interface ContactsSectionProps {
  contacts: PeerContact[];
  nearbyDevices?: NearbyDevice[];
  onCallNearby?: (device: NearbyDevice) => void;
  onCallFriend: (contact: PeerContact) => void;
  onUpdateNickname: (id: string, nickname: string) => void;
  onDeleteContact: (id: string) => void;
  onAddContactManual: (contact: PeerContact) => void;
}

// Generate distinct avatar gradients based on friend name
const AVATAR_GRADIENTS = [
  'from-indigo-500 to-indigo-700',
  'from-sky-500 to-blue-700',
  'from-violet-500 to-purple-700',
  'from-amber-500 to-orange-600',
  'from-teal-500 to-cyan-700',
  'from-rose-500 to-pink-700'
];

function getAvatarGradient(name: string) {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  const index = Math.abs(hash) % AVATAR_GRADIENTS.length;
  return AVATAR_GRADIENTS[index];
}

export const ContactsSection: React.FC<ContactsSectionProps> = ({
  contacts,
  nearbyDevices = [],
  onCallNearby,
  onCallFriend,
  onUpdateNickname,
  onDeleteContact,
  onAddContactManual
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState<string>('');
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [manualStationId, setManualStationId] = useState<string>('');
  const [manualName, setManualName] = useState<string>('');

  const handleStartEdit = (c: PeerContact) => {
    setEditingId(c.id);
    setEditName(c.nickname || c.name);
  };

  const handleSaveEdit = (id: string) => {
    if (editName.trim()) {
      onUpdateNickname(id, editName.trim());
    }
    setEditingId(null);
  };

  const handleManualAdd = (e: React.FormEvent) => {
    e.preventDefault();
    let stationId = manualStationId.trim();
    if (!stationId) return;

    if (stationId.includes('peer=')) {
      try {
        const u = new URL(stationId, window.location.origin);
        const p = u.searchParams.get('peer');
        if (p) stationId = p;
      } catch {}
    }

    const newContact: PeerContact = {
      id: stationId,
      ip: '',
      name: manualName.trim() || `חבר (${stationId.slice(0, 8)})`,
      nickname: manualName.trim() || stationId,
      lastSeen: Date.now()
    };

    onAddContactManual(newContact);
    setManualStationId('');
    setManualName('');
    setShowAddForm(false);
  };

  const formatLastSeen = (ts: number) => {
    if (!ts) return '';
    try {
      const d = new Date(ts);
      return d.toLocaleDateString('he-IL', {
        month: 'numeric',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return '';
    }
  };

  const filteredContacts = useMemo(() => {
    if (!searchQuery.trim()) return contacts;
    const q = searchQuery.toLowerCase().trim();
    return contacts.filter(
      (c) =>
        (c.nickname && c.nickname.toLowerCase().includes(q)) ||
        (c.name && c.name.toLowerCase().includes(q)) ||
        (c.ip && c.ip.toLowerCase().includes(q)) ||
        (c.city && c.city.toLowerCase().includes(q))
    );
  }, [contacts, searchQuery]);

  return (
    <div className="flex flex-col h-full space-y-3.5" dir="rtl">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-white tracking-tight">
            אנשי קשר וחברים
          </span>
          <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 font-mono text-[11px]">
            {contacts.length}
          </span>
        </div>

        <button
          type="button"
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors border border-slate-700/60 cursor-pointer"
          title="הוספת איש קשר חדש"
        >
          <Plus className="w-3.5 h-3.5 text-indigo-400" />
          <span>הוסף</span>
        </button>
      </div>

      {/* Discovered Devices on same Wi-Fi (Local Network) */}
      {nearbyDevices && nearbyDevices.length > 0 && (
        <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-sky-500" />
              </span>
              <Wifi className="w-3.5 h-3.5 text-sky-400" />
              מכשירים ברשת המקומית (אותו Wi-Fi):
            </span>
            <span className="text-[10px] text-sky-400/80 font-mono">
              {nearbyDevices.length} זוהו
            </span>
          </div>

          <div className="space-y-1.5">
            {nearbyDevices.map((dev) => (
              <div
                key={dev.stationId}
                className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800/80 hover:border-indigo-500/40 flex items-center justify-between gap-2 transition-all"
              >
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-slate-100 truncate">
                    {dev.userName}
                  </p>
                  <p className="text-[10px] text-slate-400 font-mono truncate">
                    מזהה: {dev.stationId}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    onCallNearby
                      ? onCallNearby(dev)
                      : onCallFriend({
                          id: dev.stationId,
                          name: dev.userName,
                          nickname: dev.userName,
                          ip: dev.clientIp,
                          lastSeen: Date.now()
                        })
                  }
                  className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1 shadow-xs transition-colors cursor-pointer shrink-0"
                >
                  <Phone className="w-3 h-3 fill-current" />
                  <span>התחבר</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Search Bar if contacts exist */}
      {contacts.length > 2 && (
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="חיפוש חבר לפי שם או מזהה..."
            className="w-full bg-slate-950/80 border border-slate-800 focus:border-indigo-500 rounded-xl pr-8 pl-8 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none transition-colors"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 p-0.5 rounded cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* Manual Add Form */}
      {showAddForm && (
        <form
          onSubmit={handleManualAdd}
          className="p-3.5 rounded-2xl bg-slate-950 border border-indigo-500/30 text-xs space-y-2.5 animate-in fade-in duration-150"
        >
          <div className="flex items-center justify-between font-medium text-slate-200">
            <span>הוספת איש קשר לפי מזהה תחנה (מספרים או אותיות):</span>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="text-slate-400 hover:text-slate-200"
            >
              ✕
            </button>
          </div>
          <div className="space-y-2">
            <input
              type="text"
              value={manualName}
              onChange={(e) => setManualName(e.target.value)}
              placeholder="כינוי (למשל: דני חבר)"
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
            />
            <input
              type="text"
              value={manualStationId}
              onChange={(e) => setManualStationId(e.target.value)}
              placeholder="מזהה תחנה (למשל: 123456 או dani_99) או קישור"
              dir="ltr"
              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-indigo-500"
            />
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-slate-200"
            >
              ביטול
            </button>
            <button
              type="submit"
              disabled={!manualStationId.trim()}
              className="px-4 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium disabled:opacity-40 transition-colors shadow-xs"
            >
              שמור חבר
            </button>
          </div>
        </form>
      )}

      {/* Contacts List */}
      <div className="space-y-2 overflow-y-auto max-h-[480px] pr-0.5">
        {contacts.length === 0 ? (
          <div className="p-6 rounded-2xl bg-slate-900/40 border border-dashed border-slate-800 text-center space-y-2">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 mx-auto flex items-center justify-center">
              <User className="w-5 h-5" />
            </div>
            <p className="text-xs font-semibold text-slate-200">עדיין אין חברים שמורים</p>
            <p className="text-[11px] text-slate-400 max-w-xs mx-auto leading-relaxed">
              שלח את מזהה התחנה או קישור ההזמנה שלך לכל חבר. כשהוא ייכנס, תוכל לתת לו כינוי והוא יישמר כאן לחיוג מיידי בלחיצה אחת!
            </p>
          </div>
        ) : filteredContacts.length === 0 ? (
          <div className="p-4 text-center text-xs text-slate-400">
            לא נמצאו חברים התואמים לחיפוש "{searchQuery}"
          </div>
        ) : (
          filteredContacts.map((c) => {
            const displayName = c.nickname || c.name || `חבר (${c.ip})`;
            const initial = displayName.trim().charAt(0) || 'ח';
            const gradient = getAvatarGradient(displayName);

            return (
              <div
                key={c.id}
                className="group relative bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-3 transition-all flex items-center justify-between gap-3 shadow-xs"
              >
                {/* Contact Left/Right Info: Avatar + Details */}
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {/* Social Initial Avatar */}
                  <div
                    className={`w-10 h-10 rounded-2xl bg-gradient-to-tr ${gradient} flex items-center justify-center text-white font-bold text-sm shrink-0 shadow-sm shadow-black/30 border border-white/10`}
                  >
                    {initial}
                  </div>

                  {/* Name and Meta */}
                  <div className="min-w-0 flex-1">
                    {editingId === c.id ? (
                      <div className="flex items-center gap-1.5">
                        <input
                          type="text"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="bg-slate-950 border border-indigo-500 rounded-lg px-2 py-0.5 text-xs text-slate-100 w-full focus:outline-none"
                          autoFocus
                        />
                        <button
                          type="button"
                          onClick={() => handleSaveEdit(c.id)}
                          className="p-1 rounded-lg bg-indigo-600 text-white hover:bg-indigo-500"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="text-xs font-bold text-slate-100 truncate">
                          {displayName}
                        </h4>
                        {c.mood && (
                          <span className="text-[10px] bg-slate-800/90 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-500/20 truncate font-normal">
                            {c.mood}
                          </span>
                        )}
                        <button
                          type="button"
                          onClick={() => handleStartEdit(c)}
                          className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-slate-300 p-0.5 transition-opacity"
                          title="ערוך כינוי"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                      </div>
                    )}

                    <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono truncate mt-0.5">
                      {c.ip && (
                        <span className="flex items-center gap-0.5 truncate text-slate-400">
                          <Globe className="w-2.5 h-2.5 text-slate-500 shrink-0" />
                          <span>{c.ip}</span>
                        </span>
                      )}
                      {(c.city || c.country) && (
                        <span className="text-slate-500 truncate hidden sm:inline">
                          • {c.city || c.country}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions: Direct Call Button + Delete */}
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => onCallFriend(c)}
                    className="flex items-center gap-1.5 py-1.5 px-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-xs hover:shadow-indigo-500/20 active:scale-95 transition-all cursor-pointer"
                    title={`התקשר אל ${displayName}`}
                  >
                    <Phone className="w-3 h-3 fill-current" />
                    <span>התקשר</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onDeleteContact(c.id)}
                    className="text-slate-600 hover:text-red-400 p-1.5 rounded-lg transition-colors cursor-pointer"
                    title="הסר איש קשר"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
