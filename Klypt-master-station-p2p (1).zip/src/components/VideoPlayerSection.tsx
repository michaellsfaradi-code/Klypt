import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { DataConnection, MediaConnection } from 'peerjs';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  Radio,
  FileVideo,
  MonitorPlay,
  Share2,
  Download,
  RotateCcw,
  Sparkles,
  Link as LinkIcon,
  Check,
  AlertCircle
} from 'lucide-react';
import { VideoSyncMessage, FileTransferProgress } from '../types';
import { sound } from '../utils/sound';

interface VideoPlayerSectionProps {
  conn: DataConnection | null;
  remotePeerId?: string;
  userName?: string;
  friendName?: string;
  onStartLiveStream?: (stream: MediaStream) => void;
  incomingStream?: MediaStream | null;
  onSendFileChunk?: (file: File) => void;
  transferProgress?: FileTransferProgress | null;
  incomingVideoChunk?: { buffer: ArrayBuffer; isLast?: boolean; mime?: string; name?: string } | null;
  onLogMessage: (text: string, type: 'me' | 'peer' | 'sys') => void;
}

interface FloatingReaction {
  id: string;
  emoji: string;
  label?: string;
  senderName?: string;
  x: number;
}

const SAMPLE_VIDEOS = [
  {
    title: 'Big Buck Bunny (Animation HD)',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'
  },
  {
    title: 'Tears of Steel (Sci-Fi 4K/HD)',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4'
  },
  {
    title: 'Elephants Dream (Classic Open Movie)',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4'
  }
];

export const VideoPlayerSection: React.FC<VideoPlayerSectionProps> = ({
  conn,
  remotePeerId,
  userName = 'אני',
  friendName = 'חבר',
  onStartLiveStream,
  incomingStream,
  transferProgress,
  incomingVideoChunk,
  onLogMessage
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [videoSrc, setVideoSrc] = useState<string>('');
  const [videoTitle, setVideoTitle] = useState<string>('לא נבחר סרטון');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolume] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [urlInput, setUrlInput] = useState<string>('');
  const [showUrlModal, setShowUrlModal] = useState<boolean>(false);
  const [isLiveStreaming, setIsLiveStreaming] = useState<boolean>(false);
  const [isMseStreaming, setIsMseStreaming] = useState<boolean>(false);
  const [watchPartySync, setWatchPartySync] = useState<boolean>(true);
  const [downloadBlobUrl, setDownloadBlobUrl] = useState<string | null>(null);
  const [downloadFilename, setDownloadFilename] = useState<string>('');

  // MSE Streaming refs
  const mediaSourceRef = useRef<MediaSource | null>(null);
  const sourceBufferRef = useRef<SourceBuffer | null>(null);
  const chunkQueueRef = useRef<ArrayBuffer[]>([]);
  const isMseActiveRef = useRef<boolean>(false);
  const chunksAppendedRef = useRef<number>(0);

  // Floating live emoji reactions on video
  const [floatingReactions, setFloatingReactions] = useState<FloatingReaction[]>([]);

  // Flag to avoid sync feedback loops
  const isRemoteAction = useRef<boolean>(false);

  const onLogMessageRef = useRef(onLogMessage);
  onLogMessageRef.current = onLogMessage;

  const triggerReaction = useCallback(
    (emoji: string, label?: string, sender?: string, isLocal = false) => {
      const newId = Math.random().toString(36).substring(2) + Date.now();
      const x = Math.floor(Math.random() * 60) + 20; // 20% to 80%
      setFloatingReactions((prev) => [...prev.slice(-8), { id: newId, emoji, label, senderName: sender, x }]);
      sound.playReaction();

      setTimeout(() => {
        setFloatingReactions((prev) => prev.filter((r) => r.id !== newId));
      }, 2500);

      if (isLocal && conn && conn.open) {
        try {
          conn.send({
            type: 'video_reaction',
            emoji,
            label,
            senderName: userName || 'אני',
            timestamp: Date.now()
          });
        } catch (err) {
          console.warn('Failed to send video reaction:', err);
        }
      }
    },
    [conn, userName]
  );

  // Mount incoming live stream if sent by peer
  useEffect(() => {
    if (incomingStream && videoRef.current) {
      videoRef.current.srcObject = incomingStream;
      videoRef.current.play().catch(() => {});
      setVideoTitle('שידור וידאו חי מהחבר (Live P2P Stream)');
      setIsPlaying(true);
      onLogMessageRef.current('התקבל שידור וידאו חי מהחבר!', 'peer');
      sound.playConnect();
    }
  }, [incomingStream]);

  // Helper to drain queued buffers into the SourceBuffer
  const drainSourceBufferQueue = useCallback(() => {
    const sb = sourceBufferRef.current;
    if (!sb || sb.updating || chunkQueueRef.current.length === 0) return;
    try {
      const nextChunk = chunkQueueRef.current.shift();
      if (nextChunk) {
        sb.appendBuffer(nextChunk);
        chunksAppendedRef.current++;
        // If we have appended at least 2 chunks and video is paused, trigger play
        if (chunksAppendedRef.current >= 2 && videoRef.current && videoRef.current.paused) {
          videoRef.current.play().catch(() => {});
          setIsPlaying(true);
        }
      }
    } catch (e) {
      console.warn('SourceBuffer append error, falling back to Blob:', e);
      isMseActiveRef.current = false;
      setIsMseStreaming(false);
    }
  }, []);

  // Process incoming video chunk via MSE Streaming (with automatic Blob fallback)
  useEffect(() => {
    if (!incomingVideoChunk || !incomingVideoChunk.buffer) return;

    const { buffer, isLast, mime, name } = incomingVideoChunk;
    const targetMime = mime || 'video/mp4; codecs="avc1.42E01E, mp4a.40.2"';

    // If MSE is not active yet, initialize it if supported
    if (!isMseActiveRef.current && typeof window !== 'undefined' && window.MediaSource) {
      const canPlay = MediaSource.isTypeSupported(targetMime) || MediaSource.isTypeSupported('video/mp4');
      if (canPlay) {
        try {
          const ms = new MediaSource();
          mediaSourceRef.current = ms;
          chunksAppendedRef.current = 0;
          chunkQueueRef.current = [];

          const objUrl = URL.createObjectURL(ms);
          if (videoRef.current) {
            videoRef.current.srcObject = null;
            videoRef.current.src = objUrl;
          }

          ms.addEventListener('sourceopen', () => {
            try {
              const supportedType = MediaSource.isTypeSupported(targetMime) ? targetMime : 'video/mp4';
              const sb = ms.addSourceBuffer(supportedType);
              sourceBufferRef.current = sb;

              sb.addEventListener('updateend', () => {
                drainSourceBufferQueue();
              });

              sb.addEventListener('error', () => {
                console.warn('SourceBuffer error event, falling back to Blob');
                isMseActiveRef.current = false;
                setIsMseStreaming(false);
              });

              drainSourceBufferQueue();
            } catch (err) {
              console.warn('Failed creating SourceBuffer, fallback to Blob:', err);
              isMseActiveRef.current = false;
              setIsMseStreaming(false);
            }
          });

          isMseActiveRef.current = true;
          setIsMseStreaming(true);
          setVideoTitle(name ? `${name} (שידור MSE חי)` : 'שידור וידאו חי');
        } catch (e) {
          console.warn('Failed initializing MediaSource, fallback to standard Blob:', e);
          isMseActiveRef.current = false;
          setIsMseStreaming(false);
        }
      }
    }

    // Push buffer to queue and drain if MSE is active
    if (isMseActiveRef.current) {
      chunkQueueRef.current.push(buffer);
      drainSourceBufferQueue();

      if (isLast && mediaSourceRef.current && mediaSourceRef.current.readyState === 'open') {
        const sb = sourceBufferRef.current;
        if (sb && !sb.updating && chunkQueueRef.current.length === 0) {
          try {
            mediaSourceRef.current.endOfStream();
          } catch {
            // Ignore end of stream error
          }
        }
      }
    }
  }, [incomingVideoChunk, drainSourceBufferQueue]);

  // Handle incoming transfer video completion (Blob Fallback & Finalization)
  useEffect(() => {
    if (transferProgress?.status === 'completed' && transferProgress.url) {
      setDownloadBlobUrl(transferProgress.url);
      setDownloadFilename(transferProgress.name);

      // If MSE was not active or failed, load standard Blob URL
      if (!isMseActiveRef.current || !videoRef.current?.src) {
        setVideoSrc(transferProgress.url);
        setVideoTitle(transferProgress.name);
        if (videoRef.current) {
          videoRef.current.srcObject = null;
          videoRef.current.src = transferProgress.url;
          videoRef.current.load();
          videoRef.current.play().catch(() => {});
        }
      }

      sound.playFileReady();
      onLogMessageRef.current(`קובץ וידאו מוכן לצפייה: ${transferProgress.name}`, 'sys');
    }
  }, [transferProgress?.status, transferProgress?.url, transferProgress?.name]);

  // Listen for sync messages & reactions from Peer
  useEffect(() => {
    if (!conn) return;

    const handleData = (data: unknown) => {
      const msg = data as Record<string, any>;
      if (!msg || typeof msg !== 'object') return;

      // Realtime video reaction
      if (msg.type === 'video_reaction') {
        triggerReaction(msg.emoji, msg.label, msg.senderName || friendName || 'חבר', false);
        return;
      }

      if (msg.type !== 'video_sync') return;
      if (!watchPartySync) return;

      const v = videoRef.current;
      if (!v) return;

      isRemoteAction.current = true;

      if (msg.action === 'load_url' && msg.url) {
        v.srcObject = null;
        v.src = msg.url;
        setVideoSrc(msg.url);
        setVideoTitle(msg.title || 'סרטון משותף מהחבר');
        v.load();
        onLogMessage(`החבר טען סרטון: ${msg.title || msg.url}`, 'peer');
      } else if (msg.action === 'play') {
        if (Math.abs(v.currentTime - msg.currentTime) > 0.6) {
          v.currentTime = msg.currentTime;
        }
        v.play().catch(() => {});
        setIsPlaying(true);
      } else if (msg.action === 'pause') {
        v.pause();
        if (Math.abs(v.currentTime - msg.currentTime) > 0.6) {
          v.currentTime = msg.currentTime;
        }
        setIsPlaying(false);
      } else if (msg.action === 'seek') {
        v.currentTime = msg.currentTime;
        setCurrentTime(msg.currentTime);
      } else if (msg.action === 'speed' && msg.playbackRate) {
        v.playbackRate = msg.playbackRate;
        setPlaybackRate(msg.playbackRate);
      }

      setTimeout(() => {
        isRemoteAction.current = false;
      }, 300);
    };

    conn.on('data', handleData);
    return () => {
      conn.off('data', handleData);
    };
  }, [conn, watchPartySync, onLogMessage, triggerReaction, friendName]);

  const sendSync = useCallback(
    (action: VideoSyncMessage['action'], extra?: Partial<VideoSyncMessage>) => {
      if (!conn || !conn.open || !watchPartySync || isRemoteAction.current) return;
      const v = videoRef.current;
      const payload: VideoSyncMessage = {
        type: 'video_sync',
        action,
        currentTime: v ? v.currentTime : 0,
        playbackRate: v ? v.playbackRate : 1,
        timestamp: Date.now(),
        ...extra
      };
      try {
        conn.send(payload);
      } catch (err) {
        console.error('Failed to send video sync:', err);
      }
    },
    [conn, watchPartySync]
  );

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) {
      v.play()
        .then(() => {
          setIsPlaying(true);
          sendSync('play');
        })
        .catch(() => {});
    } else {
      v.pause();
      setIsPlaying(false);
      sendSync('pause');
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = videoRef.current;
    if (!v) return;
    const time = parseFloat(e.target.value);
    v.currentTime = time;
    setCurrentTime(time);
    sendSync('seek', { currentTime: time });
  };

  const handleSpeedChange = (rate: number) => {
    const v = videoRef.current;
    if (!v) return;
    v.playbackRate = rate;
    setPlaybackRate(rate);
    sendSync('speed', { playbackRate: rate });
  };

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = videoRef.current;
    if (!v) return;
    const val = parseFloat(e.target.value);
    v.volume = val;
    setVolume(val);
    setIsMuted(val === 0);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  // Local file selection
  const handleLocalFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (downloadBlobUrl) {
      URL.revokeObjectURL(downloadBlobUrl);
    }

    const objUrl = URL.createObjectURL(file);
    setVideoSrc(objUrl);
    setVideoTitle(file.name);
    setDownloadBlobUrl(objUrl);
    setDownloadFilename(file.name);

    if (videoRef.current) {
      videoRef.current.srcObject = null;
      videoRef.current.src = objUrl;
      videoRef.current.load();
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }

    onLogMessage(`נטען קובץ מקומי: ${file.name}`, 'me');
  };

  // Stream local playing video directly to peer in real-time via captureStream!
  const startLiveStreamToPeer = async () => {
    const v = videoRef.current;
    if (!v) return;
    if (!conn || !conn.open) {
      alert('יש להתחבר לחבר קודם כדי לשדר לו בזמן אמת');
      return;
    }

    try {
      // Use standard captureStream / mozCaptureStream
      const streamCapturer = (v as any).captureStream || (v as any).mozCaptureStream;
      if (!streamCapturer) {
        alert('דפדפן זה אינו תומך ב-captureStream ישיר. אפשר להשתמש בשיתוף מסך במקום!');
        return;
      }

      const stream: MediaStream = streamCapturer.call(v);
      if (onStartLiveStream) {
        onStartLiveStream(stream);
        setIsLiveStreaming(true);
        onLogMessage('משדר כעת את הסרטון לחבר בשידור חי (P2P Stream)!', 'me');
      }
    } catch (err: any) {
      alert('שגיאה בהפעלת שידור חי: ' + (err?.message || err));
    }
  };

  // Screen share to watch anything (YouTube, Netflix, etc.) together live
  const startScreenShareLive = async () => {
    if (!conn || !conn.open) {
      alert('יש להתחבר לחבר קודם');
      return;
    }
    try {
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true
      });

      if (videoRef.current) {
        videoRef.current.srcObject = displayStream;
        videoRef.current.play().catch(() => {});
        setVideoTitle('שיתוף מסך חי (Screen Share Watch Party)');
      }

      if (onStartLiveStream) {
        onStartLiveStream(displayStream);
        setIsLiveStreaming(true);
        onLogMessage('משתף מסך עם החבר בזמן אמת!', 'me');
      }

      displayStream.getVideoTracks()[0].onended = () => {
        setIsLiveStreaming(false);
        onLogMessage('שיתוף המסך הסתיים', 'sys');
      };
    } catch (err: any) {
      if (err.name !== 'NotAllowedError') {
        alert('שגיאה בשיתוף מסך: ' + err.message);
      }
    }
  };

  const loadPresetUrl = (sample: { title: string; url: string }) => {
    setVideoSrc(sample.url);
    setVideoTitle(sample.title);
    setShowUrlModal(false);
    if (videoRef.current) {
      videoRef.current.srcObject = null;
      videoRef.current.src = sample.url;
      videoRef.current.load();
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
    sendSync('load_url', { url: sample.url, title: sample.title });
    onLogMessage(`טוען סרטון דוגמה: ${sample.title}`, 'me');
  };

  const handleCustomUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    const url = urlInput.trim();
    setVideoSrc(url);
    setVideoTitle('סרטון מקוון: ' + url.slice(0, 30));
    setShowUrlModal(false);
    if (videoRef.current) {
      videoRef.current.srcObject = null;
      videoRef.current.src = url;
      videoRef.current.load();
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
    sendSync('load_url', { url, title: 'סרטון רשת' });
    setUrlInput('');
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-[#121620] border border-slate-800/80 rounded-2xl p-4 md:p-5 shadow-xl transition-all duration-300">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <MonitorPlay className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              נגן סרטים & שיתוף וידאו P2P
              {isLiveStreaming && (
                <span className="inline-flex items-center gap-1 text-[11px] font-mono px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse">
                  <Radio className="w-3 h-3" /> LIVE
                </span>
              )}
              {isMseStreaming && (
                <span className="inline-flex items-center gap-1 text-[11px] font-mono px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/40 animate-pulse">
                  <Sparkles className="w-3 h-3 text-sky-400" /> MSE Stream
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-400 line-clamp-1">{videoTitle}</p>
          </div>
        </div>

        {/* Watch Party toggle */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setWatchPartySync(!watchPartySync)}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium border flex items-center gap-1.5 transition-colors ${
              watchPartySync
                ? 'bg-indigo-500/15 border-indigo-500/40 text-indigo-300'
                : 'bg-slate-800/80 border-slate-700 text-slate-400'
            }`}
            title="סנכרן פעולות ניגון/עצירה בין שניכם"
          >
            <Sparkles className="w-3.5 h-3.5" />
            {watchPartySync ? 'סנכרון סרטים פעיל (Watch Party)' : 'סנכרון כבוי'}
          </button>
        </div>
      </div>

      {/* Video Container */}
      <div
        ref={containerRef}
        className="relative group bg-black rounded-xl overflow-hidden aspect-video flex items-center justify-center border border-slate-800 shadow-2xl"
      >
        {/* Floating Emoji Reactions Overlay */}
        {floatingReactions.map((r) => (
          <div
            key={r.id}
            style={{ left: `${r.x}%`, bottom: '25%' }}
            className="absolute pointer-events-none z-30 flex flex-col items-center animate-bounce transition-all duration-1000 transform -translate-x-1/2"
          >
            <span className="text-4xl drop-shadow-lg filter select-none animate-pulse">{r.emoji}</span>
            {r.senderName && (
              <span className="text-[10px] bg-slate-900/95 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30 shadow-md mt-1 whitespace-nowrap">
                {r.senderName}
              </span>
            )}
          </div>
        ))}

        <video
          ref={videoRef}
          playsInline
          className="w-full h-full object-contain cursor-pointer"
          onClick={togglePlay}
          onTimeUpdate={() => {
            if (videoRef.current) setCurrentTime(videoRef.current.currentTime);
          }}
          onLoadedMetadata={() => {
            if (videoRef.current) setDuration(videoRef.current.duration);
          }}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
        />

        {/* Empty state overlay if no source loaded */}
        {!videoSrc && !incomingStream && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-slate-950/80 backdrop-blur-sm pointer-events-none">
            <div className="w-14 h-14 rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center text-slate-400 mb-3">
              <FileVideo className="w-7 h-7 text-indigo-400" />
            </div>
            <p className="text-sm font-semibold text-slate-200 mb-1">הנגן מוכן לפעולה</p>
            <p className="text-xs text-slate-400 max-w-md">
              בחר קובץ סרטון מהמחשב, הדבק קישור ישיר, נסה סרטון הדגמה בלחיצה, או פתח שיתוף מסך/שידור חי P2P
            </p>
          </div>
        )}

        {/* Big play button on pause */}
        {!isPlaying && (videoSrc || incomingStream) && (
          <button
            type="button"
            onClick={togglePlay}
            className="absolute z-10 w-16 h-16 rounded-full bg-indigo-600/90 hover:bg-indigo-500 text-white flex items-center justify-center shadow-lg shadow-indigo-950/50 hover:scale-105 transition-transform"
          >
            <Play className="w-8 h-8 fill-current translate-x-0.5" />
          </button>
        )}

        {/* Video Control Bar Overlay */}
        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-3 pt-6 flex flex-col gap-2 opacity-95 group-hover:opacity-100 transition-opacity">
          {/* Progress Seekbar */}
          <div className="flex items-center gap-2">
            <input
              type="range"
              min={0}
              max={duration || 100}
              step={0.1}
              value={currentTime}
              onChange={handleSeek}
              disabled={!duration || isLiveStreaming}
              className="w-full h-1.5 bg-slate-700/80 rounded-lg appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-between text-xs text-slate-300">
            {/* Left controls */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={togglePlay}
                className="hover:text-indigo-400 transition-colors p-1"
                title={isPlaying ? 'עצור' : 'נגן'}
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
              </button>

              <div className="flex items-center gap-1.5 group/vol">
                <button
                  type="button"
                  onClick={toggleMute}
                  className="hover:text-indigo-400 transition-colors p-1"
                >
                  {isMuted || volume === 0 ? (
                    <VolumeX className="w-4 h-4 text-red-400" />
                  ) : (
                    <Volume2 className="w-4 h-4" />
                  )}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={isMuted ? 0 : volume}
                  onChange={handleVolumeChange}
                  className="w-16 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                />
              </div>

              <span className="font-mono text-[11px] text-slate-400">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>
            </div>

            {/* Right controls */}
            <div className="flex items-center gap-2">
              {/* Speed toggle */}
              <div className="flex items-center bg-slate-800/80 rounded-lg px-1.5 py-0.5 border border-slate-700 text-[11px] font-mono">
                {[0.75, 1, 1.25, 1.5, 2].map((rate) => (
                  <button
                    key={rate}
                    type="button"
                    onClick={() => handleSpeedChange(rate)}
                    className={`px-1 rounded ${playbackRate === rate ? 'text-indigo-400 font-bold' : 'text-slate-400'}`}
                  >
                    {rate}x
                  </button>
                ))}
              </div>

              {/* Download if blob exists */}
              {downloadBlobUrl && (
                <a
                  href={downloadBlobUrl}
                  download={downloadFilename || 'video.mp4'}
                  className="p-1 hover:text-indigo-400 text-slate-400 transition-colors"
                  title="הורד קובץ סרטון למחשב"
                >
                  <Download className="w-4 h-4" />
                </a>
              )}

              <button
                type="button"
                onClick={toggleFullscreen}
                className="hover:text-indigo-400 transition-colors p-1"
                title="מסך מלא"
              >
                {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Social Watch Party Reaction Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 mt-3 shadow-sm">
        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-200">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>תגובות חיות לסרט (Watch Party Reactions):</span>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          {[
            { emoji: '🍿', label: 'פופקורן' },
            { emoji: '🔥', label: 'אש' },
            { emoji: '😂', label: 'קורע' },
            { emoji: '👏', label: 'כפיים' },
            { emoji: '❤️', label: 'אהבתי' },
            { emoji: '😱', label: 'הלם' },
            { emoji: '🎉', label: 'מסיבה' }
          ].map((item) => (
            <button
              key={item.emoji}
              type="button"
              onClick={() => triggerReaction(item.emoji, item.label, userName, true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 hover:scale-105 active:scale-95 border border-slate-700 hover:border-amber-400/50 text-xs font-medium text-slate-200 transition-all cursor-pointer shadow-xs"
              title={`שלח תגובת ${item.label}`}
            >
              <span className="text-sm">{item.emoji}</span>
              <span className="text-[11px] text-slate-300">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Transfer progress bar if receiving/sending file */}
      {transferProgress && transferProgress.status === 'transferring' && (
        <div className="mt-3 p-3 rounded-xl bg-slate-900/90 border border-amber-500/30">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="font-semibold text-amber-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              {transferProgress.direction === 'sending' ? 'שולח סרטון לחבר:' : 'מקבל סרטון מהחבר:'}{' '}
              {transferProgress.name}
            </span>
            <span className="font-mono text-slate-300">
              {transferProgress.progress}% ({Math.round(transferProgress.transferred / 1024 / 1024)}MB /{' '}
              {Math.round(transferProgress.size / 1024 / 1024)}MB)
            </span>
          </div>
          <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-150"
              style={{ width: `${transferProgress.progress}%` }}
            />
          </div>
          <div className="flex justify-between items-center text-[11px] text-slate-400 mt-1 font-mono">
            <span>מהירות: {(transferProgress.speedBps / 1024 / 1024).toFixed(2)} MB/s</span>
            <span>עובר בערוץ P2P ישיר ומאובטח</span>
          </div>
        </div>
      )}

      {/* Action Buttons Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4">
        {/* Local file picker */}
        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          className="hidden"
          onChange={handleLocalFileSelect}
        />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700 text-slate-200 text-xs font-medium transition-all"
        >
          <FileVideo className="w-4 h-4 text-indigo-400" />
          בחר סרטון מהמחשב
        </button>

        {/* Live stream to peer */}
        <button
          type="button"
          onClick={startLiveStreamToPeer}
          disabled={!videoSrc || !conn}
          className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:pointer-events-none text-white text-xs font-semibold shadow-md shadow-indigo-950/40 transition-all"
          title="שדר את הסרט שמתנגן אצלך בשידור חי לחבר (ללא המתנה להורדה!)"
        >
          <Radio className="w-4 h-4" />
          שדר סרטון חי לחבר
        </button>

        {/* Screen share */}
        <button
          type="button"
          onClick={startScreenShareLive}
          disabled={!conn}
          className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-sky-600/20 hover:bg-sky-600/30 border border-sky-500/40 text-sky-300 text-xs font-medium transition-all disabled:opacity-40"
          title="שתף מסך / חלון / לשונית דפדפן לצפייה משותפת בזמן אמת"
        >
          <Share2 className="w-4 h-4 text-sky-400" />
          שיתוף מסך חי (Watch Together)
        </button>

        {/* Load URL / Samples */}
        <button
          type="button"
          onClick={() => setShowUrlModal(true)}
          className="flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700 text-slate-200 text-xs font-medium transition-all"
        >
          <LinkIcon className="w-4 h-4 text-cyan-400" />
          קישור / סרטי הדגמה
        </button>
      </div>

      {/* URL & Sample Modal */}
      {showUrlModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-[#121620] border border-slate-700 rounded-2xl max-w-md w-full p-5 shadow-2xl">
            <h3 className="text-base font-semibold text-slate-100 mb-2">טעינת סרטון לצפייה משותפת</h3>
            <p className="text-xs text-slate-400 mb-4">
              הדבק כתובת URL ישירה לקובץ וידאו (MP4 / WebM), או בחר באחד מסרטוני ההדגמה:
            </p>

            <form onSubmit={handleCustomUrlSubmit} className="mb-4">
              <div className="flex gap-2">
                <input
                  type="url"
                  placeholder="https://example.com/movie.mp4"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  dir="ltr"
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-sm"
                >
                  טען
                </button>
              </div>
            </form>

            <div className="space-y-2 mb-4">
              <span className="text-xs font-medium text-slate-400">סרטוני הדגמה מהירים (Ready to test):</span>
              {SAMPLE_VIDEOS.map((s, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => loadPresetUrl(s)}
                  className="w-full text-right p-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 hover:border-slate-700 text-xs text-slate-200 flex items-center justify-between transition-colors"
                >
                  <span>{s.title}</span>
                  <span className="text-[10px] font-mono text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/30">
                    טען סרטון
                  </span>
                </button>
              ))}
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setShowUrlModal(false)}
                className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 font-medium"
              >
                סגור
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
