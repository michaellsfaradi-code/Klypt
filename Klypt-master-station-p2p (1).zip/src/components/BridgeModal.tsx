import React, { useState } from 'react';
import {
  Share2,
  Copy,
  Check,
  Users,
  Network,
  X,
  ShieldCheck,
  Radio,
  Key,
  ExternalLink
} from 'lucide-react';
import { GroupParticipant } from '../types';
import { copyToClipboard } from '../utils/clipboard';

interface BridgeModalProps {
  isOpen: boolean;
  onClose: () => void;
  myId: string;
  connectedPeerIds: string[];
  participants: GroupParticipant[];
}

export const BridgeModal: React.FC<BridgeModalProps> = ({
  isOpen,
  onClose,
  myId,
  connectedPeerIds,
  participants
}) => {
  const [copiedId, setCopiedId] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedToken, setCopiedToken] = useState(false);

  if (!isOpen) return null;

  // Build the bridge token and shareable URL
  const allPeers = Array.from(new Set([myId, ...connectedPeerIds]));
  const tokenPayload = {
    type: 'p2p_bridge_v1',
    host: myId,
    peers: allPeers,
    timestamp: Date.now()
  };
  const bridgeToken = `BRIDGE-${btoa(JSON.stringify(tokenPayload))}`;

  const bridgeUrl = `${window.location.origin}${window.location.pathname}?bridge=1&host=${encodeURIComponent(
    myId
  )}&peers=${encodeURIComponent(allPeers.join(','))}&token=${encodeURIComponent(bridgeToken)}`;

  const handleCopyId = async () => {
    const ok = await copyToClipboard(myId);
    if (ok) {
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  const handleCopyLink = async () => {
    const ok = await copyToClipboard(bridgeUrl);
    if (ok) {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const handleCopyToken = async () => {
    const ok = await copyToClipboard(bridgeToken);
    if (ok) {
      setCopiedToken(true);
      setTimeout(() => setCopiedToken(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200" dir="rtl">
      <div className="relative w-full max-w-lg bg-[#0f141c] border border-indigo-500/30 rounded-3xl p-6 sm:p-7 shadow-[0_20px_60px_rgba(0,0,0,0.8),0_0_30px_rgba(99,102,241,0.15)] text-right flex flex-col max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 left-5 text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 pb-4 border-b border-slate-800/80">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-sky-500 flex items-center justify-center text-white shadow-md border border-indigo-400/30 shrink-0">
            <Network className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                מצב גשר (Bridge Mode) — צ'אט קבוצתי
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-[10px] text-indigo-300 font-semibold">
                P2P Mesh
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              שתף מזהה, קישור או טוקן כדי לצרף אדם שלישי לשיחה הקבוצתית
            </p>
          </div>
        </div>

        {/* Body content */}
        <div className="py-4 space-y-4 text-xs">
          {/* Visual Mesh Architecture Diagram */}
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-around text-center">
            <div className="flex flex-col items-center gap-1">
              <div className="w-9 h-9 rounded-xl bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 flex items-center justify-center font-bold text-xs">
                אני
              </div>
              <span className="text-[10px] text-slate-300">גשר ראשי (Host)</span>
            </div>

            <div className="h-0.5 flex-1 bg-gradient-to-r from-indigo-500 via-sky-400 to-indigo-500 mx-2 relative flex items-center justify-center">
              <span className="absolute -top-3 text-[9px] text-indigo-300 font-mono">חיבור פעיל</span>
            </div>

            <div className="flex flex-col items-center gap-1">
              <div className="w-9 h-9 rounded-xl bg-sky-500/20 border border-sky-500/40 text-sky-400 flex items-center justify-center font-bold text-xs">
                חבר 1
              </div>
              <span className="text-[10px] text-slate-300">
                {participants.find((p) => !p.isMe)?.name || 'מחובר'}
              </span>
            </div>

            <div className="h-0.5 flex-1 border-t-2 border-dashed border-indigo-500/60 mx-2 relative flex items-center justify-center">
              <span className="absolute -top-3 text-[9px] text-indigo-300 font-mono">+ משתתף 3</span>
            </div>

            <div className="flex flex-col items-center gap-1">
              <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-400 flex items-center justify-center font-bold text-xs">
                +3
              </div>
              <span className="text-[10px] text-slate-300">אדם שלישי</span>
            </div>
          </div>

          {/* Current Participants in Session */}
          <div className="space-y-1.5">
            <span className="text-xs font-semibold text-slate-200 block">
              משתתפים נוכחיים ({participants.length}):
            </span>
            <div className="flex flex-wrap gap-2">
              {participants.map((p) => (
                <div
                  key={p.id}
                  className="px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700/60 flex items-center gap-2 text-xs"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span className="font-medium text-slate-200">
                    {p.name} {p.isMe && '(אני)'}
                  </span>
                  {p.ip && (
                    <span className="text-[10px] text-slate-400 font-mono">
                      {p.ip}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Option 1 (Default): Host Station ID (ברירת מחדל אמינה אם הקישור לא עובד) */}
          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-indigo-500/40 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
              <span className="flex items-center gap-1.5 text-indigo-400">
                <Key className="w-3.5 h-3.5" />
                מזהה גשר להתחברות (ברירת מחדל):
              </span>
              {copiedId && (
                <span className="text-[11px] text-indigo-300 font-bold animate-in fade-in">
                  המזהה הועתק! ✓
                </span>
              )}
            </div>

            <div className="flex gap-2">
              <div
                onClick={handleCopyId}
                dir="ltr"
                className="flex-1 bg-slate-950/80 border border-slate-800 hover:border-indigo-500/40 rounded-xl px-3 py-2 font-mono text-xs text-indigo-300 truncate cursor-pointer transition-colors select-all font-bold"
                title="לחץ להעתקת המזהה"
              >
                {myId}
              </div>

              <button
                type="button"
                onClick={handleCopyId}
                className={`flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer shadow-xs ${
                  copiedId
                    ? 'bg-indigo-500 text-white'
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                }`}
              >
                {copiedId ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedId ? 'הועתק' : 'העתק מזהה'}</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              האדם השלישי מדביק מזהה זה בתיבת ההתחברות ומתחבר ישירות לגשר (עובד תמיד גם אם הקישור נחסם).
            </p>
          </div>

          {/* Option 2: Direct Bridge Join Link */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
              <span className="flex items-center gap-1.5 text-slate-300">
                <Share2 className="w-3.5 h-3.5 text-sky-400" />
                קישור גשר ישיר (פתחי בדפדפן):
              </span>
              {copiedLink && (
                <span className="text-[11px] text-sky-400 font-bold animate-in fade-in">
                  הקישור הועתק! ✓
                </span>
              )}
            </div>

            <div className="flex gap-2">
              <div
                onClick={handleCopyLink}
                dir="ltr"
                className="flex-1 bg-slate-950/80 border border-slate-800 hover:border-slate-700 rounded-xl px-3 py-2 font-mono text-xs text-slate-300 truncate cursor-pointer transition-colors select-all"
                title="לחץ להעתקת הקישור"
              >
                {bridgeUrl}
              </div>

              <button
                type="button"
                onClick={handleCopyLink}
                className="flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium transition-all shrink-0 cursor-pointer"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5 text-sky-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'הועתק' : 'העתק קישור'}</span>
              </button>
            </div>
          </div>

          {/* Option 3: Bridge Token String */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
              <span className="flex items-center gap-1.5 text-slate-300">
                <Radio className="w-3.5 h-3.5 text-indigo-400" />
                טוקן חיבור גשר מלא (Bridge Token):
              </span>
              {copiedToken && (
                <span className="text-[11px] text-indigo-300 font-bold animate-in fade-in">
                  הטוקן הועתק! ✓
                </span>
              )}
            </div>

            <div className="flex gap-2">
              <div
                onClick={handleCopyToken}
                dir="ltr"
                className="flex-1 bg-slate-950/80 border border-slate-800 hover:border-slate-700 rounded-xl px-3 py-2 font-mono text-[11px] text-slate-400 truncate cursor-pointer transition-colors select-all"
                title="לחץ להעתקת הטוקן"
              >
                {bridgeToken}
              </div>

              <button
                type="button"
                onClick={handleCopyToken}
                className="flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium transition-all shrink-0 cursor-pointer"
              >
                {copiedToken ? <Check className="w-3.5 h-3.5 text-indigo-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedToken ? 'הועתק' : 'העתק טוקן'}</span>
              </button>
            </div>
          </div>

          {/* Bridge explanation banner */}
          <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 flex items-start gap-2.5 text-[11px] text-slate-400">
            <ShieldCheck className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>איך זה עובד?</strong> הדפדפן שלך משמש כגשר ניתוב (P2P Relay & Mesh Bridge). כל הודעה שנשלחת בקבוצה תועבר מיד לכל המשתתפים בצורה ישירה, מוצפנת ומאובטחת מקצה לקצה.
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="pt-2 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            סגור חלון
          </button>
        </div>
      </div>
    </div>
  );
};
