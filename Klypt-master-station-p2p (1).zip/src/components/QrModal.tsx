import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { QrCode, X, Copy, Check } from 'lucide-react';
import { copyToClipboard } from '../utils/clipboard';

interface QrModalProps {
  isOpen: boolean;
  onClose: () => void;
  url: string;
  peerId: string;
}

export const QrModal: React.FC<QrModalProps> = ({ isOpen, onClose, url, peerId }) => {
  const [dataUrl, setDataUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (!url || !isOpen) return;
    QRCode.toDataURL(url, {
      width: 320,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#ffffff'
      }
    })
      .then(setDataUrl)
      .catch((err) => console.error('QR generation error:', err));
  }, [url, isOpen]);

  const handleCopy = async () => {
    const success = await copyToClipboard(url);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-[#141824] border border-slate-700/80 rounded-2xl max-w-sm w-full p-5 shadow-2xl text-center">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <QrCode className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-slate-100">סריקת קוד QR להתחברות מהירה</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-400 mb-3">
          סרוק עם הטלפון או שתף את הקוד כדי להתחבר מיד ללא צורך בהקלדת קישור:
        </p>

        <div className="bg-white p-3 rounded-xl inline-block shadow-lg mx-auto mb-3">
          {dataUrl ? (
            <img src={dataUrl} alt="Connect QR Code" className="w-56 h-56 mx-auto block" />
          ) : (
            <div className="w-56 h-56 flex items-center justify-center text-slate-800 text-xs font-mono">
              מייצר קוד QR...
            </div>
          )}
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-2 font-mono text-[11px] text-emerald-400 truncate mb-3 select-all">
          ID: {peerId}
        </div>

        <button
          type="button"
          onClick={handleCopy}
          className="w-full flex items-center justify-center gap-2 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-semibold shadow-md transition-all"
        >
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          {copied ? 'הקישור הועתק בהצלחה!' : 'העתק קישור ישיר'}
        </button>
      </div>
    </div>
  );
};
