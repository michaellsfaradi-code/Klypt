import React, { useEffect, useState } from 'react';
import { Phone, PhoneOff, Globe, BellRing, Volume2 } from 'lucide-react';

interface IncomingCallModalProps {
  callerIp: string;
  callerName?: string;
  callerCity?: string;
  callerCountry?: string;
  onAnswer: () => void;
  onDecline: () => void;
}

export const IncomingCallModal: React.FC<IncomingCallModalProps> = ({
  callerIp,
  callerName,
  callerCity,
  callerCountry,
  onAnswer,
  onDecline
}) => {
  const displayName = callerName || 'חבר';
  const [pulseRing, setPulseRing] = useState(true);

  // Periodic pulse animation to match ring interval
  useEffect(() => {
    const int = setInterval(() => {
      setPulseRing((p) => !p);
    }, 600);
    return () => clearInterval(int);
  }, []);

  return (
    <>
      {/* Subtle backdrop overlay */}
      <div 
        className="fixed inset-0 z-40 bg-slate-950/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
        onClick={onDecline}
      />

      {/* Urgent Dropdown Call Alert Banner (התראת שיחה חופרת וקופצת מלמעלה) */}
      <aside
        aria-label="התראת שיחה נכנסת"
        className="fixed top-3 sm:top-5 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-lg transition-all transform animate-in slide-in-from-top-6 duration-300 ease-out"
        dir="rtl"
      >
        <div className="relative overflow-hidden rounded-2xl bg-slate-900/95 border-2 border-emerald-500/80 shadow-[0_16px_50px_rgba(0,0,0,0.8),0_0_30px_rgba(16,185,129,0.35)] backdrop-blur-xl p-4 sm:p-5">
          {/* Top highlight bar */}
          <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 animate-pulse" />

          {/* Top meta row - live indicator */}
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800/80 text-[11px]">
            <div className="flex items-center gap-1.5 font-semibold text-emerald-400">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
              </span>
              <span>שיחה נכנסת בזמן אמת!</span>
            </div>

            {/* Audio Wave / Ringing Indicator */}
            <div className="flex items-center gap-1 text-slate-400 font-mono text-[10px]">
              <Volume2 className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>הדפדפן מצלצל...</span>
              <div className="flex items-end gap-0.5 h-3 ml-1">
                <span className={`w-0.5 bg-emerald-400 rounded-full transition-all duration-200 ${pulseRing ? 'h-3' : 'h-1.5'}`} />
                <span className={`w-0.5 bg-emerald-400 rounded-full transition-all duration-200 ${pulseRing ? 'h-1.5' : 'h-3'}`} />
                <span className={`w-0.5 bg-emerald-400 rounded-full transition-all duration-200 ${pulseRing ? 'h-3' : 'h-2'}`} />
              </div>
            </div>
          </div>

          {/* Main Card Body */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              {/* Avatar with Station Logo & Calling Badge */}
              <div className="relative shrink-0">
                <img
                  src="/station-logo.jpg"
                  alt="Station Logo"
                  className="w-12 h-12 rounded-2xl object-cover border border-emerald-500/50 shadow-inner"
                />
                <div className="absolute -bottom-1 -left-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-slate-900 flex items-center justify-center text-slate-950">
                  <Phone className="w-2.5 h-2.5 fill-current animate-pulse" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 border-2 border-slate-900 flex items-center justify-center text-white">
                  <BellRing className="w-2.5 h-2.5 animate-bounce" />
                </div>
              </div>

              {/* Caller details */}
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-bold text-white truncate">
                    {displayName}
                  </h3>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-[10px] text-emerald-300 font-medium shrink-0">
                    מחייג אליך
                  </span>
                </div>

                <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono truncate mt-0.5">
                  <Globe className="w-3 h-3 text-slate-500 shrink-0" />
                  <span className="truncate">{callerIp || 'IP מאומת'}</span>
                  {(callerCity || callerCountry) && (
                    <span className="text-slate-500 truncate hidden sm:inline">
                      • {callerCity ? `${callerCity}, ` : ''}{callerCountry}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Quick action buttons */}
          <div className="grid grid-cols-2 gap-2.5 mt-4 pt-1">
            <button
              type="button"
              onClick={onAnswer}
              className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-[0.98] text-slate-950 font-bold text-xs shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all cursor-pointer"
            >
              <Phone className="w-4 h-4 fill-current" />
              הצטרף לשיחה
            </button>

            <button
              type="button"
              onClick={onDecline}
              className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-slate-800/90 hover:bg-red-500/20 hover:text-red-300 hover:border-red-500/30 border border-slate-700/60 active:scale-[0.98] text-slate-300 font-medium text-xs transition-all cursor-pointer"
            >
              <PhoneOff className="w-4 h-4" />
              לא עכשיו
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
