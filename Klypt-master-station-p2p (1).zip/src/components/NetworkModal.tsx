import React from 'react';
import {
  Globe,
  Wifi,
  ShieldCheck,
  Activity,
  Server,
  Zap,
  MapPin,
  RefreshCw,
  X
} from 'lucide-react';
import { NetworkInfo, PeerNetworkInfo } from '../types';

interface NetworkModalProps {
  isOpen: boolean;
  onClose: () => void;
  myNetwork: NetworkInfo;
  peerNetwork?: PeerNetworkInfo | null;
  onRefresh: () => void;
}

export const NetworkModal: React.FC<NetworkModalProps> = ({
  isOpen,
  onClose,
  myNetwork,
  peerNetwork,
  onRefresh
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-[#141824] border border-slate-700/80 rounded-2xl max-w-2xl w-full p-5 shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
                מרכז ניטור רשת, IP & WebRTC P2P
              </h3>
              <p className="text-xs text-slate-400">
                זיהוי כתובות IP ציבוריות, מועמדי STUN/ICE ומדדי מהירות חיבור
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Refresh button */}
        <div className="flex justify-between items-center mb-4">
          <span className="text-xs text-slate-400 flex items-center gap-1.5 font-medium">
            <span
              className={`w-2.5 h-2.5 rounded-full ${myNetwork.online ? 'bg-emerald-400' : 'bg-red-500'}`}
            />
            {myNetwork.online ? 'מחובר לאינטרנט' : 'מנותק מרשת'}
          </span>
          <button
            type="button"
            onClick={onRefresh}
            disabled={myNetwork.isLoading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-medium transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${myNetwork.isLoading ? 'animate-spin' : ''}`} />
            רענן בדיקת IP
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
          {/* My Network Box */}
          <div className="bg-[#0e111a] border border-slate-800 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-800/80">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wide">
                הרשת שלך (המכשיר המקומי)
              </h4>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">כתובת IP ציבורית:</span>
                <span className="font-mono font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  {myNetwork.isLoading ? 'בודק...' : myNetwork.publicIp || 'לא זוהה'}
                </span>
              </div>

              {myNetwork.country && (
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">מיקום משוער:</span>
                  <span className="text-slate-200 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-emerald-400" />
                    {myNetwork.city ? `${myNetwork.city}, ` : ''}
                    {myNetwork.country}
                  </span>
                </div>
              )}

              {myNetwork.org && (
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">ספק תשתית (ISP):</span>
                  <span className="text-slate-300 font-mono text-[11px] truncate max-w-[140px]" title={myNetwork.org}>
                    {myNetwork.org}
                  </span>
                </div>
              )}

              {myNetwork.stunReflexiveIp && (
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">STUN Reflexive IP:</span>
                  <span className="font-mono text-cyan-400">{myNetwork.stunReflexiveIp}</span>
                </div>
              )}
            </div>

            {/* Local ICE candidates */}
            <div className="mt-3 pt-2.5 border-t border-slate-800/80">
              <span className="text-[11px] font-semibold text-slate-400 block mb-1.5">
                מועמדי WebRTC ICE שאותרו:
              </span>
              <div className="space-y-1 max-h-24 overflow-y-auto">
                {myNetwork.localCandidates.length > 0 ? (
                  myNetwork.localCandidates.map((cand, idx) => (
                    <div
                      key={idx}
                      className="font-mono text-[10px] text-slate-400 bg-slate-900/60 p-1 rounded border border-slate-800"
                    >
                      {cand}
                    </div>
                  ))
                ) : (
                  <span className="text-[11px] text-slate-500 italic">
                    מתבצעת איסוף מועמדים מול שרתי STUN...
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Peer Network Box */}
          <div className="bg-[#0e111a] border border-slate-800 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-800/80">
              <Zap className="w-4 h-4 text-cyan-400" />
              <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wide">
                רשת החבר (Peer Connected)
              </h4>
            </div>

            {peerNetwork ? (
              <div className="space-y-2.5 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">כתובת IP של החבר:</span>
                  <span className="font-mono font-semibold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
                    {peerNetwork.publicIp || 'מחובר ישירות'}
                  </span>
                </div>

                {peerNetwork.country && (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">מיקום החבר:</span>
                    <span className="text-slate-200 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-cyan-400" />
                      {peerNetwork.city ? `${peerNetwork.city}, ` : ''}
                      {peerNetwork.country}
                    </span>
                  </div>
                )}

                {peerNetwork.platform && (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">מערכת / דפדפן:</span>
                    <span className="text-slate-300 font-mono text-[11px]">{peerNetwork.platform}</span>
                  </div>
                )}

                {peerNetwork.screen && (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">רזולוציית מסך:</span>
                    <span className="text-slate-300 font-mono text-[11px]">{peerNetwork.screen}</span>
                  </div>
                )}

                <div className="flex justify-between items-center pt-2 border-t border-slate-800">
                  <span className="text-slate-400 flex items-center gap-1">
                    <Activity className="w-3.5 h-3.5 text-amber-400" />
                    זמן שיהוי (RTT / Ping):
                  </span>
                  <span
                    className={`font-mono font-bold text-xs px-2 py-0.5 rounded ${
                      (peerNetwork.lastPingMs || 0) < 60
                        ? 'text-emerald-400 bg-emerald-500/10'
                        : (peerNetwork.lastPingMs || 0) < 150
                          ? 'text-amber-400 bg-amber-500/10'
                          : 'text-red-400 bg-red-500/10'
                    }`}
                  >
                    {peerNetwork.lastPingMs !== undefined ? `${peerNetwork.lastPingMs} ms` : 'מחשב...'}
                  </span>
                </div>
              </div>
            ) : (
              <div className="h-44 flex flex-col items-center justify-center text-center p-4">
                <Server className="w-8 h-8 text-slate-600 mb-2" />
                <p className="text-xs text-slate-400 font-medium">אין כרגע חבר מחובר</p>
                <p className="text-[11px] text-slate-500 mt-1">
                  ברגע שחבר יתחבר דרך הלינק, הנתונים שלו (IP, מיקום, זמן תגובה ופינג) יוצגו כאן אוטומטית.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors"
          >
            סגור
          </button>
        </div>
      </div>
    </div>
  );
};
