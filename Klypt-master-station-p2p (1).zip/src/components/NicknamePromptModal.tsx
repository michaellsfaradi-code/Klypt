import React, { useState } from 'react';
import { UserCheck, Globe, Monitor, MapPin } from 'lucide-react';
import { PeerNetworkInfo } from '../types';

interface NicknamePromptModalProps {
  peerIp: string;
  peerNetwork?: PeerNetworkInfo | null;
  initialName?: string;
  onSave: (nickname: string) => void;
  onDismiss: () => void;
}

export const NicknamePromptModal: React.FC<NicknamePromptModalProps> = ({
  peerIp,
  peerNetwork,
  initialName,
  onSave,
  onDismiss
}) => {
  const [nickname, setNickname] = useState<string>(initialName || '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = nickname.trim() || initialName || `חבר (${peerIp})`;
    onSave(finalName);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-6 shadow-2xl text-right">
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <UserCheck className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-slate-100">שמירת חבר בזיכרון</h3>
            <p className="text-xs text-slate-400">החבר התחבר בהצלחה</p>
          </div>
        </div>

        {/* Collected background data */}
        <div className="my-3.5 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs space-y-1.5">
          <div className="flex items-center justify-between text-slate-400">
            <span>כתובת IP:</span>
            <span className="font-mono text-emerald-400 select-all">{peerIp}</span>
          </div>

          {(peerNetwork?.city || peerNetwork?.country) && (
            <div className="flex items-center justify-between text-slate-400">
              <span className="flex items-center gap-1">
                <MapPin className="w-3 h-3 text-slate-500" />
                מיקום:
              </span>
              <span className="text-slate-300">
                {peerNetwork.city ? `${peerNetwork.city}, ` : ''}{peerNetwork.country}
              </span>
            </div>
          )}

          {peerNetwork?.platform && (
            <div className="flex items-center justify-between text-slate-400">
              <span className="flex items-center gap-1">
                <Monitor className="w-3 h-3 text-slate-500" />
                דפדפן / מערכת:
              </span>
              <span className="text-slate-300 font-mono text-[11px] truncate max-w-[150px]">
                {peerNetwork.platform}
              </span>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1.5">
              איך תרצה לכנות אותו בפעם הבאה?
            </label>
            <input
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              placeholder="למשל: יוסי, דני מהעבודה..."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              autoFocus
            />
            <p className="text-[11px] text-slate-500 mt-1">
              הכינוי יישמר בדפדפן, ובפעם הבאה שתיכנס יופיע כפתור מוכן להתחברות אליו בלחיצה אחת.
            </p>
          </div>

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={onDismiss}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
            >
              המשך ללא שמירה
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium shadow-sm transition-colors"
            >
              שמור כינוי בזיכרון
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
