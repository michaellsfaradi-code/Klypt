import React, { useState } from 'react';
import {
  ShieldCheck,
  Bell,
  Video,
  Mic,
  Volume2,
  Lock,
  Globe,
  CheckCircle2,
  CheckSquare,
  Square,
  ArrowLeft
} from 'lucide-react';
import { requestNotificationPermission, subscribeToWebPush } from '../utils/notifications';
import { sound } from '../utils/sound';

interface TermsAndSettingsModalProps {
  onAccept: () => void;
}

export const TermsAndSettingsModal: React.FC<TermsAndSettingsModalProps> = ({ onAccept }) => {
  const [agreedTerms, setAgreedTerms] = useState(false);
  const [agreedNotifs, setAgreedNotifs] = useState(false);
  const [agreedMedia, setAgreedMedia] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const allChecked = agreedTerms && agreedNotifs && agreedMedia;

  const handleAcceptAll = async () => {
    setIsSubmitting(true);

    // 1. Unlock AudioContext so ringing works immediately without user hesitation
    sound.unlock();

    // 2. Request browser notification permission & register Web Push
    try {
      const granted = await requestNotificationPermission();
      if (granted) {
        const stationId = localStorage.getItem('ms_persistent_station_id');
        if (stationId) {
          await subscribeToWebPush(stationId);
        }
      }
    } catch (e) {
      console.warn('Web push registration on accept failed:', e);
    }

    // 3. Mark as accepted in localStorage
    localStorage.setItem('ms_terms_accepted_v1', 'true');
    localStorage.setItem('ms_terms_accepted_at', new Date().toISOString());

    // 4. Callback to unlock app
    onAccept();
  };

  const handleSelectAllCheckboxes = () => {
    const next = !allChecked;
    setAgreedTerms(next);
    setAgreedNotifs(next);
    setAgreedMedia(next);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-xl bg-[#0f141c] border border-indigo-500/30 rounded-3xl p-6 sm:p-7 shadow-[0_20px_60px_rgba(0,0,0,0.8),0_0_30px_rgba(99,102,241,0.15)] text-right flex flex-col max-h-[92vh] overflow-y-auto"
        dir="rtl"
      >
        {/* Header */}
        <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
          <img
            src="/station-logo.jpg"
            alt="Klypt Logo"
            className="w-12 h-12 rounded-2xl object-cover border border-indigo-500/40 shadow-sm shrink-0"
          />
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">
              אישור תנאי שימוש והגדרות מערכת
            </h2>
            <p className="text-xs text-slate-400">
              לפני תחילת השימוש באפליקציה, יש לאשר את תנאי השימוש ופרטיות ה-P2P
            </p>
          </div>
        </div>

        {/* Terms list */}
        <div className="py-4 space-y-3.5 text-xs text-slate-300">
          {/* Item 1: P2P & IP Privacy */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-1.5">
            <div className="flex items-center gap-2 font-semibold text-slate-100">
              <Globe className="w-4 h-4 text-indigo-400 shrink-0" />
              <span>1. תקשורת P2P ישירה ופרטיות רשת</span>
            </div>
            <p className="text-slate-400 leading-relaxed text-[11.5px]">
              האפליקציה פועלת ברשת עמית-לעמית (P2P) ללא שרתים מתווכים. השיחות, הווידאו והקבצים מועברים ישירות בין הדפדפן שלך לדפדפן של החבר. החיבור מחליף כתובות IP ונתוני רשת בין הצדדים לצורך התחברות ישירה.
            </p>
          </div>

          {/* Item 2: Notifications & Ringing */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-1.5">
            <div className="flex items-center gap-2 font-semibold text-slate-100">
              <Bell className="w-4 h-4 text-sky-400 shrink-0" />
              <span>2. התראות מערכת וצלצול במסך הבית</span>
            </div>
            <p className="text-slate-400 leading-relaxed text-[11.5px]">
              האפליקציה משתמשת בהתראות דפדפן וב-Service Worker כדי להקפיץ לך שיחות נכנסות גם כשאתה במסך הבית או בתוכנה אחרת, כולל צלצול חוזר ורטט.
            </p>
          </div>

          {/* Item 3: Media permissions */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-1.5">
            <div className="flex items-center gap-2 font-semibold text-slate-100">
              <div className="flex items-center gap-1">
                <Mic className="w-3.5 h-3.5 text-indigo-400" />
                <Video className="w-3.5 h-3.5 text-indigo-400" />
              </div>
              <span>3. גישה למיקרופון ולמצלמה</span>
            </div>
            <p className="text-slate-400 leading-relaxed text-[11.5px]">
              לצורך שיחות קוליות ושיחות וידאו באיכות HD, האפליקציה תבקש גישה למיקרופון ולמצלמה של המכשיר שלך בעת הפעלת שיחה.
            </p>
          </div>

          {/* Item 4: Local Storage */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-1.5">
            <div className="flex items-center gap-2 font-semibold text-slate-100">
              <Lock className="w-4 h-4 text-indigo-400 shrink-0" />
              <span>4. שמירת אנשי קשר מקומית</span>
            </div>
            <p className="text-slate-400 leading-relaxed text-[11.5px]">
              כל הכינויים, החברים השמורים וההגדרות שלך נשמרים מקומית על המכשיר שלך בלבד בזיכרון הדפדפן (Local Storage), ללא שמירה בענן חיצוני.
            </p>
          </div>
        </div>

        {/* Checkbox Section */}
        <div className="pt-2 pb-4 space-y-2.5 border-t border-slate-800 text-xs">
          <label
            onClick={() => setAgreedTerms(!agreedTerms)}
            className="flex items-center gap-2.5 cursor-pointer text-slate-200 hover:text-white select-none"
          >
            {agreedTerms ? (
              <CheckSquare className="w-4 h-4 text-indigo-400 shrink-0" />
            ) : (
              <Square className="w-4 h-4 text-slate-500 shrink-0" />
            )}
            <span>אני מאשר/ת את תנאי השימוש, פרטיות ה-P2P ושמירת הנתונים המקומית</span>
          </label>

          <label
            onClick={() => setAgreedNotifs(!agreedNotifs)}
            className="flex items-center gap-2.5 cursor-pointer text-slate-200 hover:text-white select-none"
          >
            {agreedNotifs ? (
              <CheckSquare className="w-4 h-4 text-indigo-400 shrink-0" />
            ) : (
              <Square className="w-4 h-4 text-slate-500 shrink-0" />
            )}
            <span>אני מאשר/ת קבלת התראות שיחה וצלצול במסך הבית ובשולחן העבודה</span>
          </label>

          <label
            onClick={() => setAgreedMedia(!agreedMedia)}
            className="flex items-center gap-2.5 cursor-pointer text-slate-200 hover:text-white select-none"
          >
            {agreedMedia ? (
              <CheckSquare className="w-4 h-4 text-indigo-400 shrink-0" />
            ) : (
              <Square className="w-4 h-4 text-slate-500 shrink-0" />
            )}
            <span>אני מאשר/ת שימוש במיקרופון ומצלמה בעת ביצוע שיחות וידאו ואודיו</span>
          </label>
        </div>

        {/* Bottom Buttons */}
        <div className="pt-2 flex flex-col sm:flex-row gap-2.5">
          <button
            type="button"
            onClick={handleSelectAllCheckboxes}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors cursor-pointer"
          >
            {allChecked ? 'בטל בחירת הכל' : 'סמן הכל'}
          </button>

          <button
            type="button"
            disabled={!allChecked || isSubmitting}
            onClick={handleAcceptAll}
            className={`flex-1 flex items-center justify-center gap-2 py-3 px-5 rounded-xl font-bold text-xs transition-all shadow-md cursor-pointer ${
              allChecked
                ? 'bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-500 hover:to-sky-500 text-white shadow-indigo-950/40 active:scale-[0.98]'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/60'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>אשר את כל התנאים והמשך לאפליקציה</span>
          </button>
        </div>
      </div>
    </div>
  );
};
