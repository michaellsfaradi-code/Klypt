import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  Send,
  Paperclip,
  Download,
  Trash2,
  FileCheck,
  File,
  Film,
  Users,
  Share2,
  Network,
  Smile,
  Sparkles,
  CheckCheck
} from 'lucide-react';
import { ChatMessage, FileTransferProgress, GroupParticipant } from '../types';
import { sound } from '../utils/sound';

interface ChatSectionProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  onSendFile: (file: File) => void;
  onClearChat: () => void;
  isPeerConnected: boolean;
  fileProgress: FileTransferProgress | null;
  groupParticipants?: GroupParticipant[];
  onOpenBridgeModal?: () => void;
  contacts?: Array<{ id: string; name: string; nickname?: string; ip?: string }>;
  onConnectToFriend?: (id: string) => void;
}

const QUICK_EMOJIS = ['🔥', '❤️', '😂', '🍿', '🚀', '👏', '🥳', '👍', '☕', '🎮'];

// Helper to detect if message is only emojis (1-3 emojis)
const isSingleEmoji = (text: string) => {
  const emojiRegex = /^(\p{Extended_Pictographic}|\p{Emoji_Presentation}){1,3}$/u;
  return emojiRegex.test(text.trim());
};

export const ChatSection: React.FC<ChatSectionProps> = ({
  messages,
  onSendMessage,
  onSendFile,
  onClearChat,
  isPeerConnected,
  fileProgress,
  groupParticipants = [],
  onOpenBridgeModal,
  contacts = [],
  onConnectToFriend
}) => {
  const [inputText, setInputText] = useState<string>('');
  const [showEmojiPicker, setShowEmojiPicker] = useState<boolean>(false);
  const chatScrollRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const isGroup = groupParticipants.length > 2;

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !isPeerConnected) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const handleSendQuickEmoji = (emoji: string) => {
    if (!isPeerConnected) return;
    sound.playReaction();
    onSendMessage(emoji);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    onSendFile(file);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1048576).toFixed(1) + ' MB';
  };

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800/80 rounded-3xl p-4 sm:p-5 shadow-2xl flex flex-col min-h-[500px] h-[580px] backdrop-blur-xl transition-all">
      {/* Header */}
      <div className="flex items-center justify-between pb-3.5 mb-3 border-b border-slate-800/80 flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-indigo-500 to-sky-600 flex items-center justify-center text-white shadow-sm border border-indigo-400/30">
            {isGroup ? <Users className="w-4 h-4" /> : <MessageSquare className="w-4 h-4" />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-slate-100">
                {isGroup ? "צ'אט קבוצתי P2P" : "צ'אט חברתי ישיר"}
              </h3>
              {isGroup ? (
                <span className="px-2 py-0.5 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-[10px] text-indigo-300 font-semibold">
                  מצב גשר • {groupParticipants.length} חברים
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full bg-slate-800 text-[10px] text-indigo-300 font-mono">
                  מוצפן מקצה לקצה
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-400">
              {isGroup
                ? 'שיחה קבוצתית ישירה ומהנה ללא שרתים'
                : 'הודעות, קבצים ותגובות אימוג\'י בזמן אמת'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onOpenBridgeModal && (
            <button
              type="button"
              onClick={onOpenBridgeModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600/15 hover:bg-indigo-600/25 border border-indigo-500/30 text-indigo-300 text-xs font-semibold transition-all cursor-pointer shadow-xs active:scale-95"
              title="שתף טוקן גשר לצירוף משתתף שלישי"
            >
              <Network className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">טוקן גשר לקבוצה</span>
            </button>
          )}

          <button
            type="button"
            onClick={onClearChat}
            className="text-slate-500 hover:text-slate-300 p-2 rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
            title="נקה היסטוריית צ'אט"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Feed */}
      <div
        ref={chatScrollRef}
        className="flex-1 overflow-y-auto space-y-3 p-3 rounded-2xl bg-[#0c1017] border border-slate-800/80 mb-3"
      >
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
            <div className="w-14 h-14 rounded-3xl bg-gradient-to-tr from-indigo-500/20 to-sky-500/10 border border-indigo-500/30 text-indigo-400 flex items-center justify-center shadow-lg shadow-indigo-950/20">
              <Sparkles className="w-7 h-7 animate-pulse" />
            </div>
            <div className="space-y-1">
              <p className="text-sm font-bold text-slate-100">
                {isPeerConnected ? "הצ'אט מוכן ומחכה לכם!" : "מרכז ההודעות החברתי"}
              </p>
              <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
                {isPeerConnected
                  ? "שלח הודעה, תגובת אימוג'י מהירה או גרור קבצים, תמונות וסרטונים לשיתוף ישיר."
                  : "התחבר לחבר באמצעות מזהה התחנה שלו כדי לפתוח צ'אט ישיר ונעים ללא מתווכים."}
              </p>
            </div>

            {/* If not connected, offer quick contacts to connect & chat */}
            {!isPeerConnected && contacts.length > 0 && onConnectToFriend && (
              <div className="w-full max-w-md pt-2 space-y-2 text-right">
                <span className="text-[11px] font-semibold text-slate-400 block px-1">
                  פתח שיחה עם חבר שמור:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {contacts.slice(0, 4).map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => onConnectToFriend(c.id)}
                      className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-indigo-500/40 text-slate-200 text-xs font-medium transition-all text-right cursor-pointer group shadow-xs"
                    >
                      <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-sky-600 flex items-center justify-center text-white text-xs font-bold shrink-0">
                        {(c.nickname || c.name || 'ח').charAt(0)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="truncate font-semibold group-hover:text-indigo-300">
                          {c.nickname || c.name}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono truncate">
                          {c.id}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Fun Starter Prompts when connected */}
            {isPeerConnected && (
              <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => handleSendQuickEmoji('היי מה נשמע? 👋')}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white text-xs font-medium transition-all active:scale-95 cursor-pointer shadow-xs"
                >
                  היי מה נשמע? 👋
                </button>
                <button
                  type="button"
                  onClick={() => handleSendQuickEmoji('בוא נראה סרט! 🍿')}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white text-xs font-medium transition-all active:scale-95 cursor-pointer shadow-xs"
                >
                  בוא נראה סרט! 🍿
                </button>
                <button
                  type="button"
                  onClick={() => handleSendQuickEmoji('הכל עובד מעולה 🔥')}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white text-xs font-medium transition-all active:scale-95 cursor-pointer shadow-xs"
                >
                  הכל עובד מעולה 🔥
                </button>
              </div>
            )}
          </div>
        ) : (
          messages.map((m) => {
            if (m.sender === 'system') {
              return (
                <div key={m.id} className="text-center py-1">
                  <span className="text-[11px] font-mono text-slate-400 bg-slate-900/90 px-3.5 py-1 rounded-full border border-slate-800 shadow-xs">
                    {m.text}
                  </span>
                </div>
              );
            }

            const isMe = m.sender === 'me';
            const isEmojiOnly = isSingleEmoji(m.text);

            return (
              <div
                key={m.id}
                className={`flex flex-col ${isMe ? 'items-start' : 'items-end'} animate-in fade-in duration-150`}
              >
                {/* Jumbo Emoji for 1-3 emojis */}
                {isEmojiOnly ? (
                  <div className="py-1 px-2 text-3xl sm:text-4xl select-none hover:scale-110 transition-transform">
                    {m.text}
                  </div>
                ) : (
                  <div
                    className={`max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-2.5 text-xs shadow-md transition-all ${
                      isMe
                        ? 'bg-gradient-to-br from-indigo-600 to-indigo-500 text-white font-normal rounded-br-xs shadow-indigo-950/30'
                        : 'bg-slate-800/90 text-slate-100 rounded-bl-xs border border-slate-700/80 shadow-black/40'
                    }`}
                  >
                    {/* Sender Name in group chat */}
                    {!isMe && m.senderName && (
                      <span className="text-[11px] font-bold text-indigo-300 block mb-1">
                        {m.senderName}
                      </span>
                    )}

                    {/* Text content */}
                    {m.text && <p className="whitespace-pre-wrap break-words leading-relaxed text-[12.5px]">{m.text}</p>}

                    {/* Attached file card */}
                    {m.file && (
                      <div className="mt-2 p-2.5 rounded-xl bg-black/25 border border-white/10 flex items-center justify-between gap-3 shadow-inner">
                        <div className="flex items-center gap-2.5 overflow-hidden">
                          {m.file.isVideo ? (
                            <Film className="w-5 h-5 flex-shrink-0 text-amber-300" />
                          ) : (
                            <FileCheck className="w-5 h-5 flex-shrink-0 text-indigo-300" />
                          )}
                          <div className="truncate">
                            <p className="font-semibold truncate text-[11.5px]">{m.file.name}</p>
                            <p className="text-[10px] opacity-75">{formatFileSize(m.file.size)}</p>
                          </div>
                        </div>

                        <a
                          href={m.file.url}
                          download={m.file.name}
                          className="p-1.5 rounded-lg bg-white/20 hover:bg-white/30 transition-colors flex-shrink-0 cursor-pointer shadow-xs"
                          title="הורד קובץ"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    )}

                    {/* Timestamp & Delivery confirmation */}
                    <div className="flex items-center justify-between gap-2.5 mt-1.5 pt-0.5">
                      <span
                        className={`text-[9.5px] font-mono ${
                          isMe ? 'text-indigo-200/80' : 'text-slate-400'
                        }`}
                      >
                        {formatTime(m.timestamp)}
                      </span>
                      <div className="flex items-center gap-1">
                        {m.isBridgeRelayed && (
                          <span className="text-[9px] text-indigo-200 font-mono px-1 rounded bg-black/20">
                            גשר
                          </span>
                        )}
                        {isMe && <CheckCheck className="w-3 h-3 text-indigo-200" />}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Progress of active file transfer */}
      {fileProgress && fileProgress.status === 'transferring' && (
        <div className="mb-2 p-2.5 rounded-2xl bg-slate-950 border border-slate-800 text-[11px] animate-in fade-in">
          <div className="flex justify-between items-center mb-1 text-slate-300">
            <span className="truncate max-w-[200px]">
              {fileProgress.direction === 'sending' ? 'מעלה' : 'מוריד'}: {fileProgress.name}
            </span>
            <span className="font-mono text-indigo-400 font-bold">{fileProgress.progress}%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-indigo-500 to-sky-400 h-full transition-all duration-200"
              style={{ width: `${fileProgress.progress}%` }}
            />
          </div>
        </div>
      )}

      {/* Social Quick Emoji Bar */}
      {isPeerConnected && (
        <div className="flex items-center gap-1 pb-2 px-1 overflow-x-auto no-scrollbar">
          <span className="text-[11px] text-slate-500 font-medium pl-1 shrink-0">
            תגובה מהירה:
          </span>
          {QUICK_EMOJIS.map((emoji) => (
            <button
              key={emoji}
              type="button"
              onClick={() => handleSendQuickEmoji(emoji)}
              className="p-1 px-1.5 rounded-xl hover:bg-slate-800 text-sm hover:scale-125 active:scale-95 transition-transform cursor-pointer"
              title={`שלח ${emoji}`}
            >
              {emoji}
            </button>
          ))}
        </div>
      )}

      {/* Input bar */}
      <form onSubmit={handleSubmit} className="flex items-center gap-2 flex-shrink-0">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
        />

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={!isPeerConnected}
          className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 transition-colors cursor-pointer border border-slate-700/60 shadow-xs active:scale-95"
          title="צרף קובץ, תמונה או סרטון"
        >
          <Paperclip className="w-4 h-4" />
        </button>

        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={
            isPeerConnected
              ? isGroup
                ? 'כתוב הודעה לקבוצה...'
                : 'כתוב הודעה לחבר...'
              : 'ממתין לחיבור...'
          }
          disabled={!isPeerConnected}
          className="flex-1 bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none transition-all"
        />

        <button
          type="submit"
          disabled={!inputText.trim() || !isPeerConnected}
          className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-semibold transition-all cursor-pointer shadow-xs active:scale-95"
          title="שלח הודעה"
        >
          <Send className="w-4 h-4 rotate-180" />
        </button>
      </form>
    </div>
  );
};
