import React, { useRef, useEffect, useState, useCallback } from 'react';
import type { DataConnection } from 'peerjs';
import {
  Palette,
  Eraser,
  Trash2,
  Download,
  RotateCcw,
  Sparkles,
  Users,
  PenTool,
  Check
} from 'lucide-react';
import { WhiteboardStroke, WhiteboardPoint, WhiteboardDrawMessage, WhiteboardClearMessage } from '../types';

interface WhiteboardSectionProps {
  conn: DataConnection | null;
  remotePeerId?: string;
  userName?: string;
  isPeerConnected: boolean;
  onBroadcastMessage?: (message: unknown) => void;
  incomingWhiteboardStroke?: WhiteboardStroke | null;
  incomingWhiteboardClear?: boolean;
}

const COLOR_PALETTE = [
  { hex: '#6366f1', label: 'אינדיגו' },
  { hex: '#38bdf8', label: 'תכלת' },
  { hex: '#10b981', label: 'ירוק' },
  { hex: '#f59e0b', label: 'ענבר' },
  { hex: '#f43f5e', label: 'ורוד' },
  { hex: '#a855f7', label: 'סגול' },
  { hex: '#ffffff', label: 'לבן' }
];

const BRUSH_SIZES = [
  { size: 2, label: 'דק' },
  { size: 4, label: 'בינוני' },
  { size: 8, label: 'עבה' },
  { size: 16, label: 'עבה מאוד' }
];

export const WhiteboardSection: React.FC<WhiteboardSectionProps> = ({
  conn,
  remotePeerId,
  userName = 'אני',
  isPeerConnected,
  onBroadcastMessage,
  incomingWhiteboardStroke,
  incomingWhiteboardClear
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [currentColor, setCurrentColor] = useState<string>('#6366f1');
  const [currentWidth, setCurrentWidth] = useState<number>(4);
  const [isEraser, setIsEraser] = useState<boolean>(false);
  const [strokes, setStrokes] = useState<WhiteboardStroke[]>([]);
  const isDrawingRef = useRef<boolean>(false);
  const currentPointsRef = useRef<WhiteboardPoint[]>([]);

  // Redraw all strokes on canvas
  const redrawCanvas = useCallback((allStrokes: WhiteboardStroke[]) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Background color: clean dark slate
    ctx.fillStyle = '#0b0f17';
    ctx.fillRect(0, 0, width, height);

    // Subtle grid pattern for precision
    ctx.strokeStyle = '#1a2234';
    ctx.lineWidth = 1;
    const gridSize = 40;
    for (let x = 0; x < width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Render strokes
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    for (const s of allStrokes) {
      if (s.points.length < 2) continue;

      ctx.beginPath();
      ctx.strokeStyle = s.isEraser ? '#0b0f17' : s.color;
      ctx.lineWidth = s.width;

      const p0 = s.points[0];
      ctx.moveTo(p0.x * width, p0.y * height);

      for (let i = 1; i < s.points.length; i++) {
        const pt = s.points[i];
        ctx.lineTo(pt.x * width, pt.y * height);
      }
      ctx.stroke();
    }
  }, []);

  // Resize canvas to match container while keeping contents intact
  useEffect(() => {
    const handleResize = () => {
      const container = containerRef.current;
      const canvas = canvasRef.current;
      if (!container || !canvas) return;

      const rect = container.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.scale(dpr, dpr);
      }
      // Set display CSS size
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;

      redrawCanvas(strokes);
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [strokes, redrawCanvas]);

  // Handle incoming remote stroke from peer
  useEffect(() => {
    if (!incomingWhiteboardStroke) return;
    setStrokes((prev) => {
      if (prev.some((s) => s.id === incomingWhiteboardStroke.id)) return prev;
      const updated = [...prev, incomingWhiteboardStroke];
      redrawCanvas(updated);
      return updated;
    });
  }, [incomingWhiteboardStroke, redrawCanvas]);

  // Handle incoming board clear from peer
  useEffect(() => {
    if (incomingWhiteboardClear) {
      setStrokes([]);
      redrawCanvas([]);
    }
  }, [incomingWhiteboardClear, redrawCanvas]);

  // Get normalized position (0.0 to 1.0)
  const getNormalizedPos = (e: React.PointerEvent<HTMLCanvasElement>): WhiteboardPoint | null => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const y = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));
    return { x, y };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.setPointerCapture(e.pointerId);

    const pos = getNormalizedPos(e);
    if (!pos) return;

    isDrawingRef.current = true;
    currentPointsRef.current = [pos];
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    const pos = getNormalizedPos(e);
    if (!pos) return;

    currentPointsRef.current.push(pos);

    // Live draw in-progress stroke on top
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width / (window.devicePixelRatio || 1);
    const height = canvas.height / (window.devicePixelRatio || 1);
    const pts = currentPointsRef.current;

    if (pts.length >= 2) {
      const p1 = pts[pts.length - 2];
      const p2 = pts[pts.length - 1];

      ctx.beginPath();
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.strokeStyle = isEraser ? '#0b0f17' : currentColor;
      ctx.lineWidth = currentWidth;
      ctx.moveTo(p1.x * width, p1.y * height);
      ctx.lineTo(p2.x * width, p2.y * height);
      ctx.stroke();
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    isDrawingRef.current = false;

    const pts = currentPointsRef.current;
    if (pts.length < 2) return;

    const newStroke: WhiteboardStroke = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      points: pts,
      color: currentColor,
      width: currentWidth,
      isEraser
    };

    setStrokes((prev) => {
      const updated = [...prev, newStroke];
      redrawCanvas(updated);
      return updated;
    });

    // Broadcast stroke to connected peers
    const message: WhiteboardDrawMessage = {
      type: 'whiteboard_draw',
      stroke: newStroke,
      senderName: userName
    };

    if (onBroadcastMessage) {
      onBroadcastMessage(message);
    } else if (conn && conn.open) {
      try {
        conn.send(message);
      } catch (err) {
        console.warn('Failed to send whiteboard stroke:', err);
      }
    }
  };

  // Undo last stroke
  const handleUndo = () => {
    setStrokes((prev) => {
      const updated = prev.slice(0, -1);
      redrawCanvas(updated);
      return updated;
    });
  };

  // Clear board
  const handleClear = () => {
    if (strokes.length === 0) return;
    setStrokes([]);
    redrawCanvas([]);

    const clearMsg: WhiteboardClearMessage = {
      type: 'whiteboard_clear',
      senderName: userName
    };

    if (onBroadcastMessage) {
      onBroadcastMessage(clearMsg);
    } else if (conn && conn.open) {
      try {
        conn.send(clearMsg);
      } catch (err) {
        console.warn('Failed to send whiteboard clear:', err);
      }
    }
  };

  // Download whiteboard as image
  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `whiteboard-${Date.now()}.png`;
    a.click();
  };

  return (
    <div className="bg-[#121620] border border-slate-800/80 rounded-2xl p-4 md:p-5 shadow-xl flex flex-col h-full min-h-[580px]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <PenTool className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              לוח ציור & שיתוף רעיונות P2P
              {isPeerConnected && (
                <span className="inline-flex items-center gap-1 text-[11px] font-mono px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                  <Sparkles className="w-3 h-3 text-sky-400" /> סנכרון חי
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-400">
              ציור משותף בזמן אמת, מתווה תוכניות ופתרון בעיות מעל חיבור P2P ישיר
            </p>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleUndo}
            disabled={strokes.length === 0}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 disabled:opacity-40 text-slate-300 transition-colors cursor-pointer"
            title="בטל קו אחרון"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleClear}
            disabled={strokes.length === 0}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-red-500/20 hover:text-red-300 disabled:opacity-40 text-slate-300 transition-colors cursor-pointer"
            title="נקה לוח שלם"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleDownload}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
            title="הורד תמונת לוח כקובץ PNG"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Toolbar Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800/80 text-xs">
        {/* Colors */}
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400 text-[11px] font-medium ml-1">צבע:</span>
          {COLOR_PALETTE.map((c) => (
            <button
              key={c.hex}
              type="button"
              onClick={() => {
                setCurrentColor(c.hex);
                setIsEraser(false);
              }}
              style={{ backgroundColor: c.hex }}
              className={`w-6 h-6 rounded-full border-2 transition-transform cursor-pointer ${
                currentColor === c.hex && !isEraser
                  ? 'scale-115 border-white shadow-md'
                  : 'border-transparent hover:scale-105 opacity-80 hover:opacity-100'
              }`}
              title={c.label}
            />
          ))}
        </div>

        {/* Tool: Brush vs Eraser */}
        <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/80">
          <button
            type="button"
            onClick={() => setIsEraser(false)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
              !isEraser
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <PenTool className="w-3.5 h-3.5" />
            <span>מברשת</span>
          </button>
          <button
            type="button"
            onClick={() => setIsEraser(true)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
              isEraser
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Eraser className="w-3.5 h-3.5" />
            <span>מחק</span>
          </button>
        </div>

        {/* Thickness */}
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400 text-[11px] font-medium ml-1">עובי:</span>
          {BRUSH_SIZES.map((b) => (
            <button
              key={b.size}
              type="button"
              onClick={() => setCurrentWidth(b.size)}
              className={`px-2 py-1 rounded-lg text-xs font-mono transition-colors cursor-pointer ${
                currentWidth === b.size
                  ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-bold'
                  : 'bg-slate-800/60 hover:bg-slate-800 text-slate-400'
              }`}
            >
              {b.label}
            </button>
          ))}
        </div>
      </div>

      {/* Responsive Canvas Container */}
      <div
        ref={containerRef}
        className="relative flex-1 min-h-[420px] rounded-xl overflow-hidden border border-slate-800 bg-[#0b0f17] shadow-inner touch-none cursor-crosshair"
      >
        <canvas
          ref={canvasRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="absolute inset-0 block w-full h-full"
        />

        {strokes.length === 0 && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center pointer-events-none select-none">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mb-2">
              <PenTool className="w-6 h-6" />
            </div>
            <p className="text-xs font-medium text-slate-300 mb-0.5">לוח הציור נקי ומוכן</p>
            <p className="text-[11px] text-slate-500 max-w-xs">
              התחל לצייר או לשרטט — כל קו משתקף בזמן אמת אצל שאר המשתתפים בחיבור ה-P2P
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
