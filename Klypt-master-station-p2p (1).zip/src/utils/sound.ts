/**
 * Synthesizer audio cues & phone ringtones using Web Audio API.
 * Never fails with 404s, works completely offline/P2P.
 */
class SoundEngine {
  private ctx: AudioContext | null = null;
  private ringInterval: number | null = null;
  private ringTimeout: number | null = null;
  public enabled = true;

  public unlock() {
    try {
      const ctx = this.getContext();
      if (ctx && ctx.state === 'suspended') {
        ctx.resume().catch(() => {});
      }
    } catch {}
  }

  private getContext(): AudioContext | null {
    if (!this.enabled) return null;
    try {
      if (!this.ctx) {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.ctx = new AudioCtx();
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      return this.ctx;
    } catch {
      return null;
    }
  }

  /**
   * Persistent Incoming Call Ringtone — strong, noisy, pulsed, up to 1.5 minutes
   * High-volume multi-oscillator bursts with clear pulse pattern. Auto-stops after 90s.
   */
  startIncomingRingtone() {
    this.stopRingtone();
    if (!this.enabled) return;

    this.unlock();

    const playAlertCycle = () => {
      const ctx = this.getContext();
      if (!ctx) return;
      try {
        const now = ctx.currentTime;
        const VOL = 0.72; // strong & noisy

        // Stage 1: Sharp attention chime (higher + more aggressive)
        const chimeNotes = [880.0, 1046.5, 1318.51, 1760.0]; // A5, C6, E6, A6
        chimeNotes.forEach((freq, i) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'square';
          osc.frequency.setValueAtTime(freq, now + i * 0.045);
          gain.gain.setValueAtTime(0.001, now + i * 0.045);
          gain.gain.linearRampToValueAtTime(VOL * 0.85, now + i * 0.045 + 0.015);
          gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.045 + 0.22);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + i * 0.045);
          osc.stop(now + i * 0.045 + 0.23);
        });

        // Stage 2: Loud dual-tone ring with multiple pulses (classic phone + noise edge)
        const ringStart = now + 0.28;
        const pulseDur = 0.18;
        const pulseGap = 0.08;
        const freqs = [440, 480, 620, 880]; // richer, noisier spectrum

        // 4 rapid pulses
        for (let p = 0; p < 4; p++) {
          const t0 = ringStart + p * (pulseDur + pulseGap);
          freqs.forEach((freq, fi) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = fi % 2 === 0 ? 'sawtooth' : 'square';
            osc.frequency.setValueAtTime(freq, t0);
            // slight detune for noise/harshness
            if (fi > 0) osc.detune.setValueAtTime((fi - 1.5) * 12, t0);

            gain.gain.setValueAtTime(0.001, t0);
            gain.gain.linearRampToValueAtTime(VOL * (0.9 - fi * 0.08), t0 + 0.02);
            gain.gain.setValueAtTime(VOL * (0.85 - fi * 0.08), t0 + pulseDur * 0.7);
            gain.gain.linearRampToValueAtTime(0.001, t0 + pulseDur);

            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(t0);
            osc.stop(t0 + pulseDur + 0.02);
          });
        }

        // Stage 3: Final strong pulse burst
        const finalStart = ringStart + 4 * (pulseDur + pulseGap) + 0.05;
        [480, 620, 1046.5].forEach((freq) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'square';
          osc.frequency.setValueAtTime(freq, finalStart);
          gain.gain.setValueAtTime(0.001, finalStart);
          gain.gain.linearRampToValueAtTime(VOL, finalStart + 0.025);
          gain.gain.setValueAtTime(VOL, finalStart + 0.35);
          gain.gain.linearRampToValueAtTime(0.001, finalStart + 0.42);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(finalStart);
          osc.stop(finalStart + 0.45);
        });
      } catch {
        // Ignore
      }
    };

    playAlertCycle();
    // Cycle every ~1.6s for continuous strong ringing
    this.ringInterval = window.setInterval(playAlertCycle, 1600);

    // Hard stop after 1.5 minutes (90 seconds) as requested
    this.ringTimeout = window.setTimeout(() => {
      this.stopRingtone();
    }, 90000);
  }

  testRing() {
    this.startIncomingRingtone();
    setTimeout(() => {
      this.stopRingtone();
    }, 2500);
  }

  /**
   * Outgoing dial tone ("טוּ... טוּ...")
   */
  startOutgoingTone() {
    this.stopRingtone();
    if (!this.enabled) return;

    const playOutgoingCycle = () => {
      const ctx = this.getContext();
      if (!ctx) return;
      try {
        const now = ctx.currentTime;
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();

        osc1.type = 'sine';
        osc2.type = 'sine';
        osc1.frequency.setValueAtTime(400, now);
        osc2.frequency.setValueAtTime(450, now);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.08, now + 0.05);
        gain.gain.setValueAtTime(0.08, now + 1.0);
        gain.gain.linearRampToValueAtTime(0.001, now + 1.05);

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + 1.1);
        osc2.stop(now + 1.1);
      } catch {
        // Ignore
      }
    };

    playOutgoingCycle();
    this.ringInterval = window.setInterval(playOutgoingCycle, 3000);
  }

  stopRingtone() {
    if (this.ringInterval !== null) {
      clearInterval(this.ringInterval);
      this.ringInterval = null;
    }
    if (this.ringTimeout !== null) {
      clearTimeout(this.ringTimeout);
      this.ringTimeout = null;
    }
  }

  playBusyTone() {
    this.stopRingtone();
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      [0, 0.4, 0.8].forEach((offset) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(480, now + offset);
        gain.gain.setValueAtTime(0.15, now + offset);
        gain.gain.setValueAtTime(0.001, now + offset + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + offset);
        osc.stop(now + offset + 0.25);
      });
    } catch {
      // Ignore
    }
  }

  playConnect() {
    this.stopRingtone();
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now); // A4
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.15); // A5
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.35);
    } catch {
      // Ignore
    }
  }

  playMessage() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.08); // G5
      gain.gain.setValueAtTime(0.09, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.2);
    } catch {
      // Ignore
    }
  }

  playFileReady() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.07);
        gain.gain.setValueAtTime(0.1, now + idx * 0.07);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.07);
        osc.stop(now + idx * 0.07 + 0.25);
      });
    } catch {
      // Ignore
    }
  }

  playDisconnect() {
    this.stopRingtone();
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(220, now + 0.2);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.25);
    } catch {
      // Ignore
    }
  }

  playReaction() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(1200, now + 0.08);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.15);
    } catch {}
  }

  playPop() {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(400, now + 0.05);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.08);
    } catch {}
  }
}

export const sound = new SoundEngine();
