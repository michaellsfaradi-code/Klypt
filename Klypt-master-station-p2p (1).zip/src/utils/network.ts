import { NetworkInfo } from '../types';

/**
 * Checks if a string looks like an IPv4 or IPv6 address (optionally with port)
 */
export function isIpAddress(input: string): boolean {
  if (!input) return false;
  const clean = input.trim().replace(/^https?:\/\//, '').split('/')[0].split(':')[0];
  // IPv4 regex
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  // IPv6 regex (basic)
  const ipv6Regex = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  return ipv4Regex.test(clean) || ipv6Regex.test(clean);
}

/**
 * Strips protocol and port to get a clean IP string
 */
export function extractCleanIp(input: string): string {
  if (!input) return '';
  return input.trim().replace(/^https?:\/\//, '').split('/')[0].split(':')[0];
}

/**
 * Converts an IP (e.g. "84.108.20.15") to a valid PeerJS identifier (e.g. "ip_84_108_20_15")
 * PeerJS requires alphanumeric + dashes + underscores (no dots!)
 */
export function ipToPeerId(ip: string, suffix?: string): string {
  const clean = extractCleanIp(ip);
  const formatted = 'ip_' + clean.replace(/[.:]/g, '_');
  return suffix ? `${formatted}_${suffix}` : formatted;
}

/**
 * Converts a PeerJS ID (e.g. "ip_84_108_20_15") back to an IP string ("84.108.20.15") if applicable
 */
export function peerIdToIp(peerId: string): string | null {
  if (!peerId) return null;
  if (peerId.startsWith('ip_')) {
    const raw = peerId.slice(3).split('_');
    if (raw.length >= 4) {
      return raw.slice(0, 4).join('.');
    }
  }
  return null;
}

export async function fetchPublicNetworkInfo(): Promise<Partial<NetworkInfo>> {
  // Strategy 1: Try rich IP info from ipapi.co
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3500);
    const res = await fetch('https://ipapi.co/json/', { signal: controller.signal });
    clearTimeout(timeout);
    if (res.ok) {
      const data = await res.json();
      if (data && data.ip) {
        return {
          publicIp: data.ip,
          country: data.country_name,
          countryCode: data.country_code,
          city: data.city,
          org: data.org || data.asn,
        };
      }
    }
  } catch {
    // Fall through to backup
  }

  // Strategy 2: Fast lightweight IP from ipify
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3000);
    const res = await fetch('https://api.ipify.org?format=json', { signal: controller.signal });
    clearTimeout(timeout);
    if (res.ok) {
      const data = await res.json();
      if (data && data.ip) {
        return {
          publicIp: data.ip,
        };
      }
    }
  } catch {
    // Fall through
  }

  // Strategy 3: api64 (IPv4 / IPv6)
  try {
    const res = await fetch('https://api64.ipify.org?format=json');
    if (res.ok) {
      const data = await res.json();
      if (data && data.ip) {
        return { publicIp: data.ip };
      }
    }
  } catch {
    // Ignore
  }

  return { publicIp: '' };
}

/**
 * WebRTC ICE Candidate & STUN gatherer
 */
export function gatherWebRtcIceInfo(): Promise<{ candidates: string[]; stunIp?: string }> {
  return new Promise((resolve) => {
    const candidates: string[] = [];
    let stunIp: string | undefined = undefined;

    let pc: RTCPeerConnection | null = null;
    try {
      pc = new RTCPeerConnection({
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
          { urls: 'stun:global.stun.twilio.com:3478' },
        ],
      });
    } catch {
      resolve({ candidates: [] });
      return;
    }

    const timer = setTimeout(() => {
      cleanup();
      resolve({ candidates, stunIp });
    }, 2200);

    function cleanup() {
      clearTimeout(timer);
      if (pc) {
        try {
          pc.close();
        } catch {
          // Ignore
        }
        pc = null;
      }
    }

    try {
      pc.createDataChannel('ice-probe');
      pc.createOffer()
        .then((offer) => pc?.setLocalDescription(offer))
        .catch(() => {});

      pc.onicecandidate = (event) => {
        if (!event.candidate) {
          cleanup();
          resolve({ candidates, stunIp });
          return;
        }

        const candStr = event.candidate.candidate;
        // Check if srflx (server reflexive / public IP seen by STUN)
        if (candStr.includes('srflx')) {
          const match = candStr.match(/([0-9]{1,3}(?:\.[0-9]{1,3}){3})/);
          if (match && match[1]) {
            stunIp = match[1];
          }
        }

        // Collect readable candidate summary
        const parts = candStr.split(' ');
        if (parts.length >= 8) {
          const type = parts[7]; // host, srflx, relay
          const ip = parts[4];
          const proto = parts[2];
          candidates.push(`${type.toUpperCase()} (${proto}): ${ip}`);
        } else {
          candidates.push(candStr.slice(0, 45));
        }
      };
    } catch {
      cleanup();
      resolve({ candidates: [] });
    }
  });
}
