/**
 * System-Level Notification Manager (Desktop & Mobile Home Screen)
 * Utilizes Service Worker showNotification with focus-on-click for native OS integration.
 * Supports persistent, nagging incoming call alert cycles.
 */

import { sound } from './sound';

let swRegistration: ServiceWorkerRegistration | null = null;
let naggingInterval: ReturnType<typeof setInterval> | null = null;

export async function initServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (typeof window === 'undefined' || !('serviceWorker' in navigator)) {
    return null;
  }

  try {
    const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
    swRegistration = reg;
    return reg;
  } catch (err) {
    console.warn('Service Worker registration failed:', err);
    return null;
  }
}

export function getNotificationPermissionStatus(): NotificationPermission | 'unsupported' {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission;
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }

  try {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  } catch {
    return false;
  }
}

/**
 * Trigger an OS-level notification on the Desktop or Mobile Home Screen
 */
export async function showHomeScreenNotification(
  title: string,
  options?: {
    body?: string;
    tag?: string;
    callerName?: string;
    callerIp?: string;
    url?: string;
  }
) {
  if (typeof window === 'undefined' || !('Notification' in window)) return;
  if (Notification.permission !== 'granted') return;

  const bodyText =
    options?.body ||
    (options?.callerName
      ? `${options.callerName} מחייג אליך כעת • כתובת IP: ${options.callerIp || 'מאומת'}`
      : 'שיחה נכנסת מחכה לאישורך');

  const notificationOptions: NotificationOptions & Record<string, any> = {
    body: bodyText,
    icon: '/station-logo.jpg',
    badge: '/station-logo.jpg',
    tag: options?.tag || 'station-incoming-call',
    renotify: true,
    requireInteraction: true,
    silent: false,
    vibrate: [500, 200, 500, 200, 500],
    data: {
      url: options?.url || '/'
    }
  };

  // Try through Service Worker first (pops outside browser to Home Screen / Desktop)
  try {
    if ('serviceWorker' in navigator) {
      const reg = swRegistration || (await navigator.serviceWorker.ready);
      if (reg && 'showNotification' in reg) {
        await reg.showNotification(title, notificationOptions);
        return;
      }
    }
  } catch (e) {
    console.warn('SW showNotification error, falling back to window Notification:', e);
  }

  // Fallback to standard window Notification
  try {
    const notif = new Notification(title, notificationOptions);
    notif.onclick = () => {
      window.focus();
      notif.close();
    };
  } catch (e) {
    console.warn('Window Notification error:', e);
  }
}

/**
 * Nagging Persistent Call Alert ("התראה חופרת")
 * Re-triggers the OS alert every 3.5 seconds continuously until the call is answered or declined!
 */
export function startNaggingCallAlert(callerName: string, callerIp: string) {
  stopNaggingCallAlert();

  const title = `שיחה נכנסת מ-${callerName}!`;
  const body = `מחייג אליך עכשיו • לחץ כאן להצטרפות לשיחה (IP: ${callerIp || 'מאומת'})`;

  // 1. Send first immediate notification
  showHomeScreenNotification(title, {
    body,
    callerName,
    callerIp,
    tag: 'station-incoming-call'
  });

  // 2. Instruct Service Worker to hold persistent nagging loop in background
  try {
    if (navigator.serviceWorker?.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'START_NAGGING_ALERT',
        title,
        body
      });
    }
  } catch {}

  // 3. Client-side loop re-firing every 3.5s with renotify so it keeps buzzing the screen
  naggingInterval = setInterval(() => {
    showHomeScreenNotification(title, {
      body,
      callerName,
      callerIp,
      tag: 'station-incoming-call'
    });
  }, 3500);
}

/**
 * Stop the nagging alert loop immediately when call is answered, declined, or cancelled
 */
export function stopNaggingCallAlert() {
  if (naggingInterval) {
    clearInterval(naggingInterval);
    naggingInterval = null;
  }

  try {
    if (navigator.serviceWorker?.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'STOP_NAGGING_ALERT'
      });
    }
  } catch {}
}

/**
 * Convert URL-safe base64 string to Uint8Array for PushManager VAPID key
 */
function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

/**
 * Subscribe the browser to Web Push and register with the backend server by stationId.
 * Allows the browser to ring even when closed!
 */
export async function subscribeToWebPush(stationId: string): Promise<boolean> {
  if (typeof window === 'undefined' || !('serviceWorker' in navigator) || !('PushManager' in window)) {
    return false;
  }
  if (!stationId) return false;

  try {
    const reg = swRegistration || (await navigator.serviceWorker.ready);
    if (!reg) return false;

    // 1. Fetch public VAPID key from backend
    const res = await fetch('/api/vapid-public-key');
    if (!res.ok) return false;
    const { publicKey } = await res.json();
    if (!publicKey) return false;

    // 2. Subscribe browser to Push Service (Google/Apple)
    const convertedKey = urlBase64ToUint8Array(publicKey);
    let subscription = await reg.pushManager.getSubscription();

    if (!subscription) {
      subscription = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: convertedKey
      });
    }

    // 3. Register with backend
    const subRes = await fetch('/api/subscribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        stationId,
        subscription
      })
    });

    console.log('[WebPush] Registered with backend:', subRes.status);
    return subRes.ok;
  } catch (err) {
    console.warn('[WebPush] Registration failed:', err);
    return false;
  }
}

/**
 * Send an OS-level Push ring to an offline/sleeping peer via backend
 */
export async function sendPushRing(
  targetStationId: string,
  callerId: string,
  callerName: string,
  callerIp: string
): Promise<{ success: boolean; message?: string }> {
  try {
    const res = await fetch('/api/ring', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        targetStationId,
        callerId,
        callerName,
        callerIp
      })
    });
    return await res.json();
  } catch (err) {
    console.warn('[WebPush] Ring request failed:', err);
    return { success: false };
  }
}

/**
 * Cancel push ringing if caller hung up before answer
 */
export async function stopPushRing(targetStationId: string): Promise<void> {
  try {
    await fetch('/api/stop-ring', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ targetStationId })
    });
  } catch {}
}
