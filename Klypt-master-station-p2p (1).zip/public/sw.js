/**
 * Service Worker for Klypt
 * Handles background notifications, Web Push events, nagging call loops, and focus on click
 */

let naggingCallTimer = null;

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// ======================= WEB PUSH EVENT LISTENER =======================
// Wakes up the Service Worker even if the browser window is completely closed!
self.addEventListener('push', (event) => {
  let data = {};
  if (event.data) {
    try {
      data = event.data.json();
    } catch {
      data = { body: event.data.text() };
    }
  }

  // Handle call cancellation
  if (data.type === 'CANCEL_CALL') {
    if (naggingCallTimer) {
      clearInterval(naggingCallTimer);
      naggingCallTimer = null;
    }
    event.waitUntil(
      self.registration.getNotifications({ tag: 'station-incoming-call' }).then((notifications) => {
        notifications.forEach((n) => n.close());
      })
    );
    return;
  }

  const callerId = data.callerId || '';
  const callerName = data.callerName || 'חבר';
  const title = data.title || `שיחה נכנסת מ-${callerName}!`;
  const body = data.body || 'מחייג אליך כעת ל-Klypt • לחץ למענה';
  const targetUrl = data.url || `/?incomingCallFrom=${encodeURIComponent(callerId)}&callerName=${encodeURIComponent(callerName)}&autoAnswer=1`;

  // Start nagging ring cycle
  if (naggingCallTimer) {
    clearInterval(naggingCallTimer);
    naggingCallTimer = null;
  }

  const triggerAlert = () => {
    return self.registration.showNotification(title, {
      body,
      icon: '/station-logo.jpg',
      badge: '/station-logo.jpg',
      vibrate: [500, 200, 500, 200, 500, 300, 500],
      requireInteraction: true,
      tag: 'station-incoming-call',
      renotify: true,
      actions: [
        { action: 'answer', title: 'מענה לשיחה 📞' },
        { action: 'decline', title: 'דחה שיחה ✕' }
      ],
      data: {
        url: targetUrl,
        callerId,
        callerName,
        callerIp: data.callerIp || ''
      }
    });
  };

  // Immediate notification + repeating ring cycle every 3.5s
  naggingCallTimer = setInterval(triggerAlert, 3500);

  event.waitUntil(triggerAlert());
});

// ======================= NOTIFICATION CLICK HANDLER =======================
// When user clicks the OS notification on Desktop or Mobile Home Screen:
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (naggingCallTimer) {
    clearInterval(naggingCallTimer);
    naggingCallTimer = null;
  }

  if (event.action === 'decline') {
    return;
  }

  const data = event.notification.data || {};
  const targetUrl = data.url || (data.callerId ? `/?incomingCallFrom=${encodeURIComponent(data.callerId)}&autoAnswer=1` : '/');

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // 1. If an existing app window is open, focus it and auto-answer
      for (const client of clientList) {
        if ('focus' in client && client.url.includes(self.registration.scope)) {
          client.focus();
          client.postMessage({
            type: 'AUTO_ANSWER_CALL',
            callerId: data.callerId,
            callerName: data.callerName,
            callerIp: data.callerIp
          });
          return;
        }
      }

      // 2. Otherwise open a fresh window with incoming call parameters
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});

// ======================= CLIENT MESSAGES =======================
self.addEventListener('message', (event) => {
  const data = event.data;
  if (!data) return;

  if (data.type === 'SHOW_NOTIFICATION') {
    self.registration.showNotification(data.title, data.options);
  }

  // Persistent nagging alert loop from in-app
  if (data.type === 'START_NAGGING_ALERT') {
    if (naggingCallTimer) clearInterval(naggingCallTimer);
    const trigger = () => {
      self.registration.showNotification(data.title || 'שיחה נכנסת מחכה למענה!', {
        body: data.body || 'לחץ כאן כדי להיכנס מיד לשיחה',
        icon: '/station-logo.jpg',
        badge: '/station-logo.jpg',
        vibrate: [500, 200, 500, 200, 500],
        requireInteraction: true,
        tag: 'station-incoming-call',
        renotify: true,
        actions: [
          { action: 'answer', title: 'מענה לשיחה 📞' },
          { action: 'decline', title: 'דחה שיחה ✕' }
        ],
        data: { url: data.url || '/' }
      });
    };
    trigger();
    naggingCallTimer = setInterval(trigger, 3500);
  }

  if (data.type === 'STOP_NAGGING_ALERT') {
    if (naggingCallTimer) {
      clearInterval(naggingCallTimer);
      naggingCallTimer = null;
    }
  }

  if (data.type === 'SCHEDULE_TEST_NOTIFICATION') {
    const delay = data.delay || 4000;
    setTimeout(() => {
      self.registration.showNotification('בדיקה מוצלחת במסך הבית!', {
        body: 'ההתראה עובדת מעולה! לחץ כאן כדי לחזור מיד לאפליקציה.',
        icon: '/station-logo.jpg',
        badge: '/station-logo.jpg',
        vibrate: [500, 200, 500, 200, 500],
        requireInteraction: true,
        tag: 'test-home-screen-alert',
        renotify: true,
        data: { url: '/' }
      });
    }, delay);
  }
});
